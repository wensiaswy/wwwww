# KHUMOYUN OS — Netlify'ga joylashtirish

Sayt **butunlay statik**: server, baza yoki build qadami kerak emas.
Barcha ma'lumotlar foydalanuvchi qurilmasida (localStorage + IndexedDB) saqlanadi.

## 1-usul (eng oson) — yakka fayl
`netlify-drop/index.html` — hamma narsa (CSS, JS, shrift, ikonka) bitta fayl ichida.
1. https://app.netlify.com/drop ni oching
2. **index.html** faylini sudrab tashlang (yoki Netlify → Deploys → "Drag and drop")
3. Tayyor — havola darhol ishlaydi (HTTPS avtomatik)

> Bu nusxada Service Worker yo'q, ya'ni **offline/PWA rejimi ishlamaydi**.
> To'liq offline + "ilova sifatida o'rnatish" kerak bo'lsa 2-usulni ishlating.

## 2-usul (tavsiya) — to'liq statik sayt
`khumoyun-os-netlify.zip` (yoki `netlify-static/` papkasi) — to'liq versiya:
offline rejim, Service Worker, manifest, ikonka, Inter shrifti.

**A) ZIP bilan:** https://app.netlify.com/drop → zip faylni tashlang.
**B) Papka bilan:** `netlify-static` papkasini Netlify Drop'ga tashlang.
**C) GitHub bilan:** kodni repo'ga qo'ying → Netlify → "Import from GitHub":
- Build command: **(bo'sh)**
- Publish directory: **netlify-static** (yoki sayt papkasi)

Sayt ichida `netlify.toml`, `_headers`, `_redirects` bor — ular kerakli
kesh sozlamalari va SPA qayta yo'naltirishni o'zi bajaradi (sw.js va version.json
hech qachon keshlanmaydi, shu sababli yangi versiya darhol ko'rinadi).

## Birinchi ochilganda
1. PIN kod o'rnatasiz (4/5/6 xona) — keyin faqat kod kiritiladi, tizim o'zi ochiladi.
2. Sozlamalar → Profil orqali ismingizni o'zgartirasiz (WELCOME ... shu ismga bog'lanadi).
3. Chrome/Edge manzil qatoridagi "o'rnatish" belgisi orqali **ilova sifatida** o'rnatish mumkin.

## Muhim
- Ma'lumotlar **har bir qurilma/brauzer uchun alohida** saqlanadi (serverga yuborilmaydi).
  Ko'chirish uchun: Sozlamalar → Ma'lumotlar → **ZIP zaxira nusxa** oling, yangi qurilmada **Import** qiling.
- Yangilash: yangi versiyani qayta deploy qilsangiz, foydalanuvchida pastdan "Yangilash"
  paneli o'zi chiqadi (yoki Sozlamalar → Yordam → "Keshni tozalash va yangilash").

## Qayta yasash (kod o'zgargach)
```bash
node tools/build-netlify.mjs
```
Natija: `deploy/netlify-static/`, `deploy/netlify-drop/index.html`, `deploy/khumoyun-os-netlify.zip`
