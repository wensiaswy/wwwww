/* ============================================================
   KHUMOYUN OS — Service Worker (v2.2.0)
   - HTML/CSS/JS  : network-first  → yangi versiya DARHOL ko'rinadi
   - Ikon/rasm    : cache-first    → tez va offline
   - sw.js / version.json : hech qachon keshlanmaydi
   - skipWaiting + clients.claim → yangilanish bir zumda qo'llanadi
   ============================================================ */
const VERSION = 'kwt-v2.2.0';
const ASSETS = [
  './', './index.html', './manifest.webmanifest', './version.json', './icons/icon.svg',
  './css/base.css', './css/components.css', './css/effects.css',
  './fonts/inter-400.woff2', './fonts/inter-600.woff2', './fonts/inter-700.woff2', './fonts/inter-800.woff2',
  './js/app.js', './js/util.js', './js/store.js', './js/zip.js', './js/charts.js', './js/form.js', './js/kit.js',
  './js/view-dashboard.js', './js/view-cash.js', './js/view-journal.js', './js/view-goals.js',
  './js/view-life.js', './js/view-music.js', './js/view-settings.js',
];
const NEVER = /\/(sw\.js|version\.json)(\?|$)/;

self.addEventListener('install', (e) => {
  e.waitUntil((async () => {
    const cache = await caches.open(VERSION);
    await Promise.all(ASSETS.map(async (a) => {
      try { await cache.add(new Request(a, { cache: 'reload' })); } catch (err) { /* fayl yo'q */ }
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)));
    await self.clients.claim();
    const cs = await self.clients.matchAll({ includeUncontrolled: true });
    cs.forEach((c) => c.postMessage({ type: 'activated', version: VERSION }));
  })());
});

self.addEventListener('message', (e) => {
  const d = e.data;
  if (d === 'skip-waiting' || (d && d.type === 'skip-waiting')) self.skipWaiting();
  if (d && d.type === 'clear-caches') {
    e.waitUntil((async () => {
      const keys = await caches.keys();
      await Promise.all(keys.map((k) => caches.delete(k)));
    })());
  }
});

function isStatic(url) {
  return /\.(?:css|js|mjs|html)$/i.test(url.pathname) || url.pathname === '/' || url.pathname.endsWith('/');
}
function isMedia(url) {
  return /\.(?:png|jpe?g|webp|gif|svg|ico|woff2?|ttf|mp3|ogg|mp4|webm)$/i.test(url.pathname);
}

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (NEVER.test(url.pathname)) return;              // doim tarmoqdan

  e.respondWith((async () => {
    const cache = await caches.open(VERSION);

    /* --- media/ikon: cache-first (offline tez) --- */
    if (isMedia(url)) {
      const hit = await cache.match(req, { ignoreSearch: true });
      if (hit) return hit;
      try {
        const net = await fetch(req);
        if (net && net.status === 200) cache.put(req, net.clone());
        return net;
      } catch (err) { return new Response('', { status: 504, statusText: 'Offline' }); }
    }

    /* --- HTML/CSS/JS: network-first --- */
    try {
      const net = await fetch(req, { cache: 'no-cache' });
      if (net && net.status === 200 && net.type === 'basic') cache.put(req, net.clone());
      return net;
    } catch (err) {
      const hit = await cache.match(req, { ignoreSearch: true });
      if (hit) return hit;
      if (req.mode === 'navigate') {
        const shell = await cache.match('./index.html');
        if (shell) return shell;
      }
      return new Response('Offline va keshda nusxa topilmadi', { status: 503, statusText: 'Offline' });
    }
  })());
});
