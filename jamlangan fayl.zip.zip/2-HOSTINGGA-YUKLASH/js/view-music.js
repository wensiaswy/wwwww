/* ============================================================
   KHUMOYUN OS — Musiqa: jildlar (1:1 muqova), mp3 import, player
   ============================================================ */
import { $, $$, esc, icon, on, toast, sfx, uid, modal, confirmDialog, fmtDate, clamp, sound } from './util.js';
import { state, save, media, mediaFromFile, logActivity } from './store.js';
import { pageHead, section, empty, bar, kpi, statMini, thumb, editBtn, delBtn, tagsRow } from './kit.js';
import { fillMedia, openForm, SCHEMAS, pickFiles, pickFile } from './form.js';

/* ================= PLAYER ================= */
export const player = {
  audio: null, queue: [], index: -1, shuffle: false, repeat: 'off', analyser: null, srcNode: null, gain: null,
  init() {
    if (this.audio) return this.audio;
    const a = new Audio();
    a.preload = 'metadata';
    a.volume = state.settings.volume != null ? state.settings.volume : .6;
    a.addEventListener('ended', () => this.next(true));
    a.addEventListener('timeupdate', () => updateSeek());
    a.addEventListener('play', () => { renderBar(); });
    a.addEventListener('pause', () => { renderBar(); });
    this.audio = a;
    return a;
  },
  connect() {
    try {
      const c = sound.init(); if (!c || !this.audio || this.srcNode) return;
      this.srcNode = c.createMediaElementSource(this.audio);
      this.gain = c.createGain(); this.gain.gain.value = 1;
      this.analyser = c.createAnalyser(); this.analyser.fftSize = 128;
      this.srcNode.connect(this.analyser); this.analyser.connect(this.gain); this.gain.connect(c.destination);
    } catch (e) { /* analyser mavjud emas — oddiy ijro */ }
  },
  async load(trackId, queueIds) {
    const t = state.music.tracks.find((x) => x.id === trackId);
    if (!t) return toast('Trek topilmadi', { type: 'error' });
    const url = await media.url(t.file);
    if (!url) return toast('Audio fayl yuklanmagan', { type: 'error' });
    this.init(); this.connect();
    this.audio.src = url;
    this.index = this.queue.indexOf(trackId);
    if (queueIds) this.queue = queueIds;
    if (this.index < 0) { this.queue = queueIds || state.music.tracks.map((x) => x.id); this.index = this.queue.indexOf(trackId); }
    try { await this.audio.play(); sfx('check'); } catch (e) { toast('Brauzer ijroni blokladi — qayta bosing', { type: 'warn' }); }
    renderBar();
  },
  toggle() {
    if (!this.audio || !this.audio.src) { if (state.music.tracks.length) this.load(state.music.tracks[0].id); return; }
    if (this.audio.paused) { this.connect(); this.audio.play().catch(() => { }); } else this.audio.pause();
    renderBar();
  },
  next(auto) {
    if (!this.queue.length) return;
    if (this.repeat === 'one' && auto) { this.audio.currentTime = 0; this.audio.play(); return; }
    let i = this.shuffle ? Math.floor(Math.random() * this.queue.length) : this.index + 1;
    if (i >= this.queue.length) { if (this.repeat === 'all' || !auto) i = 0; else { this.audio.pause(); return; } }
    this.load(this.queue[i]);
  },
  prev() {
    if (!this.queue.length) return;
    let i = this.index - 1; if (i < 0) i = this.queue.length - 1;
    this.load(this.queue[i]);
  },
  seek(pct) { if (this.audio && this.audio.duration) this.audio.currentTime = (pct / 100) * this.audio.duration; },
  setVolume(v) { this.init(); this.audio.volume = clamp(v, 0, 100) / 100; state.settings.volume = clamp(v, 0, 100) / 100; save(); },
  setEQ(bands) {
    this.connect();
    if (!this.analyser || !this.ctx) return;
  },
  current() { return state.music.tracks.find((t) => t.id === this.queue[this.index]) || null; },
};
function fmtTime(s) {
  if (!isFinite(s)) return '0:00';
  const m = Math.floor(s / 60), sec = Math.floor(s % 60);
  return `${m}:${String(sec).padStart(2, '0')}`;
}
function updateSeek() {
  const barEl = document.querySelector('#playerInner .pl-bar i');
  const t1 = document.querySelector('#playerInner [data-t="cur"]');
  const t2 = document.querySelector('#playerInner [data-t="dur"]');
  const a = player.audio;
  if (!a) return;
  if (barEl) barEl.style.transform = 'scaleX(' + (a.duration ? a.currentTime / a.duration : 0).toFixed(4) + ')';
  if (t1) t1.textContent = fmtTime(a.currentTime);
  if (t2) t2.textContent = fmtTime(a.duration);
}
let vizRAF = null;
function startViz() {
  const wrap = document.querySelector('#playerInner .viz');
  if (!wrap || vizRAF) return;
  const bars = $$('i', wrap);
  let data = null;   /* bufer bir marta ajratiladi — har freymda GC bo'lmaydi */
  const loop = () => {
    vizRAF = requestAnimationFrame(loop);
    if (document.hidden) return;
    if (!player.analyser) {
      for (let i = 0; i < bars.length; i++) {
        const h = player.audio && !player.audio.paused ? 20 + Math.random() * 70 : 12;
        bars[i].style.transform = 'scaleY(' + (h / 100).toFixed(2) + ')';
      }
      return;
    }
    if (!data || data.length !== player.analyser.frequencyBinCount) data = new Uint8Array(player.analyser.frequencyBinCount);
    player.analyser.getByteFrequencyData(data);
    for (let i = 0; i < bars.length; i++) {
      const v = data[Math.floor((i / bars.length) * (data.length * .7))] || 0;
      bars[i].style.transform = 'scaleY(' + Math.max(.08, v / 255).toFixed(2) + ')';
    }
  };
  loop();
}
export function renderBar() {
  const wrap = $('#player'); const inner = $('#playerInner');
  if (!wrap || !inner) return;
  const t = player.current();
  if (!t) { wrap.hidden = true; return; }
  wrap.hidden = false;
  const folder = state.music.folders.find((f) => f.id === t.folder);
  inner.innerHTML = `
    ${thumb(t.file, { ratio: '1:1', pos: '50% 50%', style: 'width:52px;height:52px', icon: 'music', cls: 'pl-cover' }).replace('class="thumb', 'class="pl-cover thumb')}
    <div class="pl-info">
      <div class="pl-title">${esc(t.title)}</div>
      <div class="pl-artist">${esc(t.artist || folder ? (t.artist || folder.name) : 'Noma\'lum')}</div>
    </div>
    <div class="pl-controls">
      <button class="pl-btn ${player.shuffle ? 'on' : ''}" data-p="shuffle" title="Tasodifiy">${icon('shuffle')}</button>
      <button class="pl-btn" data-p="prev" title="Oldingi">${icon('prev')}</button>
      <button class="pl-btn main" data-p="toggle" title="Ijro / pauza">${icon(player.audio && !player.audio.paused ? 'pause' : 'play')}</button>
      <button class="pl-btn" data-p="next" title="Keyingi">${icon('next')}</button>
      <button class="pl-btn ${player.repeat !== 'off' ? 'on' : ''}" data-p="repeat" title="Takrorlash">${icon('repeat')}</button>
    </div>
    <div class="pl-seek">
      <span class="pl-time" data-t="cur">0:00</span>
      <div class="pl-bar" data-seek><i></i></div>
      <span class="pl-time" data-t="dur">0:00</span>
    </div>
    <div class="viz">${Array.from({ length: 14 }).map(() => '<i></i>').join('')}</div>
    <div class="pl-controls">
      <button class="pl-btn" data-p="volume" title="Ovoz">${icon('volume')}</button>
      <input type="range" min="0" max="100" value="${Math.round((state.settings.volume || .6) * 100)}" data-vol style="width:90px">
      <button class="pl-btn" data-p="close" title="Yopish">${icon('x')}</button>
    </div>`;
  fillMedia(inner);
  startViz(); updateSeek();
}
export function bindPlayer() {
  const wrap = $('#player');
  if (!wrap || wrap.dataset.bound) return;
  wrap.dataset.bound = '1';
  on(wrap, 'click', '[data-p]', (e, b) => {
    const p = b.dataset.p;
    if (p === 'toggle') player.toggle();
    else if (p === 'next') player.next(false);
    else if (p === 'prev') player.prev();
    else if (p === 'shuffle') { player.shuffle = !player.shuffle; sfx('tap'); renderBar(); }
    else if (p === 'repeat') { player.repeat = player.repeat === 'off' ? 'all' : player.repeat === 'all' ? 'one' : 'off'; sfx('tap'); renderBar(); }
    else if (p === 'volume') { player.setVolume(state.settings.volume > 0 ? 0 : 60); renderBar(); }
    else if (p === 'close') { player.audio && player.audio.pause(); $('#player').hidden = true; }
  });
  on(wrap, 'input', '[data-vol]', (e, b) => { player.setVolume(b.value); });
  on(wrap, 'click', '[data-seek]', (e, b) => {
    const r = b.getBoundingClientRect();
    player.seek(((e.clientX - r.left) / r.width) * 100);
  });
}

/* ================= IMPORT ================= */
async function probe(file) {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const a = new Audio();
    a.preload = 'metadata';
    a.onloadedmetadata = () => { const d = a.duration; URL.revokeObjectURL(url); resolve(isFinite(d) ? d : 0); };
    a.onerror = () => { URL.revokeObjectURL(url); resolve(0); };
    a.src = url;
  });
}
export async function importTracks(files, folderId, ctx) {
  let n = 0;
  for (const f of files) {
    const base = (f.name || 'track').replace(/\.[a-z0-9]+$/i, '');
    const rec = await mediaFromFile(f, { maxDim: 0 });
    const dur = await probe(f);
    const track = {
      id: uid('trk'), title: base, artist: '', folder: folderId || null,
      file: rec.id, duration: dur, mood: 'chill', addedAt: new Date().toISOString(),
    };
    state.music.tracks.push(track);
    n++;
    toast(`${n}/${files.length} · ${base}`, { type: 'info', ms: 1200 });
  }
  save();
  logActivity(`${n} ta musiqa import qilindi`, 'music');
  toast(`${n} ta musiqa qo'shildi`, { type: 'success' });
  sfx('success');
  ctx && ctx.refresh();
}

/* ================= VIEW ================= */
export function render(view, ctx) {
  const fId = ctx.query.get('f');
  const folder = state.music.folders.find((f) => f.id === fId);
  const q = ctx.query.get('q') || '';
  if (folder) return renderFolder(view, ctx, folder);
  return renderLibrary(view, ctx, q);
}

function renderLibrary(view, ctx, q) {
  const folders = state.music.folders;
  let tracks = [...state.music.tracks].sort((a, b) => String(b.addedAt).localeCompare(String(a.addedAt)));
  if (q) tracks = tracks.filter((t) => `${t.title} ${t.artist}`.toLowerCase().includes(q.toLowerCase()));
  const totalDur = state.music.tracks.reduce((s, t) => s + (Number(t.duration) || 0), 0);
  view.innerHTML = `<div class="stagger">
    ${pageHead({
    title: 'Musiqa', icon: 'music', badge: 'sevimli musiqalar',
    sub: `${state.music.tracks.length} trek · ${folders.length} jild · jami ${Math.round(totalDur / 60)} daqiqa`,
    actions: `<button class="btn sm ghost" data-act="add-folder">${icon('folder')}Yangi jild</button>
        <button class="btn primary sm" data-act="import">${icon('upload')}MP3 import</button>`
  })}
    <div class="kpis" style="margin-bottom:18px">
      ${kpi({ label: 'Trekllar', value: String(state.music.tracks.length), icon: 'music' })}
      ${kpi({ label: 'Jildlar', value: String(folders.length), icon: 'folder' })}
      ${kpi({ label: 'Umumiy vaqt', value: `${Math.floor(totalDur / 60)} daq`, icon: 'clock' })}
      ${kpi({ label: 'Hajm', value: `${(state.music.tracks.length * 3).toFixed(0)} MB~`, icon: 'grid' })}
    </div>
    ${section({
    title: 'Jildlar', icon: 'folder', sub: 'Jild tugmasining ustiga 1:1 formatdagi rasm qo\'yishingiz mumkin',
    actions: `<button class="btn sm ghost" data-act="add-folder">${icon('plus')}Jild qo'shish</button>`,
    body: `<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(170px,1fr))">
        ${folders.map((f) => {
      const list = state.music.tracks.filter((t) => t.folder === f.id);
      return `<button class="tile" data-act="open-folder" data-id="${f.id}" style="text-align:left">
          <div style="position:relative">
            ${thumb(f.cover, { ratio: '1:1', pos: f.cover_pos, zoom: f.cover_zoom, icon: 'folder', style: `border-radius:0;background:${esc(f.color || 'var(--accent)')}22` })}
            <span class="badge" style="position:absolute;bottom:8px;left:8px;z-index:2">${icon('music')}${list.length}</span>
          </div>
          <div class="tile-body"><div class="tile-label">${esc(f.name)}</div><div class="tile-sub">${esc((f.note || 'Jild').slice(0, 26))}</div></div>
        </button>`;
    }).join('')}
        <button class="tile add" data-act="add-folder">${icon('plus')}<span class="tiny">Yangi jild</span></button>
      </div>`
  })}
    ${section({
    title: 'Barcha treklar', icon: 'music', sub: 'Play tugmasini bosib tinglang',
    actions: `<div class="top-search" style="max-width:230px">${icon('search')}<input id="mSearch" placeholder="Musiqa qidirish…" value="${esc(q)}"></div>
        <button class="btn sm ghost" data-act="import">${icon('upload')}Import</button>`,
    body: tracks.length ? `<div class="list">${tracks.map((t) => trackRow(t, ctx)).join('')}</div>`
      : empty({ icon: 'music', title: 'Musiqa yo\'q', sub: 'MP3 fayllarni import qiling — telefoningizdan yoki kompyuteringizdan', action: `<button class="btn primary sm" data-act="import">${icon('upload')}MP3 import qilish</button>` })
  })}
  </div>`;
  fillMedia(view);
  const s = view.querySelector('#mSearch');
  if (s) s.addEventListener('input', (e) => { const val = e.target.value; const p = e.target.selectionStart; ctx.go('music', { q: val }).then(() => { const el = view.querySelector('#mSearch'); if (el) { el.focus(); el.setSelectionRange(p, p); } }); });
  bindActs(view, ctx);
}

function renderFolder(view, ctx, folder) {
  const tracks = state.music.tracks.filter((t) => t.folder === folder.id);
  view.innerHTML = `<div class="stagger">
    ${pageHead({
    title: folder.name, icon: 'folder', badge: 'musiqa jildi', back: 'music',
    sub: `${tracks.length} trek · ${Math.round(tracks.reduce((s, t) => s + (t.duration || 0), 0) / 60)} daqiqa`,
    actions: `<button class="btn sm ghost" data-act="edit-folder" data-id="${folder.id}">${icon('pencil')}Tahrirlash</button>
        <button class="btn sm ghost" data-act="play-all" data-id="${folder.id}">${icon('play')}Hammasini ijro</button>
        <button class="btn primary sm" data-act="import-here" data-id="${folder.id}">${icon('upload')}Trek qo'shish</button>`
  })}
    <div class="card" style="margin-bottom:18px;overflow:hidden">
      <div class="row" style="gap:18px;flex-wrap:wrap">
        <div style="width:200px">${thumb(folder.cover, { ratio: '1:1', pos: folder.cover_pos, zoom: folder.cover_zoom, icon: 'folder', cls: 'shine', style: 'border-radius:var(--radius-sm)' })}</div>
        <div class="grow col">
          <div class="h2">${esc(folder.name)}</div>
          <div class="tiny faint">${esc(folder.note || 'Izoh yo\'q')}</div>
          <div class="row wrap" style="gap:8px;margin-top:6px">
            ${statMini('Trekllar', String(tracks.length), 'music')}
            ${statMini('Yaratilgan', fmtDate(folder.createdAt || new Date().toISOString()), 'calendar')}
          </div>
          <div class="row" style="gap:8px;margin-top:8px">
            <button class="btn sm soft" data-act="import-here" data-id="${folder.id}">${icon('upload')}Fayl qo'shish</button>
            <button class="btn sm ghost" data-act="edit-folder" data-id="${folder.id}">${icon('pencil')}Tahrirlash</button>
            <button class="btn sm danger" data-act="del-folder" data-id="${folder.id}">${icon('trash')}Jildni o'chirish</button>
          </div>
        </div>
      </div>
    </div>
    ${section({
    title: 'Treklar', icon: 'list', sub: 'Qalamcha orqali nomi, ijrochisi va muqovasini o\'zgartirishingiz mumkin',
    body: tracks.length ? `<div class="list">${tracks.map((t) => trackRow(t, ctx)).join('')}</div>`
      : empty({ icon: 'music', title: 'Bu jild bo\'sh', sub: 'MP3 fayllarni shu jildga yuklang', action: `<button class="btn primary sm" data-act="import-here" data-id="${folder.id}">${icon('upload')}Fayl qo'shish</button>` })
  })}
  </div>`;
  fillMedia(view);
  bindActs(view, ctx);
}

function trackRow(t, ctx) {
  const playing = player.current() && player.current().id === t.id && player.audio && !player.audio.paused;
  const folder = state.music.folders.find((f) => f.id === t.folder);
  return `<div class="item">
    <button class="icon-btn big" data-act="play" data-id="${t.id}" title="Ijro etish">${icon(playing ? 'pause' : 'play')}</button>
    <div class="avatar" style="overflow:hidden">${icon('music')}</div>
    <div class="item-main">
      <div class="item-title">${esc(t.title)} ${playing ? '<span class="eqbars"><i></i><i></i><i></i></span>' : ''}</div>
      <div class="item-sub">${esc(t.artist || 'Noma\'lum ijrochi')}${folder ? ' · ' + esc(folder.name) : ''} · ${esc(fmtTime(t.duration || 0))}</div>
    </div>
    <div class="item-actions">
      ${editBtn('edit-track', t.id)}${delBtn('del-track', t.id)}
    </div>
  </div>`;
}

function bindActs(view, ctx) {
  on(view, 'click', '[data-act]', async (e, b) => {
    const act = b.dataset.act, id = b.dataset.id;
    if (act === 'add-folder') return openFolderForm(null, ctx);
    if (act === 'edit-folder') return openFolderForm(state.music.folders.find((f) => f.id === id), ctx);
    if (act === 'del-folder') {
      const ok = await confirmDialog('Jildni o\'chirish?', 'Jild o\'chiriladi, treklar kutubxonada qoladi.', { danger: true, okLabel: 'O\'chirish' });
      if (!ok) return;
      state.music.folders = state.music.folders.filter((f) => f.id !== id);
      save(); toast('Jild o\'chirildi', { type: 'warn' }); ctx.refresh(); return;
    }
    if (act === 'open-folder') { sfx('open'); return ctx.go('music', { f: id }); }
    if (act === 'import') {
      const files = await pickFiles('audio/*,.mp3,.wav,.m4a,.flac,.ogg');
      if (!files.length) return;
      return importTracks(files, null, ctx);
    }
    if (act === 'import-here') {
      const files = await pickFiles('audio/*,.mp3,.wav,.m4a,.flac,.ogg');
      if (!files.length) return;
      return importTracks(files, id, ctx);
    }
    if (act === 'play') {
      const t = state.music.tracks.find((x) => x.id === id);
      const list = t && t.folder ? state.music.tracks.filter((x) => x.folder === t.folder).map((x) => x.id) : state.music.tracks.map((x) => x.id);
      if (player.current() && player.current().id === id) player.toggle(); else await player.load(id, list);
      ctx.refresh(); return;
    }
    if (act === 'play-all') {
      const list = state.music.tracks.filter((t) => t.folder === id).map((t) => t.id);
      if (!list.length) return toast('Jild bo\'sh', { type: 'warn' });
      await player.load(list[0], list); ctx.refresh(); return;
    }
    if (act === 'edit-track') return openTrackForm(state.music.tracks.find((t) => t.id === id), ctx);
    if (act === 'del-track') {
      state.music.tracks = state.music.tracks.filter((t) => t.id !== id);
      save(); toast('Trek o\'chirildi', { type: 'warn' }); ctx.refresh(); return;
    }
  });
}

export function openFolderForm(data, ctx) {
  const editing = !!(data && data.id);
  openForm({
    title: editing ? 'Jildni tahrirlash' : 'Yangi jild', icon: 'folder', schema: SCHEMAS.folder, data: data || {},
    subtitle: 'Jild nomi, rangi va 1:1 muqova rasmi',
    allowDelete: editing,
    onDelete: () => { state.music.folders = state.music.folders.filter((f) => f.id !== data.id); save(); ctx.refresh(); },
    onSave: (v) => {
      if (editing) Object.assign(data, v);
      else { state.music.folders.push({ id: uid('fld'), ...v, createdAt: new Date().toISOString() }); logActivity(`Musiqa jildi yaratildi: ${v.name}`, 'folder'); }
      save(); toast('Jild saqlandi', { type: 'success' }); ctx.refresh();
    },
  });
}
export function openTrackForm(data, ctx) {
  const editing = !!(data && data.id);
  openForm({
    title: editing ? 'Trekni tahrirlash' : 'Yangi trek', icon: 'music', schema: SCHEMAS.track, data: data || {},
    subtitle: 'Audio faylni tanlang, nomi va ijrochisini yozing',
    allowDelete: editing,
    onDelete: () => { state.music.tracks = state.music.tracks.filter((t) => t.id !== data.id); save(); ctx.refresh(); },
    onSave: async (v) => {
      if (editing) Object.assign(data, v);
      else {
        state.music.tracks.push({ id: uid('trk'), duration: 0, addedAt: new Date().toISOString(), ...v });
      }
      save(); toast('Trek saqlandi', { type: 'success' }); ctx.refresh();
    },
  });
}

export { render as default };
