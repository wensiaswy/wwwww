/* ============================================================
   KHUMOYUN OS — app shell: nav, router, lock, splash, fon, FX
   ============================================================ */
import { $, $$, esc, icon, on, toast, sfx, sound, ambient, clamp, todayISO, debounce, throttle, modal, confirmDialog, animateNumber, countUpAll, barFill, ripple, download, DAYS_UZ, MONTHS_UZ, humanSize } from './util.js';
import { state, load, save, saveNow, subscribe, media, money, netWorth, ensureSnapshot, logActivity, setPin, verifyPin, exportAll } from './store.js';
import { fillMedia, openForm, SCHEMAS, pickFiles } from './form.js';
import { THEMES } from './view-settings.js';

import * as vDashboard from './view-dashboard.js';
import * as vCash from './view-cash.js';
import * as vJournal from './view-journal.js';
import * as vGoals from './view-goals.js';
import * as vLife from './view-life.js';
import * as vMusic from './view-music.js';
import * as vSettings from './view-settings.js';

const VIEWS = {
  dashboard: vDashboard, cash: vCash, journal: vJournal, goals: vGoals, wishlist: vGoals,
  notes: vLife, tasks: vLife, music: vMusic, search: vSettings, settings: vSettings,
};
const NAV_META = vSettings.NAV_META;
const SECTIONS = [
  ['Asosiy', ['dashboard', 'cash', 'journal']],
  ['Maqsadlar', ['goals', 'wishlist']],
  ['Hayot', ['notes', 'tasks', 'music']],
  ['Tizim', ['search', 'settings']],
];

/* ================= BUILD / VERSIYA ================= */
export const BUILD = '2.2.0';
export const BUILD_DATE = '2026-10-11';

let current = { route: 'dashboard', query: new URLSearchParams() };
let idleTimer = null;

/* ================= UI APPLY ================= */
/* Har bir "UI formati" o'z qiymatlariga ega — shu sababli tanlash darhol ko'rinadi. */
export const PRESET_UI = {
  glass: { glass: 22, radius: 20, panelAlpha: 6, borderAlpha: 12, shadow: 1, tint: 'auto' },
  solid: { glass: 0, radius: 16, panelAlpha: 90, borderAlpha: 9, shadow: .85, tint: 'solid' },
  neon: { glass: 16, radius: 16, panelAlpha: 4, borderAlpha: 30, shadow: 1.2, tint: 'auto' },
  minimal: { glass: 10, radius: 12, panelAlpha: 2.5, borderAlpha: 8, shadow: .35, tint: 'auto' },
  cinematic: { glass: 34, radius: 28, panelAlpha: 8, borderAlpha: 16, shadow: 1.4, tint: 'auto' },
};
/* Panel rangi: "auto" = oq (shisha), "solid" = mavzu fonidan olingan quyuq rang */
function mixHex(hex, white = 0.08) {
  const h = String(hex || '').trim().replace('#', '');
  const full = h.length === 3 ? h.split('').map((c) => c + c).join('') : h;
  if (full.length < 6) return '255,255,255';
  const n = parseInt(full.slice(0, 6), 16);
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  const f = (v) => Math.round(v + (255 - v) * white);
  return `${f(r)},${f(g)},${f(b)}`;
}
export function applyPreset(key, { silent } = {}) {
  const p = PRESET_UI[key] || PRESET_UI.glass;
  state.settings.preset = key;
  Object.assign(state.settings.ui, {
    glass: p.glass, radius: p.radius, panelAlpha: p.panelAlpha,
    borderAlpha: p.borderAlpha, shadow: p.shadow, tint: p.tint,
  });
  saveNow();
  document.documentElement.dataset.preset = key;
  applyUi();
  if (!silent) {
    const names = { glass: 'Glass', solid: 'Solid', neon: 'Neon', minimal: 'Minimal', cinematic: 'Cinematic' };
    toast(`UI formati: ${names[key] || key} qo'llandi`, { type: 'success' });
  }
}
let uiRaf = 0, uiSig = '';
/* rAF bilan birlashtiriladi: bir freymda bir necha marta chaqirilsa ham FAQAT bir marta
   qo'llanadi. Shu bilan slayder surishda style/layout thrashing bo'lmaydi. */
export function applyUi() {
  if (uiRaf) return;
  uiRaf = requestAnimationFrame(() => { uiRaf = 0; try { applyUiNow(); } catch (e) { console.error(e); } });
}
function applyUiNow() {
  const s = state.settings, ui = s.ui;
  const root = document.documentElement;
  /* qiymatlar o'zgarmagan bo'lsa — umuman qayta hisoblamaymiz */
  const sig = [s.theme, s.preset, ui.density, s.perf, !!s.lowfx, !!s.effects.cursorGlow, ui.glass, ui.radius, ui.dim,
    ui.fontScale, ui.anim, ui.panelAlpha, ui.borderAlpha, ui.shadow, ui.tint || ''].join('|');
  if (sig === uiSig) return;
  uiSig = sig;
  root.dataset.theme = s.theme || 'emerald';
  /* tema o'zgardi — zarrachalar rangini qayta o'qish kerak (har freymda emas) */
  try { window.dispatchEvent(new Event('kx:theme')); } catch (e) { }
  root.dataset.preset = s.preset || 'glass';
  root.dataset.density = ui.density || 'cozy';
  document.body.classList.toggle('calm', Number(ui.anim) === 0);
  /* Ishlash rejimi: kuchsiz kompyuterlarda og'ir effektlar avtomatik kamayadi */
  const perf = s.perf || 'auto';
  document.body.classList.toggle('lowfx', perf === 'lite' || (perf !== 'full' && !!s.lowfx));
  document.body.classList.toggle('no-cursor-glow', !s.effects.cursorGlow);
  if (ui.borderAlpha == null) ui.borderAlpha = Math.round(8 + ui.glass / 4);
  if (ui.shadow == null) ui.shadow = 1;
  const tint = ui.tint || (s.preset === 'solid' ? 'solid' : 'auto');
  const bg2 = getComputedStyle(root).getPropertyValue('--bg-2') || '#0a1119';
  root.style.setProperty('--panel-rgb', tint === 'solid' ? mixHex(bg2, .1) : '255,255,255');
  const density = ui.density === 'compact' ? .9 : ui.density === 'roomy' ? 1.12 : 1;
  const vars = {
    '--glass': ui.glass + 'px', '--radius': ui.radius + 'px',
    '--radius-sm': Math.max(6, ui.radius - 6) + 'px', '--radius-lg': (ui.radius + 10) + 'px',
    '--dim': (ui.dim / 100), '--font-scale': (ui.fontScale / 100),
    '--anim': Math.max(.15, ui.anim / 100),
    '--panel-a': (ui.panelAlpha / 100 * density).toFixed(3),
    '--panel-a-2': (ui.panelAlpha / 100 * 1.6 * density).toFixed(3),
    '--border-a': (ui.borderAlpha / 100).toFixed(3),
    '--shadow': `0 ${Math.round(22 * ui.shadow)}px ${Math.round(60 * ui.shadow)}px rgba(0,0,0,${(0.45 * ui.shadow).toFixed(2)})`,
    '--shadow-sm': `0 ${Math.round(6 * ui.shadow)}px ${Math.round(22 * ui.shadow)}px rgba(0,0,0,${(0.26 * ui.shadow).toFixed(2)})`,
  };
  Object.entries(vars).forEach(([k, v]) => root.style.setProperty(k, v));
  window.__anim = Math.max(.15, ui.anim / 100);
  sound.on = !!s.sound; sound.vol = s.volume != null ? s.volume : .5;
  sound.pack = ['glass', 'soft', 'mech', 'bubble', 'marimba', 'retro', 'drop'].includes(s.soundPack) ? s.soundPack.replace('drop', 'bubble') : 'glass';
  sound.custom = s.customSfx || {};
  sound.sampleResolver = (id) => media.url(id);
  applyBg();
  buildNav();
  updateTopbar();
  if (typeof playerRefresh === 'function') playerRefresh();
}

/* ================= BACKGROUND ================= */
const bgUrls = {};
async function applyBg() {
  const main = state.settings.bg.main, lock = state.settings.bg.lock;
  const mainWrap = $('#bgMedia'), lockWrap = $('#lockBg');
  if (mainWrap) {
    const blur = main.hide ? 0 : (Number(main.blur) || 0);
    const zoomPct = Number(main.zoom) || 100;
    /* blur oshgani sari fon kattalashadi — chetlarda "kesilgan"/qora hoshiya ko'rinmaydi */
    mainWrap.style.setProperty('--bg-zoom', ((zoomPct / 100) * (1 + blur / 200)).toFixed(3));
    mainWrap.style.setProperty('--bg-pos', main.pos || '50% 50%');
    /* Full-screen blur eng og'ir operatsiya: 22px dan oshirilmaydi va 0 bo'lsa butunlay o'chadi */
    mainWrap.style.setProperty('--bg-blur', Math.min(22, blur * .6).toFixed(1) + 'px');
    mainWrap.dataset.blur = blur > 0 ? '1' : '0';
    if (!main.mediaId || main.hide) { mainWrap.innerHTML = ''; }
    else if (bgUrls.main !== main.mediaId + main.type) {
      const url = await media.url(main.mediaId);
      if (url) {
        bgUrls.main = main.mediaId + main.type;
        mainWrap.innerHTML = main.type === 'video'
          ? `<video src="${url}" autoplay muted loop playsinline></video>`
          : `<img src="${url}" alt="">`;
        const v = mainWrap.querySelector('video');
        if (v) v.play && v.play().catch(() => { });
      }
    }
  }
  const dimEl = $('#bgDim');
  if (dimEl) dimEl.style.setProperty('--dim', main.dim / 100);
  if (lockWrap) {
    const lz = Number(lock.zoom) || 100, lb = Number(lock.blur) || 0;
    lockWrap.style.setProperty('--lock-blur', Math.min(22, lb * .6).toFixed(1) + 'px');
    lockWrap.dataset.blur = lb > 0 ? '1' : '0';
    lockWrap.style.setProperty('--lock-dim', (lock.dim || 40) / 100);
    lockWrap.style.setProperty('--lock-zoom', ((lz / 100) * (1 + lb / 200)).toFixed(3));
    lockWrap.style.setProperty('--bg-pos', lock.pos || '50% 50%');
    if (!lock.mediaId) {
      lockWrap.innerHTML = '';
      lockWrap.style.background = '';
    } else if (bgUrls.lock !== lock.mediaId + lock.type) {
      const url = await media.url(lock.mediaId);
      if (url) {
        bgUrls.lock = lock.mediaId + lock.type;
        lockWrap.innerHTML = lock.type === 'video'
          ? `<video src="${url}" autoplay muted loop playsinline></video>`
          : `<img src="${url}" alt="">`;
        const v = lockWrap.querySelector('video');
        if (v) v.play && v.play().catch(() => { });
      }
    }
  }
}

/* ================= NAV ================= */
function navBadge(key) {
  switch (key) {
    case 'cash': return state.accounts.length || '';
    case 'journal': return state.trades.length || '';
    case 'goals': return state.goals.length || '';
    case 'wishlist': return state.wishes.filter((w) => !w.purchased).length || '';
    case 'notes': return state.notes.length || '';
    case 'tasks': { const t = (state.tasks[todayISO()] || []).filter((x) => !x.done).length; return t || ''; }
    case 'music': return state.music.tracks.length || '';
    default: return '';
  }
}
export function buildNav() {
  const nav = state.settings.nav;
  const visible = nav.order.filter((k) => NAV_META[k] && (!nav.hidden.includes(k) || k === 'settings'));
  const sidebar = $('#navList'), mobile = $('#mobileNav');
  if (sidebar) {
    sidebar.innerHTML = SECTIONS.map(([label, keys]) => {
      const items = visible.filter((k) => keys.includes(k));
      if (!items.length) return '';
      return `<div class="nav-sec">${esc(label)}</div>` + items.map((k) => {
        const [name, ic] = NAV_META[k];
        const badge = navBadge(k);
        return `<button class="nav-item ${current.route === k ? 'active' : ''}" data-go="${k}">
          ${icon(ic)}<span class="nav-label">${esc(nav.labels[k] || name)}</span>${badge ? `<span class="nav-badge">${badge}</span>` : ''}</button>`;
      }).join('');
    }).join('') || `<div class="nav-sec">Menyular yashirilgan</div>`;
  }
  if (mobile) {
    mobile.innerHTML = visible.slice(0, 6).map((k) => {
      const [name, ic] = NAV_META[k];
      return `<button class="nav-item ${current.route === k ? 'active' : ''}" data-go="${k}">${icon(ic)}<span>${esc((nav.labels[k] || name).split(' ')[0])}</span></button>`;
    }).join('');
  }
}
export function updateTopbar() {
  const s = state.settings;
  const nw = netWorth();
  const v = $('#netValue');
  if (v) v.textContent = money(nw, { sensitive: true });
  const b = $('#btnHideNet');
  if (b) b.innerHTML = icon(s.hideNetWorth ? 'eye-off' : 'eye');
  const av = $('#avatarMini');
  if (av) {
    if (state.profile.avatar) {
      media.url(state.profile.avatar).then((u) => { if (u) av.innerHTML = `<img src="${u}" alt="">`; });
    } else av.textContent = (state.profile.name || 'K').trim().charAt(0).toUpperCase();
  }
  const brand = $('#sideBrandName'); if (brand) brand.textContent = (state.profile.name || 'KHUMOYUN').toUpperCase();
  const logo = $('#sideLogo'); if (logo) logo.textContent = (state.profile.name || 'K').trim().charAt(0).toUpperCase();
  document.title = `${state.profile.name || 'KHUMOYUN'} · KHUMOYUN OS`;
  const lv = $('#lockVer'); if (lv) lv.textContent = 'v' + BUILD;
  const lockName = $('#lockName');
  if (lockName) lockName.textContent = (state.profile.name || 'Khumoyun').toUpperCase();
  const lockLogo = $('#lockLogo');
  if (lockLogo) lockLogo.textContent = (state.profile.name || 'K').trim().charAt(0).toUpperCase();
  const sb = $('#btnSound'); if (sb) sb.classList.toggle('accent', !!s.sound);
  const ab = $('#btnAmbient'); if (ab) ab.classList.toggle('soft', ambient.playing);
}

/* ================= FX ================= */
function initFx() {
  /* particles */
  const cv = $('#fxCanvas');
  if (cv) {
    const ctx = cv.getContext('2d');
    let parts = [], W = 0, H = 0;
    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = cv.width = innerWidth * dpr; H = cv.height = innerHeight * dpr;
      cv.style.width = innerWidth + 'px'; cv.style.height = innerHeight + 'px';
      const n = Math.min(70, Math.max(24, Math.round((innerWidth * innerHeight) / 34000)));
      parts = Array.from({ length: n }, () => ({
        x: Math.random() * W, y: Math.random() * H, r: (Math.random() * 2.2 + .7) * dpr,
        vx: (Math.random() - .5) * .22 * dpr, vy: (Math.random() - .5) * .22 * dpr, a: Math.random() * .5 + .12,
      }));
    };
    resize();
    window.addEventListener('resize', debounce(resize, 250));
    /* MUHIM: getComputedStyle va fillStyle parsing har freymda chaqirilmasin —
       rang bir marta o'qiladi (tema o'zgarganda yangilanadi). Bu 60fps uchun katta yutuq. */
    let col = '#22e07a', colDirty = true;
    const readAccent = () => { colDirty = true; };
    window.addEventListener('kx:theme', readAccent);
    window.addEventListener('kwttheme', readAccent);
    let wasActive = true, idleFrames = 0;
    const loop = () => {
      requestAnimationFrame(loop);
      if (document.hidden) return;                    /* fon oynada resurs tejaladi */
      const active = !document.body.classList.contains('lowfx') && !!state.settings.effects.particles;
      if (!active) {
        if (wasActive) { ctx.clearRect(0, 0, W, H); wasActive = false; }
        idleFrames++;
        if (idleFrames % 30 === 0) readAccent();      /* o'chiq holatda ham temasiz qolmaymiz */
        return;
      }
      wasActive = true; idleFrames = 0;
      if (colDirty) { col = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#22e07a'; colDirty = false; }
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = col;                            /* bir marta — tsikl ichida emas */
      for (let i = 0; i < parts.length; i++) {
        const pt = parts[i];
        pt.x += pt.vx; pt.y += pt.vy;
        if (pt.x < 0) pt.x = W; else if (pt.x > W) pt.x = 0;
        if (pt.y < 0) pt.y = H; else if (pt.y > H) pt.y = 0;
        ctx.globalAlpha = pt.a * .55;
        ctx.beginPath(); ctx.arc(pt.x, pt.y, pt.r, 0, 6.28318);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    };
    loop();
  }
  /* ripples */
  document.addEventListener('pointerdown', (e) => {
    if (!state.settings.effects.ripple) return;
    if (e.target.closest('.modal, .lock, .splash')) return;
    ripple(e.clientX, e.clientY);
  });
  /* ---- cursor glow + card tilt ----
     Ilgari ikki alohida mousemove tinglovchisi bor edi va har harakatda barcha
     .tilt elementlar bo'ylab yurib, getBoundingClientRect (layout o'qish) qilardi.
     Endi: bitta rAF navbatga qo'yish, rect faqat karta O'ZGARGANDA o'qiladi. */
  const cur = $('#fxCursor');
  let mx = innerWidth / 2, my = innerHeight / 2, fxRaf = 0, tiltCard = null, tiltRect = null;
  const paintFx = () => {
    fxRaf = 0;
    if (cur) cur.style.transform = 'translate3d(' + mx + 'px,' + my + 'px,0) translate(-50%,-50%)';
    if (tiltCard && tiltRect) {
      const px = (mx - tiltRect.left) / tiltRect.width - .5;
      const py = (my - tiltRect.top) / tiltRect.height - .5;
      tiltCard.style.transform = 'perspective(1100px) rotateY(' + (px * 3).toFixed(2) + 'deg) rotateX(' + (-py * 3).toFixed(2) + 'deg) translate3d(0,-2px,0)';
    }
  };
  const queueFx = () => { if (!fxRaf) fxRaf = requestAnimationFrame(paintFx); };
  const clearTilt = () => {
    if (tiltCard) { tiltCard.classList.remove('tilt'); tiltCard.style.transform = ''; }
    tiltCard = null; tiltRect = null;
  };
  document.addEventListener('mousemove', (e) => {
    mx = e.clientX; my = e.clientY;
    const canTilt = state.settings.effects.tilt && innerWidth >= 900 && !!e.target.closest;
    const card = canTilt ? e.target.closest('.tile, .card.lift') : null;
    if (card !== tiltCard) {                 /* layout o'qish FAQAT shu yerda */
      clearTilt();
      if (card) { tiltCard = card; tiltRect = card.getBoundingClientRect(); card.classList.add('tilt'); }
    }
    queueFx();
  }, { passive: true });
  /* sahifa aylantirilsa karta koordinatalari eskiradi — tilt tozalanadi */
  window.addEventListener('scroll', () => { if (tiltCard) clearTilt(); }, { passive: true });
  document.addEventListener('mouseleave', clearTilt);
  /* global click sound + delegation */
  document.addEventListener('click', (e) => {
    const t = e.target.closest('.btn, .tile, .nav-item, .tab, .chip, .key, .cal-day, .icon-btn, .theme-swatch, .item');
    if (t && !t.hasAttribute('data-nosfx')) sfx('click');
  }, true);
  document.addEventListener('mouseover', throttle((e) => {
    const t = e.target.closest('.btn.primary, .tile, .nav-item');
    if (t && !t.dataset.hovered) { t.dataset.hovered = '1'; sfx('hover'); setTimeout(() => { delete t.dataset.hovered; }, 700); }
  }, 120));
  /* global route delegation */
  document.addEventListener('click', (e) => {
    const g = e.target.closest('[data-go]');
    if (g) { go(g.dataset.go); return; }
  });
}

/* ================= LOCK SCREEN ================= */
const lockState = { mode: 'unlock', step: 1, pin: '', first: '', len: 4 };
/* Klaviatura: 1–9, 0 va o'chirish. Tasdiqlash (✓) tugmasi YO'Q — kod to'liq
   kiritilganda tizim o'zi ochiladi. */
function keypadHTML() {
  /* 1–9, 0 va o'chirish (⌫). Tasdiqlash (enter/✓) tugmasi YO'Q —
     kod to'liq kiritilganda tizim o'zi ochiladi. */
  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'sp', '0', 'del'];
  return keys.map((k) => {
    if (k === 'sp') return `<span class="key-sp" aria-hidden="true"></span>`;
    if (k === 'del') return `<button class="key act del" data-key="del" title="O'chirish (backspace)" aria-label="O'chirish">${icon('x')}</button>`;
    return `<button class="key" data-key="${k}" aria-label="${k}">${k}</button>`;
  }).join('');
}
function pinLength() {
  if (lockState.mode === 'setup') return lockState.step === 2 ? (lockState.first || '').length || lockState.len : lockState.len;
  const stored = Number(state.security.pinLen);
  return stored >= 4 && stored <= 6 ? stored : 0;   // 0 = uzunlik noma'lum (eski ma'lumot)
}
function lenChipsHTML() {
  if (lockState.mode !== 'setup' || lockState.step !== 1) return '';
  return `<div class="pin-len"><span>Kod uzunligi</span>
    ${[4, 5, 6].map((n) => `<button class="${lockState.len === n ? 'on' : ''}" data-pinlen="${n}">${n}</button>`).join('')}</div>`;
}
function renderPinUi() {
  const len = Math.max(4, Math.min(6, pinLength() || 6));
  $('#pinDots').innerHTML = Array.from({ length: len }).map((_, i) =>
    `<span class="dot ${i < lockState.pin.length ? 'full' : ''}"></span>`).join('');
  const lenBox = $('#pinLen');
  if (lenBox) lenBox.innerHTML = lenChipsHTML();
  $('#lockTitle').textContent = lockState.mode === 'setup'
    ? (lockState.step === 1 ? 'PIN kod o\'rnating' : 'PIN kodni tasdiqlang')
    : 'PIN kodni kiriting';
  $('#lockSub').textContent = lockState.mode === 'setup'
    ? (lockState.step === 1 ? 'Kod uzunligini tanlang va raqamlarni kiriting' : 'Xuddi shu kodni qayta kiriting — tizim o\'zi ochiladi')
    : 'Tizim qulflangan · kod to\'liq kiritilganda avtomatik ochiladi';
  const back = $('#lockBack');
  if (back) back.hidden = lockState.mode === 'setup' ? lockState.step === 1 : true;
}
function lockShake(msg) {
  const lock = $('#lock');
  lock.classList.add('shake');
  sfx('error');
  $('#lockHint').textContent = msg || (state.security.hint ? 'Eslatma: ' + state.security.hint : 'PIN kod xato');
  setTimeout(() => lock.classList.remove('shake'), 520);
  lockState.pin = '';
  setTimeout(renderPinUi, 320);
}
async function submitPin() {
  if (lockState.pin.length < 4) { lockShake('Kamida 4 xona kerak'); return; }
  if (lockState.mode === 'setup' && lockState.step === 1 && lockState.pin.length < lockState.len) { lockShake(`Kod ${lockState.len} xonali bo'lishi kerak`); return; }
  if (lockState.mode === 'setup') {
    if (lockState.step === 1) {
      lockState.first = lockState.pin; lockState.pin = ''; lockState.step = 2;
      sfx('tap'); renderPinUi(); $('#lockHint').textContent = 'Yaxshi! Endi takrorlang'; return;
    }
    if (lockState.pin !== lockState.first) { lockShake('PIN lar mos kelmadi, qaytadan'); lockState.step = 1; lockState.first = ''; return; }
    await setPin(lockState.pin);   // pinLen ham saqlanadi
    state.security.changedAt = new Date().toISOString(); saveNow();
    sfx('success');
    toast('PIN kod o\'rnatildi', { type: 'success' });
    unlockSuccess();
    return;
  }
  const ok = await verifyPin(lockState.pin);
  if (!ok) { lockShake(); return; }
  unlockSuccess();
}
function pushKey(k) {
  if (k === 'del') { lockState.pin = lockState.pin.slice(0, -1); sfx('tick'); renderPinUi(); return; }
  if (lockState.pin.length >= 6) return;
  lockState.pin += k; sfx('tap'); renderPinUi();
  const need = pinLength();
  if (!need) {
    // Eski PIN (uzunligi noma'lum): har 4+ raqamdan keyin jimgina tekshiramiz
    if (lockState.pin.length >= 4) verifyPin(lockState.pin).then((ok) => { if (ok) unlockSuccess(); });
    return;
  }
  if (lockState.pin.length >= need) submitPin();   // to'liq kiritildi → avtomatik ochiladi
}
export function openLock(mode) {
  lockState.mode = mode || (state.security.pinHash ? 'unlock' : 'setup');
  lockState.step = 1; lockState.pin = ''; lockState.first = '';
  const lock = $('#lock');
  lock.hidden = false;
  $('#keypad').innerHTML = keypadHTML();
  lockState.len = (Number(state.security.pinLen) >= 4 && Number(state.security.pinLen) <= 6) ? Number(state.security.pinLen) : 4;
  const name = (state.profile.name || 'Khumoyun');
  $('#lockName').textContent = name.toUpperCase();
  $('#lockLogo').textContent = name.trim().charAt(0).toUpperCase();
  const h = new Date().getHours();
  $('#lockGreet').textContent = h < 6 ? 'Xayrli tun' : h < 12 ? 'Xayrli tong' : h < 18 ? 'Xayrli kun' : 'Xayrli kech';
  $('#lockHint').textContent = state.security.pinHash && state.security.hint ? 'Eslatma: ' + state.security.hint : '';
  renderPinUi();
  updateClock();
  if (!lock.dataset.bound) {
    lock.dataset.bound = '1';
    on(lock, 'click', '[data-key]', (e, b) => pushKey(b.dataset.key));
    on(lock, 'click', '[data-pinlen]', (e, b) => {
      lockState.len = Number(b.dataset.pinlen) || 4;
      lockState.pin = ''; lockState.first = ''; lockState.step = 1;
      sfx('tap'); renderPinUi();
    });
    $('#lockBack').addEventListener('click', () => { lockState.step = 1; lockState.pin = ''; lockState.first = ''; renderPinUi(); sfx('close'); });
    $('#lockHintBtn').addEventListener('click', () => {
      toast(state.security.hint ? 'Eslatma: ' + state.security.hint : 'Eslatma o\'rnatilmagan. Sozlamalar → Xavfsizlik bo\'limida qo\'shishingiz mumkin.', { type: 'info', ms: 4200 });
    });
  }
}
function updateClock() {
  const el = $('#lockClock'); if (!el) return;
  const d = new Date();
  el.textContent = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}
setInterval(() => { if (!$('#lock').hidden) updateClock(); }, 10000);

function unlockSuccess() {
  sfx('unlock');
  sessionStorage.setItem('kwt.unlocked', '1');
  $('#lock').hidden = true;
  if (state.settings.ambient && !ambient.playing) ambient.start();
  showSplash(() => {});
  $('#app').hidden = false;
  renderCurrent({ first: true });
  resetIdle();
}
export function lockNow() {
  if (!state.security.pinHash) { toast('Avval PIN kod o\'rnatasiz', { type: 'warn' }); go('settings', { tab: 'security' }); return; }
  sfx('lock');
  modal.closeAll();
  openLock('unlock');
}

/* ================= SPLASH ================= */
function showSplash(done) {
  const sp = $('#splash');
  const name = (state.profile.name || 'Khumoyun').trim().toUpperCase();
  const text = `WELCOME ${name}`;
  $('#splashWord').innerHTML = text.split('').map((ch, i) =>
    `<span class="l" style="animation-delay:${(i * 0.055).toFixed(2)}s">${ch === ' ' ? '&nbsp;' : esc(ch)}</span>`).join('');
  const h = new Date().getHours();
  $('#splashSub').textContent = `${h < 12 ? 'Xayrli tong' : h < 18 ? 'Xayrli kun' : 'Xayrli kech'} · tizimga xush kelibsiz`;
  sp.hidden = false;
  sfx('boot');
  setTimeout(() => {
    sp.style.transition = 'opacity .5s, transform .5s';
    sp.style.opacity = '0'; sp.style.transform = 'scale(1.04)';
    setTimeout(() => { sp.hidden = true; sp.style.opacity = ''; sp.style.transform = ''; done && done(); }, 480);
  }, 2200);
}

/* ================= IDLE AUTO-LOCK ================= */
function resetIdle() {
  clearTimeout(idleTimer);
  const mins = Number(state.security.autoLock) || 0;
  if (!mins || !state.security.pinHash) return;
  idleTimer = setTimeout(() => {
    if (!$('#lock').hidden) return;
    sfx('lock');
    openLock('unlock');
  }, mins * 60000);
}
['mousemove', 'keydown', 'click', 'touchstart'].forEach((ev) =>
  document.addEventListener(ev, throttle(resetIdle, 4000)));

/* ================= ROUTER ================= */
function parseHash() {
  const raw = location.hash.replace(/^#\/?/, '');
  const [path, qs] = raw.split('?');
  return { route: path || 'dashboard', query: new URLSearchParams(qs || '') };
}
let relaunchResolvers = [];
export function go(route, params) {
  const qs = params ? new URLSearchParams(Object.entries(params).filter(([, v]) => v != null && v !== '')).toString() : '';
  const h = '#/' + route + (qs ? '?' + qs : '');
  if (location.hash === h) return renderCurrent({ keepScroll: false });
  location.hash = h;
  return new Promise((res) => { relaunchResolvers.push(res); });
}
function playTransition() {
  const t = $('#viewTransition');
  if (!t) return;
  t.classList.remove('run');
  void t.offsetWidth;
  t.classList.add('run');
  setTimeout(() => t.classList.remove('run'), 700);
}
export async function renderCurrent(opts = {}) {
  const { route, query } = parseHash();
  const nav = state.settings.nav;
  let r = VIEWS[route] ? route : 'dashboard';
  if (nav.hidden.includes(r) && opts.force !== true) r = 'dashboard';
  if (r !== 'dashboard' && r !== 'music') { }
  current = { route: r, query };
  if (!opts.first) playTransition();
  /* #view tugunini har safar yangisiga almashtiramiz: eski sahifalarning
     delegatsiyalangan listener'lari (masalan [data-tab], [data-act]) qolib
     ketmaydi. Aks holda ular boshqa sahifalarda ham ishga tushib, masalan
     Sozlamalar tabini bosganda Cash bo'limiga o'tib ketardi. */
  const oldView = $('#view');
  const view = document.createElement('main');
  view.id = 'view';
  view.className = oldView.className;
  view.tabIndex = -1;
  oldView.replaceWith(view);
  const keepScroll = opts.keepScroll ? window.scrollY : 0;
  modal.closeAll();
  const ctx = {
    route: r, query,
    go, applyUi, lockNow,
    refresh: (o) => renderCurrent({ keepScroll: true, ...(o || {}) }),
    refreshNoScroll: () => renderCurrent({ keepScroll: false }),
  };
  window.__ctx = ctx;
  try {
    await VIEWS[r].render(view, ctx);
  } catch (err) {
    console.error('Render xatosi:', err);
    view.innerHTML = `<div class="empty">${icon('bell')}<div class="empty-title">Sahifani yuklashda xatolik</div>
      <div class="tiny">${esc(err.message)}</div><div class="row" style="gap:8px;margin-top:10px">
      <button class="btn primary sm" data-go="dashboard">Bosh sahifa</button></div></div>`;
  }
  await fillMedia(view);
  barFill(view);
  $$('.nav-item').forEach((el) => el.classList.toggle('active', el.dataset.go === r));
  buildNav();
  updateTopbar();
  $$('.app.nav-open').forEach((el) => el.classList.remove('nav-open'));
  if (!opts.silentScroll) window.scrollTo({ top: keepScroll, behavior: 'auto' });
  relaunchResolvers.splice(0).forEach((res) => res());
  resetIdle();
}
window.addEventListener('hashchange', () => renderCurrent({ keepScroll: false }));

/* ================= TOPBAR / SHELL BINDINGS ================= */
function bindShell() {
  const hide = $('#btnHideNet');
  if (hide) hide.addEventListener('click', () => {
    state.settings.hideNetWorth = !state.settings.hideNetWorth; save();
    sfx(state.settings.hideNetWorth ? 'lock' : 'unlock');
    toast(state.settings.hideNetWorth ? 'Net Worth yashirildi' : 'Net Worth ko\'rsatildi', { type: 'info', ms: 1500 });
    updateTopbar(); renderCurrent({ keepScroll: true });
  });
  const search = $('#topSearch');
  if (search) {
    search.value = '';
    search.addEventListener('input', debounce(() => {
      const v = search.value.trim();
      if (!v) return;
      go('search', { q: v });
    }, 380));
    search.addEventListener('keydown', (e) => { if (e.key === 'Enter') go('search', { q: search.value.trim() }); });
  }
  const quick = $('#btnQuick');
  if (quick) quick.addEventListener('click', openQuickAdd);
  const themeBtn = $('#btnThemeQuick');
  if (themeBtn) themeBtn.addEventListener('click', () => {
    const idx = THEMES.findIndex((t) => t[0] === state.settings.theme);
    const next = THEMES[(idx + 1) % THEMES.length];
    state.settings.theme = next[0]; save();
    document.documentElement.dataset.theme = next[0];
    sfx('success'); toast(`Mavzu: ${next[1]}`, { type: 'success', ms: 1600 });
  });
  const prof = $('#btnProfile');
  if (prof) prof.addEventListener('click', () => go('settings', { tab: 'profile' }));
  const snd = $('#btnSound');
  if (snd) snd.addEventListener('click', () => {
    state.settings.sound = !state.settings.sound; sound.on = state.settings.sound; saveNow();
    snd.classList.toggle('accent', state.settings.sound);
    if (state.settings.sound) sfx('success');
    toast(state.settings.sound ? 'Ovoz yoqildi' : 'Ovoz o\'chirildi', { type: 'info', ms: 1400 });
  });
  const amb = $('#btnAmbient');
  if (amb) amb.addEventListener('click', () => {
    const on = ambient.toggle(); state.settings.ambient = on; save();
    amb.classList.toggle('soft', on);
    toast(on ? 'Ambient ovoz yoqildi' : 'Ambient ovoz o\'chirildi', { type: 'info', ms: 1500 });
  });
  const lockBtn = $('#btnLockNow');
  if (lockBtn) lockBtn.addEventListener('click', lockNow);
  const collapse = $('#sideCollapse');
  if (collapse) collapse.addEventListener('click', () => { $('#app').classList.toggle('collapsed'); sfx('tap'); });
  const menuBtn = $('#btnMenu');
  if (menuBtn) menuBtn.addEventListener('click', () => {
    const app = $('#app');
    app.classList.toggle('nav-open');
    if (app.classList.contains('nav-open')) {
      const bd = document.createElement('div');
      bd.className = 'nav-backdrop';
      bd.addEventListener('click', () => { app.classList.remove('nav-open'); bd.remove(); });
      document.body.appendChild(bd);
      setTimeout(() => bd.remove(), 8000);
    }
    sfx('nav');
  });
  document.addEventListener('click', (e) => {
    const bd = e.target.closest('.nav-backdrop');
    if (bd) { $('#app').classList.remove('nav-open'); bd.remove(); }
  });
}

/* ================= QUICK ADD ================= */
function openQuickAdd() {
  const items = [
    ['Trading — yangi trad', 'chart', () => vJournal.openTradeForm(null, getCtx())],
    ['Kirim (daromad)', 'download', () => vCash.openTxForm('income', null, getCtx())],
    ['Chiqim (xarajat)', 'upload', () => vCash.openTxForm('expense', null, getCtx())],
    ['O\'tkazma', 'swap', () => vCash.openTxForm('transfer', null, getCtx())],
    ['Hisob qo\'shish', 'wallet', () => vCash.openAccountForm(null, getCtx())],
    ['Maqsad qo\'shish', 'target', () => vGoals.openGoalForm(null, getCtx())],
    ['Wishlist — xohish', 'star', () => vGoals.openWishForm(null, getCtx())],
    ['Izoh yozish', 'note', () => vLife.openNoteForm(null, getCtx())],
    ['Kunlik vazifa', 'check', () => vLife.openTaskForm(null, todayISO(), getCtx())],
    ['Musiqa jildi', 'folder', () => vMusic.openFolderForm(null, getCtx())],
    ['Musiqa yuklash (mp3)', 'music', async () => {
      const files = await pickFiles('audio/*,.mp3,.wav,.m4a,.flac,.ogg');
      if (files.length) vMusic.importTracks(files, null, getCtx());
    }],
  ];
  const m = modal.open({
    title: 'Tezkor qo\'shish', icon: 'sparkles', size: 'small',
    body: `<div class="col" style="gap:8px">${items.map(([label, ic], i) =>
      `<button class="item" data-i="${i}" style="cursor:pointer;text-align:left;width:100%">
        <div class="avatar sm">${icon(ic)}</div><div class="item-main"><div class="item-title">${esc(label)}</div></div>${icon('right')}</button>`).join('')}</div>`,
  });
  on(m.root, 'click', '[data-i]', (e, b) => { const it = items[Number(b.dataset.i)]; m.close(); setTimeout(() => it[2](), 120); });
}
function getCtx() { return window.__ctx || { go, refresh: () => renderCurrent({ keepScroll: true }), applyUi, lockNow, route: current.route, query: current.query }; }

/* ================= KEYBOARD ================= */
function bindKeys() {
  document.addEventListener('keydown', (e) => {
    const tag = (e.target.tagName || '').toLowerCase();
    const typing = tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable;
    if (e.key === 'Escape' && $('#app').classList.contains('nav-open')) { $('#app').classList.remove('nav-open'); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      (async () => {
        toast('Zaxira nusxa tayyorlanmoqda…', { type: 'info', ms: 2000 });
        try {
          const res = await exportAll();
          download(res.blob, `khumoyun-os-zaxira-${todayISO()}.zip`);
          toast(`Zaxira yuklandi (${humanSize(res.size)})`, { type: 'success', ms: 3200 });
        } catch (err) { toast('Xatolik: ' + err.message, { type: 'error' }); }
      })();
      return;
    }
    if (typing) return;
    if (!($('#lock').hidden) || !($('#splash').hidden)) return;
    if (e.key === '/') { e.preventDefault(); const s = $('#topSearch'); if (s && innerWidth > 900) { s.focus(); } else go('search'); return; }
    if (e.key.toLowerCase() === 'n') { e.preventDefault(); openQuickAdd(); return; }
    if (e.key.toLowerCase() === 'l') { lockNow(); return; }
    if (e.key === ' ' || e.key.toLowerCase() === 'm') {
      const c = vMusic.player.current() || state.music.tracks[0];
      if (c && (!typing)) { e.preventDefault(); if (vMusic.player.current()) vMusic.player.toggle(); else vMusic.player.load(c.id); }
      return;
    }
    if (/^[1-9]$/.test(e.key)) {
      const nav = state.settings.nav;
      const visible = nav.order.filter((k) => NAV_META[k] && (!nav.hidden.includes(k) || k === 'settings'));
      const r = visible[Number(e.key) - 1];
      if (r) go(r);
    }
  });
}

/* ================= SERVICE WORKER / OFFLINE ================= */
let offlineToastShown = false;
function setOnlineState() {
  const on = navigator.onLine !== false;
  const meta = $('#sideMeta');
  if (meta) meta.innerHTML = `v${BUILD} · ` + (on ? '<span class="accent">online</span>' : '<span class="up">offline rejim</span>');
  const chip = $('#netChip');
  if (chip) chip.classList.toggle('offline', !on);
  if (!on && !offlineToastShown) { offlineToastShown = true; toast('Internet yo\'q — tizim offline rejimda ishlaydi', { type: 'info', ms: 3200 }); }
  if (on) offlineToastShown = false;
}
function registerSW() {
  window.addEventListener('online', setOnlineState);
  window.addEventListener('offline', setOnlineState);
  setOnlineState();
  if (!('serviceWorker' in navigator)) return;
  if (location.protocol === 'file:') return;
  /* Yakka fayl (single-file) nusxada SW bo'lmaydi — window.__NO_SW bilan o'chiriladi */
  if (window.__NO_SW) { setInterval(checkUpdate, 5 * 60 * 1000); return; }
  navigator.serviceWorker.register(`./sw.js?v=${BUILD}`, { scope: './', updateViaCache: 'none' }).then((reg) => {
    console.log('[KHUMOYUN OS] Service Worker tayyor — offline rejim yoqilgan');
    try { reg.update(); } catch (e) { }
    navigator.serviceWorker.ready.then(() => {
      if (!sessionStorage.getItem('kwt.sw.ready')) {
        sessionStorage.setItem('kwt.sw.ready', '1');
        toast('Offline rejim tayyor — internetsiz ham ishlaydi ✔', { type: 'success', ms: 3600 });
      }
    });
    reg.addEventListener('updatefound', () => {
      const nw = reg.installing;
      if (!nw) return;
      nw.addEventListener('statechange', () => {
        if (nw.state === 'installed' && navigator.serviceWorker.controller) showUpdateBar('Yangi versiya tayyor');
      });
    });
  }).catch((err) => console.warn('SW ro\'yxatga olinmadi:', err.message));
  /* Yangi SW nazoratni olganda bir marta avtomatik yangilanamiz */
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (sessionStorage.getItem('kwt.sw.reloaded')) return;
    sessionStorage.setItem('kwt.sw.reloaded', '1');
    location.reload();
  });
  /* brauzer xotirani tozalab yubormasligi uchun doimiy saqlash ruxsati */
  try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => { }); } catch (e) { }
  setInterval(checkUpdate, 5 * 60 * 1000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) checkUpdate(); });
}

/* ---------- YANGILANISHNI TEKSHIRISH ----------
   Agar serverda boshqa build bo'lsa — pastda "Yangilash" paneli chiqadi.
   Bu service worker keshi "yopishib" qolgan holatlarni ham tuzatadi.  */
export function showUpdateBar(text) {
  const bar = $('#updateBar');
  if (!bar || !bar.hidden) return;
  const t = bar.querySelector('[data-update-text]');
  if (t && text) t.textContent = text;
  bar.hidden = false;
  requestAnimationFrame(() => bar.classList.add('on'));
}
export async function checkUpdate() {
  if (window.__NO_SW) return false;      // yakka fayl nusxada version.json yo'q
  try {
    const r = await fetch(`./version.json?_=${Date.now()}`, { cache: 'no-store' });
    if (!r.ok) return false;
    const j = await r.json();
    if (j && j.version && j.version !== BUILD) { showUpdateBar(`Yangi versiya mavjud: v${j.version}`); return true; }
  } catch (e) { }
  return false;
}
/* To'liq tozalash: SW + barcha keshlar olib tashlanadi va sahifa yangilanadi */
export async function hardRefresh() {
  try {
    toast('Kesh tozalanmoqda…', { type: 'info', ms: 1800 });
    if ('serviceWorker' in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map((r) => r.unregister().catch(() => { })));
    }
    if (window.caches) {
      const keys = await caches.keys();
      await Promise.all(keys.map((k) => caches.delete(k)));
    }
    sessionStorage.removeItem('kwt.sw.ready');
    sessionStorage.removeItem('kwt.sw.reloaded');
  } catch (e) { }
  const url = new URL(location.href);
  url.searchParams.set('_v', Date.now().toString(36));
  location.replace(url.toString());
}

/* ================= ISHLASH REJIMI (performance) =================
   Kuchsiz kompyuterlarda og'ir effektlar (aurora, zarrachalar, kuchli blur)
   avtomatik yengillashtiriladi — sayt "sekinlashib/muzlab" qolmaydi.      */
export function applyPerfMode() {
  const p = state.settings.perf || 'auto';
  const on = p === 'lite' || (p !== 'full' && !!state.settings.lowfx);
  document.body.classList.toggle('lowfx', on);
  return on;
}
export function runPerfCheck() {
  const p = state.settings.perf || 'auto';
  if (p === 'full') { state.settings.lowfx = false; save(); applyPerfMode(); return; }
  if (p === 'lite') { state.settings.lowfx = true; save(); applyPerfMode(); return; }
  let frames = 0; const t0 = performance.now();
  const tick = () => {
    frames++;
    const dt = performance.now() - t0;
    if (dt < 1800) { requestAnimationFrame(tick); return; }
    const fps = frames / (dt / 1000);
    const slow = fps < 42;
    const changed = slow !== !!state.settings.lowfx;
    state.settings.lowfx = slow; save();
    applyPerfMode();
    if (slow && changed && !sessionStorage.getItem('kwt.lowfx.toast')) {
      sessionStorage.setItem('kwt.lowfx.toast', '1');
      toast('Yengil rejim yoqildi (qurilma sekin) — effektlar kamaytirildi. Sozlamalar → Ko\'rinish bo\'limida o\'zgartirasiz', { type: 'info', ms: 5000 });
    }
  };
  requestAnimationFrame(tick);
}

/* ================= UPDATE PANEL ================= */
function bindUpdateBar() {
  const go = $('#btnUpdateGo');
  if (go) go.addEventListener('click', () => { sfx('success'); hardRefresh(); });
  const later = $('#btnUpdateLater');
  if (later) later.addEventListener('click', () => {
    const bar = $('#updateBar');
    bar.classList.remove('on'); setTimeout(() => { bar.hidden = true; }, 420); sfx('close');
  });
  setTimeout(checkUpdate, 2200);
}

/* ================= BOOT ================= */
async function boot() {
  load();
  applyUi();
  initFx();
  bindShell();
  bindKeys();
  vMusic.player.init();
  vMusic.bindPlayer();
  updateTopbar();
  buildNav();
  ensureSnapshot();
  registerSW();
  bindUpdateBar();
  subscribe(() => { updateTopbar(); });
  setTimeout(() => { try { runPerfCheck(); } catch (e) { } }, 1500);
  const lastTheme = state.settings.theme;
  if (lastTheme) document.documentElement.dataset.theme = lastTheme;
  document.documentElement.dataset.preset = state.settings.preset || 'glass';
  if (!state.security.pinHash) {
    $('#app').hidden = false;
    openLock('setup');
    return;
  }
  if (state.settings.sound) sound.on = true;
  if (state.security.lockOnStart !== false) {
    openLock('unlock');
  } else {
    $('#app').hidden = false;
    showSplash();
    renderCurrent({ first: true });
  }
}
/* MUHIM: boot FAQAT BIR MARTA chaqirilishi kerak.
   Ilgari ham DOMContentLoaded, ham readyState tekshiruvi ishlab, boot ikki marta
   bajarilardi — natijada barcha tugmalar ikki marta bog'lanib, o'zgarishlar
   (masalan, Net Worth yashirish, ovoz yoqish) darhol bekor bo'lardi. */
if (document.readyState === 'loading') window.addEventListener('DOMContentLoaded', boot, { once: true });
else boot();

window.addEventListener('beforeunload', () => { try { saveNow(); } catch (e) { } });
window.addEventListener('error', (e) => {
  if (e.message && /ResizeObserver/.test(e.message)) return;
  console.warn('Xatolik:', e.message);
});
export { showSplash };
