/* ============================================================
   KHUMOYUN OS — lightweight animated canvas charts
   ============================================================ */
function setup(canvas, h) {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const w = canvas.parentElement ? canvas.parentElement.clientWidth : canvas.clientWidth;
  const height = Number(h) || Number(canvas.dataset.h) || 220;
  canvas.width = Math.max(120, Math.floor(w * dpr));
  canvas.height = Math.floor(height * dpr);
  canvas.style.height = height + 'px';
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { ctx, w, h: height };
}
function cssVar(name, fallback) {
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || fallback;
}
function hexA(color, a) {
  const c = color.trim();
  if (c.startsWith('#')) {
    const n = c.length === 4 ? c.replace(/#(.)(.)(.)/, '#$1$1$2$2$3$3') : c;
    const r = parseInt(n.slice(1, 3), 16), g = parseInt(n.slice(3, 5), 16), b = parseInt(n.slice(5, 7), 16);
    return `rgba(${r},${g},${b},${a})`;
  }
  return c;
}
function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

/** series: [{label, values:[..], color, fill:bool}]  labels: [..] */
export function areaChart(canvas, series, labels, opts = {}) {
  if (!canvas) return;
  const draw = () => {
    const { ctx, w, h } = setup(canvas, opts.height);
    if (w < 40) return;
    const padL = opts.padL == null ? 52 : opts.padL, padR = 14, padT = 16, padB = opts.padB == null ? 26 : opts.padB;
    const iw = w - padL - padR, ih = h - padT - padB;
    const all = series.flatMap((s) => s.values).filter((v) => typeof v === 'number');
    let min = Math.min(...all, 0), max = Math.max(...all, 1);
    if (opts.min != null) min = opts.min;
    if (opts.max != null) max = opts.max;
    if (max === min) max = min + 1;
    const n = Math.max(...series.map((s) => s.values.length));
    const xAt = (i) => padL + (n <= 1 ? iw / 2 : (i / (n - 1)) * iw);
    const yAt = (v) => padT + ih - ((v - min) / (max - min)) * ih;
    ctx.clearRect(0, 0, w, h);

    // grid
    ctx.strokeStyle = 'rgba(255,255,255,.07)'; ctx.lineWidth = 1;
    ctx.font = '10.5px Inter, system-ui, sans-serif'; ctx.fillStyle = 'rgba(200,215,230,.55)';
    const rows = opts.rows || 4;
    for (let r = 0; r <= rows; r++) {
      const y = padT + (ih / rows) * r;
      ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(w - padR, y); ctx.stroke();
      const val = max - ((max - min) / rows) * r;
      const txt = opts.fmtY ? opts.fmtY(val) : Math.round(val).toLocaleString('en-US');
      ctx.fillText(txt, 6, y + 3.5);
    }
    // x labels
    if (labels && labels.length) {
      ctx.fillStyle = 'rgba(200,215,230,.5)';
      const step = Math.ceil(labels.length / 7);
      labels.forEach((l, i) => {
        if (i % step) return;
        const x = xAt(i);
        ctx.fillText(String(l), Math.max(padL - 6, Math.min(w - padR - 26, x - 12)), h - 8);
      });
    }

    const anim = opts.animate === false ? 1 : 0;
    const t0 = performance.now(), dur = 900 / (window.__anim || 1);
    const step = (t) => {
      const p = opts.animate === false ? 1 : Math.min(1, (t - t0) / dur);
      const e = easeOut(p);
      ctx.clearRect(0, 0, w, h);
      // grid redraw
      ctx.strokeStyle = 'rgba(255,255,255,.07)';
      ctx.font = '10.5px Inter, system-ui, sans-serif';
      for (let r = 0; r <= rows; r++) {
        const y = padT + (ih / rows) * r;
        ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(w - padR, y); ctx.stroke();
        ctx.fillStyle = 'rgba(200,215,230,.5)';
        const val = max - ((max - min) / rows) * r;
        ctx.fillText(opts.fmtY ? opts.fmtY(val) : Math.round(val).toLocaleString('en-US'), 6, y + 3.5);
      }
      series.forEach((s) => {
        const color = s.color || cssVar('--accent', '#22e07a');
        const cnt = Math.max(1, Math.round(s.values.length * e));
        const pts = s.values.slice(0, cnt).map((v, i) => [xAt(i), yAt(v)]);
        if (!pts.length) return;
        if (s.fill !== false) {
          const grad = ctx.createLinearGradient(0, padT, 0, padT + ih);
          grad.addColorStop(0, hexA(color, .38)); grad.addColorStop(1, hexA(color, 0));
          ctx.beginPath();
          ctx.moveTo(pts[0][0], padT + ih);
          pts.forEach((p) => ctx.lineTo(p[0], p[1]));
          ctx.lineTo(pts[pts.length - 1][0], padT + ih);
          ctx.closePath(); ctx.fillStyle = grad; ctx.fill();
        }
        ctx.beginPath();
        pts.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1]));
        ctx.strokeStyle = color; ctx.lineWidth = 2.6; ctx.lineJoin = 'round'; ctx.shadowColor = hexA(color, .55); ctx.shadowBlur = 12;
        ctx.stroke(); ctx.shadowBlur = 0;
        // last dot
        const last = pts[pts.length - 1];
        ctx.beginPath(); ctx.arc(last[0], last[1], 4.4, 0, Math.PI * 2);
        ctx.fillStyle = color; ctx.fill();
        ctx.beginPath(); ctx.arc(last[0], last[1], 8.5, 0, Math.PI * 2);
        ctx.fillStyle = hexA(color, .22); ctx.fill();
      });
      if (p < 1) requestAnimationFrame(step);
    };
    if (anim === 0) requestAnimationFrame(step); else step(performance.now() + dur);
  };
  draw();
  if (window.ResizeObserver) { const ro = new ResizeObserver(() => { clearTimeout(canvas.__t); canvas.__t = setTimeout(draw, 120); }); ro.observe(canvas.parentElement || canvas); }
  return draw;
}

/** slices: [{label, value, color}] */
export function donut(canvas, slices, opts = {}) {
  if (!canvas) return;
  const draw = () => {
    const size = opts.size || 210;
    const { ctx, w, h } = setup(canvas, size);
    if (w < 40 || h < 40) return;                      // ko'rinmayotgan konteyner
    const cx = w / 2, cy = h / 2;
    const R = Math.max(6, Math.min(w, h) / 2 - 8), r = Math.max(3, R * .62);
    const total = Math.abs(slices.reduce((s, x) => s + (Number(x.value) || 0), 0)) || 1;
    const t0 = performance.now(), dur = 850 / (window.__anim || 1);
    const step = (t) => {
      const e = easeOut(Math.min(1, (t - t0) / dur));
      ctx.clearRect(0, 0, w, h);
      let a = -Math.PI / 2;
      slices.forEach((s, i) => {
        const color = s.color || `hsl(${(i * 61) % 360} 70% 60%)`;
        const span = ((Number(s.value) || 0) / total) * Math.PI * 2 * e;
        if (span <= 0) return;
        ctx.beginPath();
        ctx.arc(cx, cy, Math.max(2, (R + r) / 2), a, a + span);
        ctx.strokeStyle = color; ctx.lineWidth = R - r; ctx.lineCap = 'butt';
        ctx.shadowColor = hexA(color, .4); ctx.shadowBlur = 14;
        ctx.stroke(); ctx.shadowBlur = 0;
        a += span;
      });
      ctx.fillStyle = cssVar('--text', '#eaf1f8');
      ctx.textAlign = 'center';
      ctx.font = '700 12px Inter, system-ui, sans-serif';
      ctx.fillText(opts.label || 'Jami', cx, cy - 6);
      ctx.font = '800 21px Inter, system-ui, sans-serif';
      ctx.fillText(opts.fmt ? opts.fmt(total) : Math.round(total).toLocaleString('en-US'), cx, cy + 16);
      ctx.textAlign = 'left';
      if (e < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };
  draw();
  if (window.ResizeObserver) { const ro = new ResizeObserver(() => { clearTimeout(canvas.__t2); canvas.__t2 = setTimeout(draw, 120); }); ro.observe(canvas.parentElement || canvas); }
  return draw;
}

/** bars: [{label, values:[a,b]}] */
export function barChart(canvas, bars, opts = {}) {
  if (!canvas) return;
  const draw = () => {
    const { ctx, w, h } = setup(canvas, opts.height || 220);
    if (w < 40) return;
    const padL = 52, padR = 14, padT = 14, padB = 30;
    const iw = w - padL - padR, ih = h - padT - padB;
    const max = Math.max(1, ...bars.flatMap((b) => b.values));
    const colors = opts.colors || [cssVar('--accent', '#22e07a'), '#ff6b78'];
    const bw = iw / Math.max(1, bars.length);
    const t0 = performance.now(), dur = 800 / (window.__anim || 1);
    const step = (t) => {
      const e = easeOut(Math.min(1, (t - t0) / dur));
      ctx.clearRect(0, 0, w, h);
      ctx.font = '10.5px Inter, system-ui, sans-serif';
      for (let r = 0; r <= 4; r++) {
        const y = padT + (ih / 4) * r;
        ctx.strokeStyle = 'rgba(255,255,255,.06)';
        ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(w - padR, y); ctx.stroke();
        ctx.fillStyle = 'rgba(200,215,230,.5)';
        ctx.fillText(Math.round(max - (max / 4) * r).toLocaleString('en-US'), 6, y + 3.5);
      }
      bars.forEach((b, i) => {
        const groupW = bw * .62, cw = groupW / b.values.length;
        b.values.forEach((v, k) => {
          const bh = (v / max) * ih * e;
          const x = padL + i * bw + (bw - groupW) / 2 + k * cw;
          const y = padT + ih - bh;
          ctx.fillStyle = colors[k % colors.length];
          ctx.beginPath();
          const r2 = Math.min(5, cw / 2.4);
          const ww = Math.max(2, cw - 3);
          ctx.roundRect ? ctx.roundRect(x, y, ww, bh, [r2, r2, 0, 0]) : ctx.rect(x, y, ww, bh);
          ctx.fill();
        });
        if (bars.length <= 14) {
          ctx.fillStyle = 'rgba(200,215,230,.5)';
          ctx.fillText(String(b.label).slice(0, 7), padL + i * bw + 4, h - 10);
        }
      });
      if (e < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  };
  draw();
  if (window.ResizeObserver) { const ro = new ResizeObserver(() => { clearTimeout(canvas.__t3); canvas.__t3 = setTimeout(draw, 120); }); ro.observe(canvas.parentElement || canvas); }
  return draw;
}

export function sparkline(canvas, values, color) {
  return areaChart(canvas, [{ values, color, fill: true }], null, { height: Number(canvas?.dataset.h || 60), padL: 4, padB: 6, rows: 0, fmtY: () => '', animate: true });
}
