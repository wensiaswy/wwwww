/* ============================================================
   KHUMOYUN OS — shared view kit (HTML builders)
   ============================================================ */
import { esc, icon, fmtDate, relTime } from './util.js';
import { money } from './store.js';

export const pageHead = ({ title, sub = '', icon: ic = 'sparkles', actions = '', back = '', badge = '' }) => `
  <div class="between sec reveal" style="margin-bottom:16px">
    <div class="row" style="gap:14px;align-items:flex-start">
      ${back ? `<button class="btn icon-only ghost" data-go="${esc(back)}" title="Orqaga">${icon('left')}</button>` : ''}
      <div class="row" style="gap:12px">
        <div class="side-logo" style="width:46px;height:46px;border-radius:15px">${icon(ic)}</div>
        <div>
          <div class="eyebrow">${esc(badge || 'bo\'lim')}</div>
          <h1 class="h1">${esc(title)}</h1>
          ${sub ? `<div class="muted tiny">${esc(sub)}</div>` : ''}
        </div>
      </div>
    </div>
    <div class="sec-actions">${actions}</div>
  </div>`;

export const section = ({ title, icon: ic = '', actions = '', body = '', sub = '' }) => `
  <section class="sec">
    <div class="sec-head">
      <div>
        <div class="sec-title h3">${ic ? icon(ic) : ''}${esc(title)}</div>
        ${sub ? `<div class="tiny faint">${esc(sub)}</div>` : ''}
      </div>
      <div class="sec-actions">${actions}</div>
    </div>
    ${body}
  </section>`;

export const empty = ({ icon: ic = 'sparkles', title = 'Bo\'sh', sub = '', action = '' }) => `
  <div class="empty reveal">${icon(ic)}<div class="empty-title">${esc(title)}</div>
    ${sub ? `<div class="tiny">${esc(sub)}</div>` : ''}${action}</div>`;

export const bar = (pct, cls = 'green') => `
  <div class="progress"><span class="progress-fill ${cls}" data-w="${Math.max(0, Math.min(100, Number(pct) || 0))}"></span></div>`;

export const ring = (pct, size = 68, label = '') => {
  const r = size / 2 - 6, c = 2 * Math.PI * r;
  const p = Math.max(0, Math.min(100, Number(pct) || 0));
  return `<div class="ring" style="width:${size}px;height:${size}px">
    <svg width="${size}" height="${size}">
      <circle class="ring-bg" cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke-width="6"></circle>
      <circle class="ring-fg" cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke-width="6"
        stroke-dasharray="${c}" stroke-dashoffset="${c - (c * p) / 100}"></circle>
    </svg>
    <span class="ring-label">${label || Math.round(p) + '%'}</span></div>`;
};

export const thumb = (id, { ratio = '16:9', pos = '50% 50%', zoom = 100, cls = '', style = '', icon: ic = 'image', children = '' } = {}) =>
  `<div class="thumb ratio-${String(ratio).replace(':', '-')} ${cls}" data-media="${esc(id || '')}" data-zoom="${zoom}" style="--pos:${esc(pos)};${style}">
    ${id ? '' : `<div class="ph">${icon(ic)}</div>`}${children}</div>`;

export const statMini = (k, v, ic = '') => `<div class="stat-mini">${ic ? `<div class="k">${icon(ic)}${esc(k)}</div>` : `<div class="k">${esc(k)}</div>`}<div class="v">${esc(v)}</div></div>`;

export const kpi = ({ label, value, icon: ic = '', delta = null, cls = '' }) => `
  <div class="kpi reveal ${cls}">
    <div class="kpi-label">${ic ? icon(ic) : ''}${esc(label)}</div>
    <div class="kpi-value">${value}</div>
    ${delta ? `<div class="kpi-delta ${delta.dir || ''}">${icon(delta.dir === 'up' ? 'up-arrow' : delta.dir === 'down' ? 'down-arrow' : 'swap')}${esc(delta.text)}</div>` : ''}
  </div>`;

/* kv: kalitlar ichida <span class="kbd"> kabi HTML bo'lishi mumkin — shuning uchun k escape qilinmaydi */
export const kv = (rows) => `<div>${rows.filter(Boolean).map(([k, v]) => `<div class="kv"><span class="k">${k}</span><span class="v">${v}</span></div>`).join('')}</div>`;

export const editBtn = (act, id, title = 'Tahrirlash (qalamcha)') => `<button class="icon-btn" data-act="${esc(act)}" data-id="${esc(id)}" title="${esc(title)}">${icon('pencil')}</button>`;
export const delBtn = (act, id, title = 'O\'chirish') => `<button class="icon-btn danger" data-act="${esc(act)}" data-id="${esc(id)}" title="${esc(title)}">${icon('trash')}</button>`;
export const viewBtn = (act, id, title = 'Batafsil') => `<button class="icon-btn" data-act="${esc(act)}" data-id="${esc(id)}" title="${esc(title)}">${icon('eye')}</button>`;

export const moneyCell = (n, cls = '') => `<span class="num ${cls}">${money(n, { sensitive: true })}</span>`;
export const dateCell = (d) => `<span class="tiny faint">${icon('calendar')} ${esc(d ? fmtDate(d) : '—')}</span>`;

export const stars = (n) => `<span class="stars">${[1, 2, 3, 4, 5].map((i) => `<span class="${i <= (Number(n) || 0) ? 'on' : ''}">${icon('star')}</span>`).join('')}</span>`;

export const tagsRow = (tags) => (Array.isArray(tags) && tags.length ? `<div class="chips">${tags.map((t) => `<span class="badge">${icon('tag')}${esc(t)}</span>`).join('')}</div>` : '');

export const priorityBadge = (p) => {
  const map = { high: ['loss', 'Yuqori'], mid: ['be', 'O\'rta'], low: ['win', 'Past'] };
  const [cls, label] = map[p] || map.mid;
  return `<span class="badge ${cls}">${esc(label)}</span>`;
};
export const resultBadge = (r) => {
  const map = { win: ['win', 'FOYDA'], loss: ['loss', 'ZARAR'], be: ['be', 'BE'], open: ['open', 'OCHIQ'] };
  const [cls, label] = map[r] || map.open;
  return `<span class="badge ${cls}">${esc(label)}</span>`;
};
export const timeAgo = (iso) => `<span class="tiny faint">${esc(relTime(iso))}</span>`;

export const navTile = ({ route, icon: ic, label, sub = '', pinned = false }) => `
  <button class="tile reveal ${pinned ? 'pinned' : ''}" data-go="${esc(route)}">
    <div class="tile-top">${icon(ic)}</div>
    <div class="tile-body">
      <div class="tile-label">${esc(label)}</div>
      <div class="tile-sub">${esc(sub)}</div>
    </div>
  </button>`;

export const addTile = ({ act, label = 'Yangi qo\'shish' }) => `
  <button class="tile add" data-act="${esc(act)}">${icon('plus')}<span class="tiny">${esc(label)}</span></button>`;

export const ratioChips = (active, act) => `<div class="chips">
  ${['16:9', '1:1', '9:16', '4:3', '21:9'].map((r) => `<button class="chip ${r === active ? 'active' : ''}" data-act="${esc(act)}" data-ratio="${r}">${r}</button>`).join('')}
</div>`;
