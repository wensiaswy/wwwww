/* ============================================================
   KHUMOYUN OS — Net Worth / Dashboard
   ============================================================ */
import { $, $$, esc, icon, on, toast, sfx, todayISO, fmtDate, DAYS_UZ, MONTHS_UZ, animateNumber, barFill, countUpAll } from './util.js';
import { state, save, money, netWorth, netWorthDelta, netWorthByType, monthStats, lastMonths, tradeStats, goalProgress, wishProgress, todayStats, streak, ACC_TYPE_LABEL, ACC_TYPE_ICON, activeAccounts } from './store.js';
import { areaChart, donut, sparkline } from './charts.js';
import { pageHead, section, empty, bar, ring, kpi, thumb, statMini, navTile, addTile, resultBadge, moneyCell, tagsRow, priorityBadge } from './kit.js';
import { fillMedia, openForm, SCHEMAS } from './form.js';

let charts = [];

export function destroy() { charts = []; }

export function render(view, ctx) {
  const now = new Date();
  const hour = now.getHours();
  const greet = hour < 6 ? 'Tunda ham ishlayapsizmi' : hour < 12 ? 'Xayrli tong' : hour < 18 ? 'Xayrli kun' : 'Xayrli kech';
  const nw = netWorth();
  const delta = netWorthDelta(30);
  const m = monthStats();
  const ts = tradeStats();
  const hidden = state.settings.hideNetWorth;
  const today = todayISO();
  const tstats = todayStats(today);
  const types = netWorthByType().filter((t) => t.value > 0).sort((a, b) => b.value - a.value);
  const months = lastMonths(6);
  const goals = [...state.goals].sort((a, b) => goalProgress(b).pct - goalProgress(a).pct).slice(0, 4);
  const wishes = [...state.wishes].filter((w) => !w.purchased).sort((a, b) => (Number(b.priority) || 0) - (Number(a.priority) || 0)).slice(0, 3);
  const recentTrades = [...state.trades].sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 5);
  const recentNotes = [...state.notes].sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 3);
  const snap = state.snapshots.map((s) => s.value);
  const accs = activeAccounts().slice(0, 6);

  view.innerHTML = `
  <div class="stagger">
    ${pageHead({
    title: 'Net Worth', icon: 'dash', badge: 'asosiy menyu',
    sub: `${DAYS_UZ[now.getDay()]}, ${now.getDate()} ${MONTHS_UZ[now.getMonth()]} ${now.getFullYear()} · ${greet}, ${state.profile.name}!`,
    actions: `<button class="btn sm" data-act="add-tx" data-type="income">${icon('download')}Kirim</button>
        <button class="btn sm" data-act="add-tx" data-type="expense">${icon('upload')}Chiqim</button>
        <button class="btn sm" data-act="add-account">${icon('wallet')}Hisob</button>
        <button class="btn primary sm" data-act="add-trade">${icon('plus')}Yangi trad</button>`
  })}

    <div class="hero reveal" style="margin-bottom:22px">
      <div class="hero-inner">
        <div class="between">
          <div class="grow">
            <div class="eyebrow">Umumiy sof boylik (Net Worth)</div>
            <div class="hero-value">
              <span id="nwValue" data-count="${nw}" data-fmt="money">${hidden ? '••••••' : money(0)}</span>
              <button class="btn icon-only ghost" data-act="toggle-net" title="Net Worth ni yashirish / ko'rsatish">${icon(hidden ? 'eye-off' : 'eye')}</button>
            </div>
            <div class="row wrap" style="margin-top:10px">
              <span class="badge ${delta.abs >= 0 ? 'win' : 'loss'}">${icon(delta.abs >= 0 ? 'up-arrow' : 'down-arrow')}${esc(money(Math.abs(delta.abs)))} (${delta.pct >= 0 ? '+' : ''}${delta.pct.toFixed(1)}%) · 30 kun</span>
              <span class="badge">${icon('wallet')}${state.accounts.length} hisob</span>
              <span class="badge ${ts.pnl >= 0 ? 'win' : 'loss'}">${icon('chart')}Trading P/L: ${esc(money(ts.pnl))}</span>
              <span class="badge accent">${icon('fire')}${streak()} kunlik seriya</span>
            </div>
          </div>
          <div style="width:min(340px,100%)">
            <div class="chart-wrap"><canvas data-chart="spark" data-h="96"></canvas></div>
            <div class="tiny faint center">Boylik dinamikasi</div>
          </div>
        </div>
      </div>
    </div>

    <div class="kpis" style="margin-bottom:24px">
      ${kpi({ label: 'Bu oy kirim', value: money(m.income), icon: 'download', delta: { dir: 'up', text: 'daromad' } })}
      ${kpi({ label: 'Bu oy chiqim', value: money(m.expense), icon: 'upload', delta: { dir: 'down', text: 'xarajat' } })}
      ${kpi({ label: 'Oy balansi', value: money(m.balance), icon: 'swap', delta: m.balance >= 0 ? { dir: 'up', text: 'foyda' } : { dir: 'down', text: 'zarar' } })}
      ${kpi({ label: 'Jamg\'arma darajasi', value: `${(m.rate || 0).toFixed(1)}%`, icon: 'trend' })}
      ${kpi({ label: 'Trading P/L', value: money(ts.pnl), icon: 'chart', delta: { dir: ts.pnl >= 0 ? 'up' : 'down', text: `Win rate ${ts.winRate.toFixed(0)}% · ${ts.closed} trad` } })}
      ${kpi({ label: 'Bugungi vazifalar', value: `${tstats.done}/${tstats.total}`, icon: 'check', delta: { dir: '', text: `${tstats.pct.toFixed(0)}% bajarildi` } })}
    </div>

    <div class="sec">
      <div class="sec-head">
        <div class="sec-title h3">${icon('grid')}Menyular</div>
        <div class="sec-actions">
          <button class="btn sm ghost" data-go="settings">${icon('sliders')}Menyularni tahrirlash</button>
        </div>
      </div>
      <div class="tiles">
        ${navTile({ route: 'cash', icon: 'wallet', label: 'Cash', sub: `${state.accounts.length} hisob · ${money(nw, { sensitive: true })}` })}
        ${navTile({ route: 'journal', icon: 'chart', label: 'Trading Journal', sub: `${state.trades.length} trad · ${money(ts.pnl)}` })}
        ${navTile({ route: 'goals', icon: 'target', label: 'Maqsadlar', sub: `${state.goals.length} maqsad` })}
        ${navTile({ route: 'wishlist', icon: 'star', label: 'Wishlist', sub: `${state.wishes.length} xohish` })}
        ${navTile({ route: 'notes', icon: 'note', label: 'Izohlar', sub: `${state.notes.length} izoh` })}
        ${navTile({ route: 'tasks', icon: 'calendar', label: 'Vazifalar', sub: `${Object.values(state.tasks).flat().length} vazifa` })}
        ${navTile({ route: 'music', icon: 'music', label: 'Musiqa', sub: `${state.music.tracks.length} trek · ${state.music.folders.length} jild` })}
        ${navTile({ route: 'search', icon: 'search', label: 'Qidiruv', sub: 'Hamma joydan izlash' })}
        ${navTile({ route: 'settings', icon: 'sliders', label: 'Sozlamalar', sub: 'PIN, mavzu, fon, UI' })}
      </div>
    </div>

    <div class="grid g2" style="margin-bottom:24px">
      <div class="card">
        <div class="card-h">
          <div class="card-t">${icon('wallet')}Hisoblar</div>
          <button class="btn sm ghost" data-act="add-account">${icon('plus')}Qo'shish</button>
        </div>
        ${accs.length ? `<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(140px,1fr))">
          ${accs.map((a) => `<button class="card tight lift flat" data-go="cash" style="text-align:left;display:block">
            <div class="row between"><span class="badge">${icon(ACC_TYPE_ICON[a.type] || 'wallet')}${esc(ACC_TYPE_LABEL[a.type] || 'Boshqa')}</span></div>
            <div class="item-title" style="margin-top:8px">${esc(a.name)}</div>
            <div class="num" style="font-weight:800;font-size:16px;margin-top:4px">${money(a.balance, { sensitive: true, currency: a.currency })}</div>
          </button>`).join('')}
        </div>` : empty({ icon: 'wallet', title: 'Hali hisob qo\'shilmagan', sub: 'Naqd pul, bank, kripto yoki aksiyalaringizni kiriting', action: `<button class="btn primary sm" data-act="add-account">${icon('plus')}Hisob qo'shish</button>` })}
      </div>

      <div class="card">
        <div class="card-h">
          <div class="card-t">${icon('grid')}Taquim (allocation)</div>
          <span class="card-sub">${types.length} toifa</span>
        </div>
        ${types.length ? `<div class="row" style="gap:18px;flex-wrap:wrap">
          <div style="width:210px"><div class="chart-wrap"><canvas data-chart="donut"></canvas></div></div>
          <div class="col grow" style="gap:8px">
            ${types.map((t, i) => `<div class="row between">
              <span class="row" style="gap:8px"><i style="display:inline-block;width:10px;height:10px;border-radius:3px;background:hsl(${(i * 62) % 360} 70% 60%)"></i>${esc(t.label)}</span>
              <span class="num"><b>${money(t.value, { sensitive: true })}</b> <span class="tiny faint">${((t.value / (nw || 1)) * 100).toFixed(1)}%</span></span>
            </div>`).join('')}
          </div>
        </div>` : empty({ icon: 'grid', title: 'Ma\'lumot yo\'q', sub: 'Hisob qo\'shsangiz, taqsimot shu yerda ko\'rinadi' })}
      </div>
    </div>

    <div class="grid g2" style="margin-bottom:24px">
      <div class="card">
        <div class="card-h">
          <div class="card-t">${icon('trend')}Oylik cash flow</div>
          <div class="legend"><span><i style="background:var(--accent)"></i>Kirim</span><span><i style="background:#ff6b78"></i>Chiqim</span></div>
        </div>
        <div class="chart-wrap"><canvas data-chart="flow" data-h="300"></canvas></div>
      </div>
      <div class="card">
        <div class="card-h">
          <div class="card-t">${icon('chart')}Trading xulosasi</div>
          <button class="btn sm ghost" data-go="journal">${icon('right')}Jurnal</button>
        </div>
        <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(104px,1fr));gap:8px;margin-bottom:12px">
          ${statMini('Tradlar', String(ts.count), 'list')}
          ${statMini('Win rate', ts.winRate.toFixed(0) + '%', 'target')}
          ${statMini('Avg R', ts.avgR.toFixed(2) + 'R', 'chart')}
          ${statMini('Profit factor', ts.profitFactor.toFixed(2), 'trend')}
          ${statMini('Eng yaxshi', money(ts.best), 'up-arrow')}
          ${statMini('Eng yomon', money(ts.worst), 'down-arrow')}
        </div>
        ${recentTrades.length ? `<div class="list">${recentTrades.map((t) => `<div class="item">
          <div class="avatar sm" style="background:${t.side === 'long' ? 'rgba(60,224,138,.2)' : 'rgba(255,77,94,.2)'};color:${t.side === 'long' ? '#69f0a8' : '#ff9aa4'}">${t.side === 'long' ? icon('up-arrow') : icon('down-arrow')}</div>
          <div class="item-main">
            <div class="item-title">${esc(t.pair)} ${resultBadge(t.result)}</div>
            <div class="item-sub">${esc(fmtDate(t.date))}${t.strategy ? ' · ' + esc(t.strategy) : ''}</div>
          </div>
          <div class="item-side num ${(Number(t.pnl) || 0) >= 0 ? 'up' : 'down'}" style="font-weight:800">${money(t.pnl)}</div>
        </div>`).join('')}</div>` : empty({ icon: 'chart', title: 'Tradlar yo\'q', sub: 'Birinchi tradingingizni jurnalga yozing', action: `<button class="btn primary sm" data-act="add-trade">${icon('plus')}Trad qo'shish</button>` })}
      </div>
    </div>

    <div class="grid g2" style="margin-bottom:24px">
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('target')}Maqsadlar</div><button class="btn sm ghost" data-go="goals">${icon('right')}Barchasi</button></div>
        ${goals.length ? `<div class="col" style="gap:14px">${goals.map((g) => {
      const p = goalProgress(g);
      return `<div>
            <div class="row between" style="margin-bottom:6px">
              <span class="row" style="gap:10px">${thumb(g.cover, { ratio: '1:1', pos: g.cover_pos, zoom: g.cover_zoom, style: 'width:38px;height:38px;border-radius:11px', icon: 'target' })}<b>${esc(g.title)}</b></span>
              <span class="num tiny faint">${money(p.saved)} / ${money(p.target)}</span>
            </div>
            ${bar(p.pct)}
            <div class="pmeta"><span>${p.pct.toFixed(1)}% bajarildi</span><span>${p.left > 0 ? money(p.left) + ' qoldi' : 'Bajarildi 🎉'}</span></div>
          </div>`;
    }).join('')}</div>` : empty({ icon: 'target', title: 'Maqsadlar yo\'q', sub: 'Kelajak rejalaringizni foizlar bilan kuzatib boring', action: `<button class="btn primary sm" data-act="add-goal">${icon('plus')}Maqsad qo'shish</button>` })}
      </div>

      <div class="card">
        <div class="card-h"><div class="card-t">${icon('calendar')}Bugungi vazifalar</div><button class="btn sm ghost" data-go="tasks">${icon('right')}Kalendar</button></div>
        <div class="row between" style="margin-bottom:12px">
          ${ring(tstats.pct, 74, tstats.total ? `${tstats.done}/${tstats.total}` : '0')}
          <div class="col grow">
            <div class="h3">${tstats.total ? (tstats.pct === 100 ? 'Hammasi bajarildi! 🎉' : 'Davom eting!') : 'Bugun vazifa yo\'q'}</div>
            <div class="tiny faint">${esc(fmtDate(today))} · Kunlik intizom</div>
            <button class="btn soft sm" data-act="add-task" style="align-self:flex-start;margin-top:6px">${icon('plus')}Vazifa qo'shish</button>
          </div>
        </div>
        ${(state.tasks[today] || []).slice(0, 5).map((t) => `<div class="task ${t.done ? 'done' : ''}" data-act="toggle-task" data-id="${esc(t.id)}" data-date="${today}">
          <div class="cbox">${icon('check')}</div>
          <div class="grow"><div class="task-text">${esc(t.text)}</div>
            <div class="task-sub">${t.time ? `<span>${icon('clock')}${esc(t.time)}</span>` : ''}${priorityBadge(t.priority)}</div></div>
        </div>`).join('')}
      </div>
    </div>

    <div class="grid g3" style="margin-bottom:24px">
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('star')}Xohishlar ro'yxati</div><button class="btn sm ghost" data-go="wishlist">${icon('right')}Barchasi</button></div>
        ${wishes.length ? `<div class="col" style="gap:12px">${wishes.map((w) => {
      const p = wishProgress(w);
      return `<div class="row" style="gap:11px">
            ${thumb(w.cover, { ratio: '1:1', pos: w.cover_pos, zoom: w.cover_zoom, style: 'width:46px;height:46px;border-radius:12px;flex:0 0 auto', icon: 'star' })}
            <div class="grow">
              <div class="item-title">${esc(w.title)}</div>
              <div class="tiny faint">${money(p.saved)} / ${money(p.target)} · ${p.pct.toFixed(0)}%</div>
              ${bar(p.pct, p.pct >= 100 ? 'green' : 'warn')}
            </div>
          </div>`;
    }).join('')}</div>` : empty({ icon: 'star', title: 'Xohishlar yo\'q', sub: 'Nima olishni istaysiz? Yozib, jamg\'arib boring' })}
      </div>

      <div class="card">
        <div class="card-h"><div class="card-t">${icon('note')}So'nggi izohlar</div><button class="btn sm ghost" data-go="notes">${icon('right')}Barchasi</button></div>
        ${recentNotes.length ? `<div class="timeline">${recentNotes.map((n) => `<div class="tl-item">
          <div class="item-title"><span class="mood">${esc(n.mood || '📝')}</span>${esc(n.title)}${n.important ? `<span class="pin-flag">${icon('pin')}</span>` : ''}</div>
          <div class="tiny faint">${esc(fmtDate(n.date))} · ${esc((n.body || '').slice(0, 90))}${(n.body || '').length > 90 ? '…' : ''}</div>
        </div>`).join('')}</div>` : empty({ icon: 'note', title: 'Izohlar yo\'q', sub: 'Muammo, g\'oya va kunlik fikrlaringizni yozib boring' })}
      </div>

      <div class="card">
        <div class="card-h"><div class="card-t">${icon('sparkles')}So'nggi harakatlar</div></div>
        ${state.activity.length ? `<div class="col" style="gap:9px">${state.activity.slice(0, 7).map((a) => `<div class="row" style="gap:10px">
          <div class="avatar sm">${icon(a.icon || 'sparkles')}</div>
          <div class="grow"><div style="font-size:13px;font-weight:650">${esc(a.text)}</div><div class="tiny faint">${esc(fmtDate(a.at))} · ${esc((a.at || '').slice(11, 16))}</div></div>
        </div>`).join('')}</div>` : empty({ icon: 'sparkles', title: 'Harakatlar tarixi bo\'sh', sub: 'Siz qilgan amallar shu yerda saqlanadi' })}
      </div>
    </div>
  </div>`;

  /* ---------- charts ---------- */
  charts = [];
  const sparkCv = view.querySelector('[data-chart="spark"]');
  if (sparkCv) charts.push(sparkline(sparkCv, snap.length > 1 ? snap.slice(-40) : [0, nw, nw]));
  const flowCv = view.querySelector('[data-chart="flow"]');
  if (flowCv) charts.push(areaChart(flowCv, [
    { label: 'Kirim', values: months.map((x) => x.income), color: getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#22e07a' },
    { label: 'Chiqim', values: months.map((x) => x.expense), color: '#ff6b78', fill: false },
  ], months.map((x) => x.label)));
  const donutCv = view.querySelector('[data-chart="donut"]');
  if (donutCv && types.length) charts.push(donut(donutCv, types.map((t, i) => ({ ...t, color: `hsl(${(i * 62) % 360} 70% 60%)` })), { size: 210, label: 'Jami', fmt: (v) => money(v, { sensitive: true }) }));

  fillMedia(view);
  barFill(view);
  const nwEl = view.querySelector('#nwValue');
  if (nwEl && !hidden) animateNumber(nwEl, 0, nw, { fmt: (v) => money(v) });

  /* ---------- interactions ---------- */
  on(view, 'click', '[data-act]', async (e, b) => {
    const act = b.dataset.act;
    if (act === 'toggle-net') {
      state.settings.hideNetWorth = !state.settings.hideNetWorth;
      save(); sfx(state.settings.hideNetWorth ? 'lock' : 'unlock');
      toast(state.settings.hideNetWorth ? 'Net Worth yashirildi' : 'Net Worth ko\'rsatildi', { type: 'info' });
      ctx.refresh(); return;
    }
    if (act === 'add-account') {
      openForm({
        title: 'Yangi hisob', icon: 'wallet', schema: SCHEMAS.account,
        onSave: (v) => { state.accounts.push({ id: 'acc_' + Date.now().toString(36), ...v }); save(); toast('Hisob qo\'shildi', { type: 'success' }); ctx.refresh(); },
      });
      return;
    }
    if (act === 'add-trade') {
      const { openTradeForm } = await import('./view-journal.js');
      openTradeForm(null, ctx); return;
    }
    if (act === 'add-tx') {
      const type = b.dataset.type;
      const { openTxForm } = await import('./view-cash.js');
      openTxForm(type, null, ctx); return;
    }
    if (act === 'add-goal') {
      const { openGoalForm } = await import('./view-goals.js');
      openGoalForm(null, ctx); return;
    }
    if (act === 'add-task') {
      const { openTaskForm } = await import('./view-life.js');
      openTaskForm(null, todayISO(), ctx); return;
    }
    if (act === 'toggle-task') {
      const list = state.tasks[b.dataset.date] || [];
      const t = list.find((x) => x.id === b.dataset.id);
      if (t) { t.done = !t.done; save(); sfx(t.done ? 'check' : 'uncheck'); ctx.refresh(); }
      return;
    }
  });
}

export { render as default };
