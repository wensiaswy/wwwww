/* ============================================================
   KHUMOYUN OS — Trading Journal (TP/SL, xulosa, 16:9 skrinshot)
   ============================================================ */
import { $, $$, esc, icon, on, toast, sfx, uid, fmtDate, todayISO, sortBy, modal } from './util.js';
import { state, save, money, tradeStats, logActivity } from './store.js';
import { areaChart } from './charts.js';
import { pageHead, section, empty, kpi, statMini, thumb, editBtn, delBtn, viewBtn, resultBadge, tagsRow, kv } from './kit.js';
import { fillMedia, openForm, SCHEMAS, OPT } from './form.js';

const SESSION_LABEL = Object.fromEntries(OPT.session);
const EMOTION_LABEL = Object.fromEntries(OPT.emotion);
let filterResult = 'all', filterQuery = '';

export function plannedRR(t) {
  const e = Number(t.entry), sl = Number(t.sl), tp = Number(t.tp);
  if (!e || !sl || !tp) return null;
  const risk = Math.abs(e - sl), reward = Math.abs(tp - e);
  if (!risk) return null;
  return reward / risk;
}

export function openTradeForm(data, ctx) {
  const editing = !!(data && data.id);
  openForm({
    title: editing ? `Tradni tahrirlash · ${data.pair}` : 'Yangi trad', icon: 'chart', schema: SCHEMAS.trade, data: data || {}, size: 'wide',
    subtitle: 'TP/SL, hajm, hissiyot va skrinshotni to\'ldiring — keyin xulosani yozing',
    saveLabel: editing ? 'Yangilash' : 'Jurnalga qo\'shish',
    allowDelete: editing,
    onDelete: () => { state.trades = state.trades.filter((t) => t.id !== data.id); save(); toast('Trad o\'chirildi', { type: 'warn' }); ctx.refresh(); },
    onSave: (v) => {
      const rrAuto = plannedRR(v);
      if (!v.rr && rrAuto) v.rr = Number(rrAuto.toFixed(2));
      if (editing) { Object.assign(data, v); toast('Trad yangilandi', { type: 'success' }); }
      else {
        state.trades.push({ id: uid('tr'), ...v, createdAt: new Date().toISOString() });
        logActivity(`Yangi trad: ${v.pair} (${v.side === 'long' ? 'LONG' : 'SHORT'})`, 'chart', 'trade');
        toast(`${v.pair} jurnalga qo'shildi`, { type: 'success' });
      }
      save(); ctx.refresh();
    },
  });
}

export function render(view, ctx) {
  const all = sortBy(state.trades, 'date', 'desc');
  const st = tradeStats(all);
  let list = all.filter((t) => filterResult === 'all' || t.result === filterResult);
  if (filterQuery) {
    const q = filterQuery.toLowerCase();
    list = list.filter((t) => `${t.pair} ${t.strategy} ${t.notes} ${(t.tags || []).join(' ')}`.toLowerCase().includes(q));
  }
  const pairs = [...new Set(all.map((t) => t.pair))];
  const byPair = pairs.map((p) => {
    const arr = all.filter((t) => t.pair === p);
    return { pair: p, pnl: arr.reduce((s, t) => s + (Number(t.pnl) || 0), 0), count: arr.length };
  }).sort((a, b) => b.pnl - a.pnl).slice(0, 6);
  const pnlSeries = [...all].slice(0, 30).reverse().reduce((acc, t, i) => {
    const prev = acc.length ? acc[acc.length - 1] : 0;
    acc.push(prev + (Number(t.pnl) || 0));
    return acc;
  }, []);

  view.innerHTML = `<div class="stagger">
  ${pageHead({
    title: 'Trading Journal', icon: 'chart', badge: 'savdo jurnali',
    sub: `${st.count} trad · har biri uchun TP/SL, xulosa va 16:9 skrinshot`,
    actions: `<button class="btn sm ghost" data-act="export-csv">${icon('download')}CSV</button>
      <button class="btn primary sm" data-act="add">${icon('plus')}Yangi trad</button>`
  })}

  <div class="kpis" style="margin-bottom:20px">
    ${kpi({ label: 'Umumiy P/L', value: money(st.pnl), icon: 'trend', delta: { dir: st.pnl >= 0 ? 'up' : 'down', text: `${st.closed} yopilgan trad` } })}
    ${kpi({ label: 'Win rate', value: `${st.winRate.toFixed(0)}%`, icon: 'target', delta: { dir: '', text: `${st.wins} foyda / ${st.losses} zarar` } })}
    ${kpi({ label: 'O\'rtacha R', value: `${st.avgR.toFixed(2)}R`, icon: 'chart' })}
    ${kpi({ label: 'Profit factor', value: st.profitFactor.toFixed(2), icon: 'filter' })}
    ${kpi({ label: 'Eng yaxshi', value: money(st.best), icon: 'up-arrow' })}
    ${kpi({ label: 'Eng yomon', value: money(st.worst), icon: 'down-arrow' })}
  </div>

  <div class="grid g2" style="margin-bottom:20px">
    <div class="card">
      <div class="card-h"><div class="card-t">${icon('trend')}P/L dinamikasi (oxirgi 30 trad)</div></div>
      ${pnlSeries.length > 1 ? `<div class="chart-wrap"><canvas data-chart="pnl" data-h="220"></canvas></div>` : empty({ icon: 'chart', title: 'Grafik uchun ma\'lumot yo\'q', sub: 'Kamida 2 ta trad kiriting' })}
    </div>
    <div class="card">
      <div class="card-h"><div class="card-t">${icon('chart')}Instrumentlar bo\'yicha</div></div>
      ${byPair.length ? `<div class="col" style="gap:10px">${byPair.map((p) => `<div class="row between">
        <span class="badge">${esc(p.pair)}</span>
        <span class="row" style="gap:10px"><span class="tiny faint">${p.count} trad</span>
        <b class="num ${p.pnl >= 0 ? 'up' : 'down'}">${money(p.pnl)}</b></span></div>`).join('')}</div>`
      : empty({ icon: 'chart', title: 'Tradlar yo\'q', sub: 'Birinchi tradingizni yozing' })}
    </div>
  </div>

  ${section({
    title: 'Tradlarim', icon: 'list', sub: 'Tahrirlash uchun qalamcha, batafsil uchun ko\'z tugmasini bosing',
    actions: `<div class="top-search" style="max-width:230px">${icon('search')}<input id="jSearch" placeholder="Qidirish…" value="${esc(filterQuery)}"></div>`,
    body: `
      <div class="chips" style="margin-bottom:14px">
        ${[['all', 'Barchasi'], ['win', 'Foyda'], ['loss', 'Zarar'], ['be', 'Breakeven'], ['open', 'Ochiq']].map(([k, l]) =>
      `<button class="chip ${filterResult === k ? 'active' : ''}" data-filter="${k}">${esc(l)}</button>`).join('')}
      </div>
      ${list.length ? `<div class="grid g3">${list.map((t) => {
        const rr = plannedRR(t);
        return `<div class="card trade-card lift reveal">
          ${t.image ? thumb(t.image, {
          ratio: '16:9', pos: t.image_pos, zoom: t.image_zoom, icon: 'image', children: `
            <div class="row" style="position:absolute;top:9px;left:9px;gap:6px;z-index:2">
              <span class="badge ${t.side === 'long' ? 'long' : 'short'}">${icon(t.side === 'long' ? 'up-arrow' : 'down-arrow')}${t.side === 'long' ? 'LONG' : 'SHORT'}</span>
              ${resultBadge(t.result)}
            </div>
            <div class="row" style="position:absolute;bottom:9px;right:9px;gap:6px;z-index:2">
              <span class="badge ${(Number(t.pnl) || 0) >= 0 ? 'win' : 'loss'}">${money(t.pnl)}</span>
              ${t.rr ? `<span class="badge">${Number(t.rr).toFixed(1)}R</span>` : ''}
            </div>` })
          : `<div class="tc-strip">
              <span class="badge ${t.side === 'long' ? 'long' : 'short'}">${icon(t.side === 'long' ? 'up-arrow' : 'down-arrow')}${t.side === 'long' ? 'LONG' : 'SHORT'}</span>
              ${resultBadge(t.result)}
              <span style="flex:1"></span>
              <span class="badge ${(Number(t.pnl) || 0) >= 0 ? 'win' : 'loss'}">${money(t.pnl)}</span>
            </div>`}
          <div class="tc-head">
            <div><div class="item-title">${esc(t.pair)}</div>
              <div class="item-sub">${esc(fmtDate(t.date))} · ${esc(SESSION_LABEL[t.session] || '')}</div></div>
            <div class="item-actions">${viewBtn('detail', t.id)}${editBtn('edit', t.id)}${delBtn('del', t.id)}</div>
          </div>
          <div class="tc-meta">
            ${statMini('Kirish', t.entry ? String(t.entry) : '—')}
            ${statMini('SL', t.sl ? String(t.sl) : '—')}
            ${statMini('TP', t.tp ? String(t.tp) : '—')}
            ${statMini('RR', rr ? rr.toFixed(2) + 'R' : (t.rr ? Number(t.rr).toFixed(2) + 'R' : '—'))}
          </div>
        </div>`;
      }).join('')}</div>` : empty({ icon: 'chart', title: 'Tradlar topilmadi', sub: filterQuery || filterResult !== 'all' ? 'Filtrni o\'zgartirib ko\'ring' : 'Birinchi tradingizni jurnalga qo\'shing', action: `<button class="btn primary sm" data-act="add">${icon('plus')}Trad qo'shish</button>` })}
    `
  })}
  </div>`;

  const cv = view.querySelector('[data-chart="pnl"]');
  if (cv) areaChart(cv, [{ values: pnlSeries, color: (pnlSeries[pnlSeries.length - 1] || 0) >= 0 ? (getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#22e07a') : '#ff6b78' }], null, { height: 220 });
  fillMedia(view);

  const search = view.querySelector('#jSearch');
  if (search) search.addEventListener('input', (e) => { filterQuery = e.target.value; const pos = e.target.selectionStart; ctx.refresh({ silent: true }).then(() => { const s = view.querySelector('#jSearch'); if (s) { s.focus(); s.setSelectionRange(pos, pos); } }); });

  on(view, 'click', '[data-filter]', (e, b) => { filterResult = b.dataset.filter; sfx('tap'); ctx.refresh(); });
  on(view, 'click', '[data-act]', async (e, b) => {
    const act = b.dataset.act, id = b.dataset.id;
    if (act === 'add') return openTradeForm(null, ctx);
    if (act === 'edit') return openTradeForm(state.trades.find((t) => t.id === id), ctx);
    if (act === 'del') {
      const t = state.trades.find((x) => x.id === id);
      state.trades = state.trades.filter((x) => x.id !== id); save();
      toast(`${t ? t.pair : ''} o'chirildi`, { type: 'warn' }); ctx.refresh(); return;
    }
    if (act === 'detail') return openTradeDetail(id, ctx);
    if (act === 'export-csv') {
      const rows = [['Sana', 'Instrument', 'Yo\'nalish', 'Kirish', 'SL', 'TP', 'Lot', 'P/L', 'R', 'Holat', 'Strategiya', 'Xulosa']];
      state.trades.forEach((t) => rows.push([t.date, t.pair, t.side, t.entry, t.sl, t.tp, t.lots, t.pnl, t.rr, t.result, t.strategy, (t.notes || '').replace(/\n/g, ' ')]));
      const csv = '\uFEFF' + rows.map((r) => r.map((c) => `"${String(c == null ? '' : c).replace(/"/g, '""')}"`).join(';')).join('\n');
      const { download } = await import('./util.js');
      download(new Blob([csv], { type: 'text/csv' }), `trading-journal-${todayISO()}.csv`);
      toast('CSV yuklab olindi', { type: 'success' }); return;
    }
  });
}

export function openTradeDetail(id, ctx) {
  const t = state.trades.find((x) => x.id === id);
  if (!t) return;
  const rr = plannedRR(t);
  const risk = t.entry && t.sl ? Math.abs(Number(t.entry) - Number(t.sl)) : null;
  const reward = t.entry && t.tp ? Math.abs(Number(t.tp) - Number(t.entry)) : null;
  const m = modal.open({
    title: `${t.pair} · ${t.side === 'long' ? 'LONG' : 'SHORT'}`, icon: 'chart', size: 'wide',
    body: `
      <div class="row wrap" style="gap:8px">
        ${resultBadge(t.result)}
        <span class="badge ${t.side === 'long' ? 'long' : 'short'}">${t.side === 'long' ? 'LONG' : 'SHORT'}</span>
        <span class="badge">${icon('calendar')}${esc(fmtDate(t.date))}</span>
        <span class="badge">${icon('clock')}${esc(SESSION_LABEL[t.session] || '—')}</span>
        ${t.emotion ? `<span class="badge">${esc(EMOTION_LABEL[t.emotion] || t.emotion)}</span>` : ''}
        <span class="badge ${(Number(t.pnl) || 0) >= 0 ? 'win' : 'loss'}">${money(t.pnl)}</span>
      </div>
      ${thumb(t.image, { ratio: '16:9', pos: t.image_pos, zoom: t.image_zoom, icon: 'image', cls: 'shine' })}
      <div class="grid g4">
        ${statMini('Kirish', t.entry || '—')}${statMini('Stop Loss', t.sl || '—')}${statMini('Take Profit', t.tp || '—')}
        ${statMini('Hajm (lot)', t.lots || '—')}${statMini('Risk masofa', risk ? risk.toFixed(4) : '—')}
        ${statMini('Reward masofa', reward ? reward.toFixed(4) : '—')}${statMini('Rejalashtirilgan RR', rr ? rr.toFixed(2) + 'R' : '—')}
        ${statMini('Natija R', t.rr ? Number(t.rr).toFixed(2) + 'R' : '—')}
      </div>
      ${t.strategy ? `<div><div class="lbl">${icon('tag')}Strategiya / Setup</div><div>${esc(t.strategy)}</div></div>` : ''}
      ${t.notes ? `<div><div class="lbl">${icon('note')}Xulosa va tahlil</div><div class="card flat" style="white-space:pre-wrap;line-height:1.6">${esc(t.notes)}</div></div>` : ''}
      ${tagsRow(t.tags)}
    `,
    footer: `<button class="btn ghost" data-x>Yopish</button><button class="btn primary" data-e>${icon('pencil')}Tahrirlash</button>`,
  });
  m.root.querySelector('[data-x]').onclick = () => m.close();
  m.root.querySelector('[data-e]').onclick = () => { m.close(); openTradeForm(t, ctx); };
  fillMedia(m.root);
}

export { render as default };
