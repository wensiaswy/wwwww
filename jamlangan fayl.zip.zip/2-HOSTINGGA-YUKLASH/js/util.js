/* ============================================================
   KHUMOYUN OS — util: DOM, toast, modal, sfx, fx
   ============================================================ */
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
export const uid = (p = 'id') => p + '_' + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
export const clamp = (v, a = 0, b = 100) => Math.max(a, Math.min(b, Number(v) || 0));
export const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const debounce = (fn, ms = 300) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
export const throttle = (fn, ms = 60) => { let last = 0, tm; return (...a) => { const now = Date.now(); if (now - last >= ms) { last = now; fn(...a); } else { clearTimeout(tm); tm = setTimeout(() => { last = Date.now(); fn(...a); }, ms - (now - last)); } }; };
export const todayISO = (d = new Date()) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
export const nowISO = () => new Date().toISOString();
export const DAYS_UZ = ['Yakshanba', 'Dushanba', 'Seshanba', 'Chorshanba', 'Payshanba', 'Juma', 'Shanba'];
export const MONTHS_UZ = ['Yanvar', 'Fevral', 'Mart', 'Aprel', 'May', 'Iyun', 'Iyul', 'Avgust', 'Sentabr', 'Oktabr', 'Noyabr', 'Dekabr'];
export const MON_SHORT = ['Yan', 'Fev', 'Mar', 'Apr', 'May', 'Iyn', 'Iyl', 'Avg', 'Sen', 'Okt', 'Noy', 'Dek'];
export function fmtDate(iso) {
  if (!iso) return '—';
  const d = new Date(iso); if (isNaN(d)) return String(iso);
  return `${String(d.getDate()).padStart(2, '0')} ${MON_SHORT[d.getMonth()]} ${d.getFullYear()}`;
}
export function fmtDateTime(iso) {
  if (!iso) return '—';
  const d = new Date(iso); if (isNaN(d)) return String(iso);
  return `${fmtDate(iso)} · ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}
export function relTime(iso) {
  const d = new Date(iso); const s = (Date.now() - d.getTime()) / 1000;
  if (s < 60) return 'hozirgina';
  if (s < 3600) return Math.floor(s / 60) + ' daqiqa oldin';
  if (s < 86400) return Math.floor(s / 3600) + ' soat oldin';
  if (s < 604800) return Math.floor(s / 86400) + ' kun oldin';
  return fmtDate(iso);
}
export function icon(name, cls = '') { return `<svg class="ic ${cls}" aria-hidden="true"><use href="#i-${name}"/></svg>`; }
export function humanSize(b) {
  if (b == null) return '—';
  const u = ['B', 'KB', 'MB', 'GB']; let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return `${b.toFixed(i === 0 ? 0 : 1)} ${u[i]}`;
}
export function on(root, ev, sel, fn) {
  if (!root) return;
  root.addEventListener(ev, (e) => { const t = e.target.closest(sel); if (t && root.contains(t)) fn(e, t); });
}
export function pick(list) { return list[Math.floor(Math.random() * list.length)]; }
export function sortBy(list, key, dir = 'desc') {
  return [...list].sort((a, b) => {
    const x = a[key], y = b[key];
    const r = x == null ? -1 : y == null ? 1 : (typeof x === 'number' ? x - y : String(x).localeCompare(String(y)));
    return dir === 'desc' ? -r : r;
  });
}
export function download(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/* ---------------- SOUND ENGINE ----------------
   To'liq Web Audio sintez: hech qanday tashqi fayl yo'q, internet shart emas.
   4 xil "ovoz paketi" + reverb (xona effekti) + yumshoq ADSR konvertlar.  */
export const SOUND_PACKS = [
  ['glass', 'Glass', 'Tiniq va qimmat — premium UI ovozi'],
  ['soft', 'Soft', 'Juda yumshoq va bo\'g\'iq — xotirjam uslub'],
  ['mech', 'Mech', 'Aniq, quruq — mexanik klaviatura hissi'],
  ['bubble', 'Bubble', 'Suv tomchisi — mayin va yoqimli'],
  ['marimba', 'Marimba', 'Iliq yog\'och ohang — musiqiy'],
  ['retro', 'Retro', '8-bit o\'yin uslubi'],
];
/* Har bir paket: to'lqin turi, konvert, filtr, reverb va "click" tishchasi.
   Hammasi Web Audio'da sintezlanadi — tashqi fayl, internet va litsenziya muammosi yo'q. */
const PACKS = {
  glass: { wave: 'sine', wave2: 'triangle', base: 1, decay: 1, bright: 5200, hp: 130, rev: .3, revDur: 1.1, revDec: 2.9, sub: .3, gain: 1, click: .05, clickF: 3600, clickQ: 1.3, jit: 14 },
  soft: { wave: 'sine', wave2: 'sine', base: .8, decay: 1.6, bright: 2300, hp: 90, rev: .46, revDur: 1.9, revDec: 2.1, sub: .52, gain: .92, click: .028, clickF: 1400, clickQ: .8, jit: 24 },
  mech: { wave: 'square', wave2: 'triangle', base: 1.08, decay: .48, bright: 7800, hp: 190, rev: .06, revDur: .34, revDec: 3.6, sub: .16, gain: .72, click: .016, clickF: 6400, clickQ: 2.6, jit: 6 },
  bubble: { wave: 'sine', wave2: 'sine', base: .68, decay: 1.4, bright: 3100, hp: 150, rev: .38, revDur: 1.5, revDec: 2.4, sub: .44, gain: .95, click: .024, clickF: 2500, clickQ: 1.1, jit: 20 },
  marimba: { wave: 'triangle', wave2: 'sine', base: .85, decay: 1.4, bright: 4300, hp: 110, rev: .32, revDur: 1.3, revDec: 2.7, sub: .26, gain: .9, click: .03, clickF: 2700, clickQ: 1.7, jit: 10 },
  retro: { wave: 'square', wave2: 'square', base: 1.25, decay: .72, bright: 9200, hp: 150, rev: .04, revDur: .3, revDec: 4, sub: .06, gain: .64, click: .01, clickF: 7400, clickQ: 2.8, jit: 4 },
};
const ALIAS = { drop: 'bubble' };

/* ---- foydalanuvchi yuklagan ovoz fayllari (mp3/wav) uchun pleer ---- */
const samplePool = new Map();      // url -> Audio (asosiy nusxa)
export function playSampleUrl(url, vol = .5) {
  try {
    if (!url) return false;
    let base = samplePool.get(url);
    if (!base) { base = new Audio(url); base.preload = 'auto'; samplePool.set(url, base); }
    const node = base.cloneNode(true);              // bir vaqtda bir necha marta chalinishi uchun
    node.volume = Math.max(0, Math.min(1, Number(vol) || .5));
    const p = node.play();
    if (p && p.catch) p.catch(() => { });
    return true;
  } catch (e) { return false; }
}

class SoundEngine {
  constructor() { this.ctx = null; this.on = true; this.vol = .5; this.pack = 'glass'; this._ir = {}; this.custom = {}; this.sampleResolver = null; }
  init() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) { try { this.ctx = new AC(); } catch (e) { this.ctx = null; } }
      if (this.ctx) {
        const c = this.ctx;
        /* master zanjir: tone → rumble filtri → kompressor → master */
        this.master = c.createGain(); this.master.gain.value = .9;
        this.comp = c.createDynamicsCompressor ? c.createDynamicsCompressor() : null;
        if (this.comp) {
          this.comp.threshold.value = -14; this.comp.knee.value = 24;
          this.comp.ratio.value = 3.2; this.comp.attack.value = .004; this.comp.release.value = .18;
        }
        /* DIQQAT: filtr nomi 'lp' — 'tone' emas! Ilgari bu nom sintez metodini
           (tone()) ustidan yozib, ovozlar umuman chalinmasdi. */
        this.lp = c.createBiquadFilter(); this.lp.type = 'lowpass'; this.lp.frequency.value = 5200;
        this.hp = c.createBiquadFilter(); this.hp.type = 'highpass'; this.hp.frequency.value = 120;
        this.wet = c.createGain(); this.wet.gain.value = .18;
        this.bus = this.lp;
        const chain = [this.lp, this.hp, this.comp, this.master].filter(Boolean);
        for (let i = 0; i < chain.length - 1; i++) chain[i].connect(chain[i + 1]);
        this.master.connect(c.destination);
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume().catch(() => { });
    this.applyPack();
    return this.ctx;
  }
  get dest() { return this.master || (this.ctx ? this.ctx.destination : null); }
  /* reverb uchun impuls javobi — yumshoq, quyuq dum (plate/room) */
  impulse(dur, decay) {
    const key = dur + ':' + decay;
    if (this._ir[key]) return this._ir[key];
    const c = this.ctx, len = Math.max(1, Math.floor(c.sampleRate * dur));
    const buf = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = buf.getChannelData(ch);
      let lp = 0;
      for (let i = 0; i < len; i++) {
        const t = i / len;
        const white = Math.random() * 2 - 1;
        lp += (white - lp) * (.28 - .22 * t);      // keti bilan quyuqlashadi
        d[i] = lp * Math.pow(1 - t, decay) * (ch ? .96 : 1);
      }
      /* dastlabki akslar (early reflections) — reverb "quruq" eshitilmasligi uchun */
      [0.006, 0.013, 0.024, 0.041].forEach((ms, k) => {
        const p = Math.floor(ms * c.sampleRate);
        if (p < len) d[p] += (k % 2 ? -.5 : .5) * .5;
      });
    }
    this._ir[key] = buf; return buf;
  }
  applyPack() {
    const p = PACKS[this.pack] || PACKS.glass;
    if (!this.ctx) return;
    if (this.lp) this.lp.frequency.value = p.bright;
    if (this.hp) this.hp.frequency.value = p.hp;
    if (this.master) this.master.gain.value = .9 * (this.vol != null ? 1 : 1);
    if (this.wet && this.conv) this.wet.gain.value = p.rev * .5;
    if (this.conv) { this.conv.buffer = this.impulse(p.revDur, p.revDec); }
  }
  setPack(key) {
    key = ALIAS[key] || key;
    this.pack = PACKS[key] ? key : 'glass';
    if (!this.ctx) this.init();
    else this.applyPack();
  }
  /* konvolyutsiya (xona) effekti — paketga qarab avtomatik ulanadi */
  ensureConv() {
    if (!this.ctx) return;
    if (!this.conv && this.ctx.createConvolver) {
      this.conv = this.ctx.createConvolver();
      const p = PACKS[this.pack] || PACKS.glass;
      this.conv.buffer = this.impulse(p.revDur, p.revDec);
      this.wet.connect(this.conv); this.conv.connect(this.master);
    }
  }
  /* bitta ohang: ADSR + ixtiyoriy lowpass + reverb send */
  tone(f0, f1, dur, type = 'sine', gain = .18, delay = 0, opts = {}) {
    if (!this.on) return; const c = this.init(); if (!c) return;
    this.ensureConv();
    const ch = PACKS[this.pack] || PACKS.glass;
    const t = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type || ch.wave;
    const j = opts.jitter === false ? 0 : (Math.random() * 2 - 1) * (ch.jit || 10);
    o.frequency.setValueAtTime(Math.max(20, f0), t);
    if (j) o.detune.setValueAtTime(j, t);
    if (f1 && f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const peak = Math.max(.0006, gain * this.vol * ch.gain);
    const at = Math.max(.003, (opts.attack || .008) * ch.decay);
    const dd = dur * ch.decay;
    g.gain.setValueAtTime(.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + at);
    g.gain.exponentialRampToValueAtTime(.0001, t + dd);
    let node = g;
    if (opts.lp && c.createBiquadFilter) {
      const f = c.createBiquadFilter(); f.type = 'lowpass';
      f.frequency.value = opts.lp; f.Q.value = opts.q || .7;
      g.connect(f); node = f;
    }
    o.connect(g); node.connect(this.bus || this.dest);
    if (this.wet && ch.rev > .1) node.connect(this.wet);
    o.start(t); o.stop(t + dd + .05);
  }
  /* shovqin portlashi (click "tishlari", whoosh) */
  noise(dur = .3, freq = 1200, gain = .12, delay = 0, q = .9, type = 'bandpass') {
    if (!this.on) return; const c = this.init(); if (!c) return;
    this.ensureConv();
    const ch = PACKS[this.pack] || PACKS.glass;
    const len = Math.max(1, Math.floor(c.sampleRate * dur * Math.max(.4, ch.decay)));
    const buf = c.createBuffer(1, len, c.sampleRate); const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.2);
    const src = c.createBufferSource(); src.buffer = buf;
    const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = c.createGain(); g.gain.value = gain * this.vol * ch.gain;
    src.connect(f); f.connect(g); g.connect(this.bus || this.dest);
    if (this.wet && ch.rev > .1) g.connect(this.wet);
    src.start(c.currentTime + delay);
  }
  /* ikki qavatli "hit": tishcha + ohang (+ ixtiyoriy sub) */
  hit(f0, f1, dur, { type, gain = .11, delay = 0, sub = 0, lp, attack } = {}) {
    const ch = PACKS[this.pack] || PACKS.glass;
    this.noise(ch.click, ch.clickF, ch.click * 1.1, delay, ch.clickQ, 'bandpass');
    this.tone(f0, f1, dur, type, gain, delay, { lp, attack });
    if (sub || ch.sub) this.tone((f0 * .5), (f1 * .5), dur * 1.25, 'sine', gain * (sub || ch.sub), delay + .012, { jitter: false, lp: 900 });
  }
  chord(freqs, { dur = .3, type = 'sine', gain = .1, step = .06, delay = 0, glide = 1.01, sub = 0 } = {}) {
    freqs.forEach((f, i) => this.tone(f, f * glide, dur, type, gain, delay + i * step, { })); 
    if (sub) this.tone(freqs[0] * .5, freqs[0] * .5, dur * 1.4, 'sine', gain * sub, delay, { jitter: false, lp: 800 });
  }
  /* qaysi guruhga tegishli: umumiy bosish / muvaffaqiyat / xatolik */
  groupOf(name) {
    if (['success', 'unlock', 'progress', 'coin', 'save', 'check', 'boot'].includes(name)) return 'ok';
    if (['error', 'warn', 'delete'].includes(name)) return 'err';
    return 'ui';
  }
  /* Agar foydalanuvchi o'z ovoz faylini yuklagan bo'lsa — shuni chalamiz */
  trySample(name) {
    const map = this.custom || {};
    const id = map[this.groupOf(name)] || map.ui;
    if (!id || !this.sampleResolver) return false;
    Promise.resolve(this.sampleResolver(id)).then((url) => {
      if (url) playSampleUrl(url, this.vol * (name === 'hover' ? .55 : name === 'tick' ? .4 : 1));
    }).catch(() => { });
    return true;
  }
  play(name) {
    if (!this.on) return; this.init();
    if (this.trySample(name)) return;
    const ch = PACKS[this.pack] || PACKS.glass;
    const B = ch.base, W1 = ch.wave, W2 = ch.wave2;
    switch (name) {
      case 'click': this.hit(680 * B, 1120 * B, .08, { type: W1, gain: .1 }); break;
      case 'tap': this.hit(470 * B, 610 * B, .075, { type: W2, gain: .085, sub: .18 }); break;
      case 'tick': this.noise(.02, 5400, .032, 0, 2.3); this.tone(2100, 1900, .026, 'square', .026); break;
      case 'hover': this.tone(1950 * B, 2350 * B, .028, 'sine', .02, 0, { attack: .003, jitter: false }); break;
      case 'nav':
        this.hit(520 * B, 950 * B, .17, { type: W1, gain: .095, sub: .22 });
        this.chord([1040 * B, 1560 * B], { dur: .16, gain: .035, step: .03, delay: .04, type: 'sine' }); break;
      case 'success':
        this.chord([523, 659, 784, 1046], { dur: .36, gain: .085, step: .058, type: W1, glide: 1.004, sub: .2 });
        this.noise(.16, 6200, .028, .02, 1.2); break;
      case 'unlock':
        this.chord([392, 523, 659, 784, 1046], { dur: .5, gain: .078, step: .05, type: W1, glide: 1.5, sub: .22 });
        this.noise(.5, 3200, .03, .05, .8); break;
      case 'lock':
        this.tone(320, 150, .32, W1, .1);
        this.noise(.28, 380, .065);
        this.tone(120, 96, .34, 'sine', .055, .04, { jitter: false }); break;
      case 'error':
        this.tone(190, 96, .3, 'sawtooth', .095);
        this.tone(150, 74, .36, 'square', .045, .05);
        this.noise(.14, 400, .045); break;
      case 'warn':
        this.tone(470, 410, .2, W1, .095); this.tone(405, 300, .24, W1, .08, .17); break;
      case 'coin':
        this.chord([1180, 1560, 2100], { dur: .2, gain: .055, step: .045, type: 'square', glide: 1.2 }); break;
      case 'save':
        this.tone(680, 1180, .17, 'sine', .095); this.tone(1180, 1560, .2, W2, .05, .07); break;
      case 'delete':
        this.tone(340, 120, .26, 'sawtooth', .085); this.noise(.22, 520, .055); break;
      case 'woosh':
        this.noise(.36, 900, .07, 0, .7); this.tone(200, 640, .34, 'sine', .04); break;
      case 'open':
        this.noise(.2, 2400, .038, 0, .9); this.tone(300, 760, .2, W2, .055); break;
      case 'close':
        this.noise(.18, 700, .032); this.tone(620, 240, .17, W2, .05); break;
      case 'check': this.chord([880 * B, 1320 * B], { dur: .16, gain: .075, step: .05, type: 'sine' }); break;
      case 'uncheck': this.tone(560, 320, .14, 'sine', .065); break;
      case 'progress': this.chord([660, 880, 1100], { dur: .2, gain: .065, step: .05, type: 'sine' }); break;
      case 'boot':
        this.chord([262, 330, 392, 523], { dur: .62, gain: .055, step: .1, type: 'sine', glide: 1, sub: .3 });
        this.noise(.5, 1800, .022, .05, .6); break;
      default: this.hit(660 * B, 880 * B, .07, { type: W1, gain: .09 });
    }
  }
  /* Ovoz paketini sinab ko'rish (Sozlamalar → Ovoz) */
  preview(key) {
    const was = this.pack;
    if (key) this.setPack(key);
    this.on = true;
    const t = PACKS[this.pack] || PACKS.glass;
    this.play('click');
    setTimeout(() => this.play('tap'), 190);
    setTimeout(() => this.play('success'), 380);
    setTimeout(() => { this.setPack(was); }, 1400);
  }
}
export const sound = new SoundEngine();
export const sfx = (n) => { try { sound.play(n); } catch (e) { } };

/* ---------------- AMBIENT PAD ---------------- */
export const ambient = {
  playing: false, nodes: [], timer: null,
  start() {
    const c = sound.init(); if (!c) return;
    this.stop(true);
    const g = c.createGain(); g.gain.value = 0; g.connect(sound.dest || c.destination);
    this.nodes.push(g);
    const chords = [[196, 294, 392, 494], [174, 261, 349, 440], [220, 330, 440, 523], [164, 246, 330, 415]];
    let i = 0;
    const voice = () => {
      const set = chords[i % chords.length]; i++;
      set.forEach((f, k) => {
        const o = c.createOscillator(), og = c.createGain();
        o.type = k % 2 ? 'triangle' : 'sine'; o.frequency.value = f;
        og.gain.value = 0; o.connect(og); og.connect(g);
        const t = c.currentTime;
        og.gain.linearRampToValueAtTime(.09 / (k + 1), t + 2.4);
        og.gain.linearRampToValueAtTime(0, t + 7.2);
        o.start(t); o.stop(t + 7.4);
      });
    };
    g.gain.linearRampToValueAtTime(.5, c.currentTime + 3);
    voice(); this.timer = setInterval(voice, 6000);
    this.playing = true;
  },
  stop(silent) {
    this.playing = false;
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
    const c = sound.ctx;
    if (c) this.nodes.forEach((n) => { try { n.gain && n.gain.linearRampToValueAtTime(0, c.currentTime + .5); } catch (e) { } });
    this.nodes = [];
  },
  toggle() { this.playing ? this.stop() : this.start(); return this.playing; }
};

/* ---------------- TOAST ---------------- */
export function toast(msg, opts = {}) {
  const root = $('#toastRoot'); if (!root) return;
  const type = opts.type || 'info';
  const names = { info: 'sparkles', success: 'check', error: 'x', warn: 'bell' };
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  el.innerHTML = `${icon(names[type] || 'sparkles')}<span>${esc(msg)}</span>`
    + (opts.action ? `<button class="toast-act">${esc(opts.action.label)}</button>` : '');
  if (opts.action) {
    el.querySelector('.toast-act').addEventListener('click', () => {
      try { opts.action.fn(); } catch (e) { }
      el.classList.add('out'); setTimeout(() => el.remove(), 320);
    });
  }
  root.appendChild(el);
  sfx(type === 'success' ? 'check' : type === 'error' ? 'error' : type === 'warn' ? 'warn' : 'tap');
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 320); }, opts.ms || 2600);
}

/* ---------------- MODAL ---------------- */
export const modal = {
  stack: [],
  open({ title = '', icon: ic = 'sparkles', body = '', size = '', footer = '', onMount, closable = true }) {
    const back = document.createElement('div');
    back.className = 'modal';
    back.innerHTML = `
      <div class="modal-card ${size}" role="dialog" aria-modal="true">
        <div class="modal-head">
          <div class="modal-title">${ic ? icon(ic) : ''}<span>${esc(title)}</span></div>
          ${closable ? `<button class="btn icon-only ghost" data-close title="Yopish">${icon('x')}</button>` : ''}
        </div>
        <div class="modal-body">${body}</div>
        ${footer ? `<div class="modal-foot">${footer}</div>` : ''}
      </div>`;
    $('#modalRoot').appendChild(back);
    const api = {
      root: back,
      body: back.querySelector('.modal-body'),
      foot: back.querySelector('.modal-foot'),
      close: () => {
        back.classList.add('closing');
        setTimeout(() => back.remove(), 200);
        this.stack = this.stack.filter((m) => m !== api);
        if (!this.stack.length) document.body.style.overflow = '';
      },
    };
    this.stack.push(api);
    document.body.style.overflow = 'hidden';
    sfx('open');
    back.addEventListener('mousedown', (e) => { if (e.target === back && closable) api.close(); });
    back.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => { sfx('close'); api.close(); }));
    if (onMount) onMount(api);
    return api;
  },
  closeAll() { [...this.stack].forEach((m) => m.close()); },
};
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && modal.stack.length) modal.stack[modal.stack.length - 1].close();
});

/* ---------------- DIALOGS ---------------- */
export function confirmDialog(title, text, { danger = false, okLabel = 'Tasdiqlash', icon: ic = 'shield' } = {}) {
  return new Promise((resolve) => {
    const m = modal.open({
      title, icon: ic, size: 'small',
      body: `<div class="warnbox ${danger ? 'danger' : 'info'}">${icon('sparkles')}<div>${esc(text)}</div></div>`,
      footer: `<button class="btn ghost" data-no>Bekor qilish</button><button class="btn ${danger ? 'danger' : 'primary'}" data-yes>${esc(okLabel)}</button>`,
    });
    m.root.querySelector('[data-no]').onclick = () => { m.close(); resolve(false); };
    m.root.querySelector('[data-yes]').onclick = () => { m.close(); resolve(true); };
  });
}
export function promptDialog(title, label, { value = '', type = 'text', icon: ic = 'pencil', placeholder = '' } = {}) {
  return new Promise((resolve) => {
    const m = modal.open({
      title, icon: ic, size: 'small',
      body: `<div class="field"><label>${esc(label)}</label><input class="input" id="pdInput" type="${type}" value="${esc(value)}" placeholder="${esc(placeholder)}"></div>`,
      footer: `<button class="btn ghost" data-no>Bekor qilish</button><button class="btn primary" data-yes>Saqlash</button>`,
    });
    const inp = m.root.querySelector('#pdInput');
    setTimeout(() => { inp.focus(); inp.select(); }, 80);
    const done = () => { const v = inp.value; m.close(); resolve(v); };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') done(); });
    m.root.querySelector('[data-no]').onclick = () => { m.close(); resolve(null); };
    m.root.querySelector('[data-yes]').onclick = done;
  });
}

/* ---------------- MOTION HELPERS ---------------- */
export function animateNumber(el, from, to, { ms = 900, fmt } = {}) {
  if (!el) return;
  const f = fmt || ((v) => Math.round(v).toLocaleString('en-US'));
  const t0 = performance.now();
  const step = (t) => {
    const p = Math.min(1, (t - t0) / ms);
    const e = 1 - Math.pow(1 - p, 3);
    el.textContent = f(from + (to - from) * e);
    if (p < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}
export function ripple(x, y, color) {
  const root = $('#fxRipples'); if (!root) return;
  /* bir vaqtda 6 tadan ko'p to'lqin bo'lmasin (qatlamlar ko'payib ketmasin) */
  while (root.childElementCount >= 6) root.firstElementChild.remove();
  const r = document.createElement('span');
  r.className = 'ripple';
  r.style.left = x + 'px'; r.style.top = y + 'px';
  if (color) r.style.borderColor = color;
  r.addEventListener('animationend', () => r.remove(), { once: true });
  root.appendChild(r);
  setTimeout(() => { if (r.isConnected) r.remove(); }, 900);
}
export function countUpAll(root = document) {
  /* Bitta umumiy rAF tsikli — o'nlab raqam uchun o'nlab tsikl ochilmaydi */
  const els = $$('[data-count]', root);
  if (!els.length) return;
  const items = els.map((el) => ({ el, to: Number(el.dataset.count) || 0 }));
  const t0 = performance.now(), ms = 900;
  const tick = (t) => {
    const p = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - p, 3);
    for (let i = 0; i < items.length; i++) items[i].el.textContent = Math.round(items[i].to * e).toLocaleString('en-US');
    if (p < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}
export function barFill(root = document) {
  /* Bitta rAF + transform:scaleX — width animatsiyasi layout thrash beradi */
  const els = $$('.progress-fill[data-w]', root);
  if (!els.length) return;
  requestAnimationFrame(() => {
    for (let i = 0; i < els.length; i++) {
      els[i].style.transform = 'scaleX(' + (clamp(els[i].dataset.w) / 100) + ')';
    }
  });
}
