/* ============================================================
   KHUMOYUN OS — Qidiruv + Sozlamalar (profil, PIN, mavzu, UI, fon, menyu, ovoz, data)
   ============================================================ */
import { $, $$, esc, icon, on, toast, sfx, uid, modal, confirmDialog, promptDialog, fmtDate, todayISO, clamp, humanSize, sound, ambient, download, DAYS_UZ, SOUND_PACKS, playSampleUrl } from './util.js';
import { PRESET_UI, BUILD as APP_BUILD, BUILD_DATE as APP_BUILD_DATE, hardRefresh, checkUpdate } from './app.js';
import { state, save, saveNow, money, exportAll, exportJSON, importFile, wipeAll, media, setPin, verifyPin, netWorth, DEFAULT_NAV, mediaFromFile } from './store.js';
import { pageHead, section, empty, bar, kpi, statMini, kv, thumb, editBtn, delBtn } from './kit.js';
import { fillMedia, openForm, SCHEMAS, pickFiles, pickFile, mediaPicker } from './form.js';

export const THEMES = [
  ['emerald', 'Yashil · qora', ['#22e07a', '#0d7f6f', '#0a1119']],
  ['ocean', 'Ko\'k · qora', ['#38b6ff', '#7c5cff', '#08111c']],
  ['crimson', 'Qizil · sariq', ['#ff4d5e', '#ffc247', '#150a0d']],
  ['violet', 'Siyohrang', ['#b06bff', '#ff6bd6', '#100a1c']],
  ['sunset', 'Zarhal (sunset)', ['#ff7a45', '#ffd166', '#170d08']],
  ['mono', 'Oq · qora', ['#e8eef6', '#9fb2c8', '#0b0f14']],
];
export const PRESETS = [
  ['glass', 'Glass', 'Shisha effekt, kuchli blur'],
  ['solid', 'Solid', 'To\'liq quyuq panellar'],
  ['neon', 'Neon', 'Yorqin chegaralar, kuchli glow'],
  ['minimal', 'Minimal', 'Yengil, ingichka dizayn'],
  ['cinematic', 'Cinematic', 'Chuqur blur, kino uslubi'],
];
const TABS = [
  ['profile', 'Profil', 'user'], ['security', 'Xavfsizlik', 'shield'], ['appearance', 'Ko\'rinish / UI', 'palette'],
  ['background', 'Fon (rasm/video)', 'image'], ['menus', 'Menyular', 'list'], ['sound', 'Ovoz', 'volume'],
  ['data', 'Ma\'lumotlar', 'coins'], ['about', 'Yordam', 'sparkles'],
];

/* ================= SEARCH ================= */
export function renderSearch(view, ctx) {
  const q = (ctx.query.get('q') || '').trim();
  const low = q.toLowerCase();
  const hit = (s) => String(s || '').toLowerCase().includes(low);
  const mark = (s) => {
    const t = esc(s || '');
    if (!q) return t;
    const i = t.toLowerCase().indexOf(low);
    if (i < 0) return t;
    return t.slice(0, i) + '<mark>' + t.slice(i, i + q.length) + '</mark>' + t.slice(i + q.length);
  };
  const groups = [];
  if (q) {
    groups.push({
      title: 'Hisoblar', icon: 'wallet', route: 'cash',
      items: state.accounts.filter((a) => hit(a.name) || hit(a.note)).map((a) => ({ id: a.id, title: a.name, sub: money(a.balance, { sensitive: true, currency: a.currency }) })),
    });
    groups.push({
      title: 'Tradlar', icon: 'chart', route: 'journal',
      items: state.trades.filter((t) => hit(t.pair) || hit(t.notes) || hit(t.strategy) || (t.tags || []).some(hit)).map((t) => ({ id: t.id, title: `${t.pair} · ${t.side === 'long' ? 'LONG' : 'SHORT'}`, sub: `${fmtDate(t.date)} · ${money(t.pnl)}` })),
    });
    groups.push({
      title: 'Maqsadlar', icon: 'target', route: 'goals',
      items: state.goals.filter((g) => hit(g.title) || hit(g.note)).map((g) => ({ id: g.id, title: g.title, sub: `${money(g.saved || 0)} / ${money(g.target || 0)}` })),
    });
    groups.push({
      title: 'Xohishlar', icon: 'star', route: 'wishlist',
      items: state.wishes.filter((w) => hit(w.title) || hit(w.note)).map((w) => ({ id: w.id, title: w.title, sub: money(w.price || 0) })),
    });
    groups.push({
      title: 'Izohlar', icon: 'note', route: 'notes',
      items: state.notes.filter((n) => hit(n.title) || hit(n.body) || (n.tags || []).some(hit)).map((n) => ({ id: n.id, title: n.title, sub: (n.body || '').slice(0, 70) })),
    });
    const tasks = [];
    Object.entries(state.tasks).forEach(([d, list]) => list.forEach((t) => { if (hit(t.text) || hit(t.note)) tasks.push({ id: t.id + '|' + d, title: t.text, sub: fmtDate(d) + (t.done ? ' · bajarilgan' : '') }); }));
    groups.push({ title: 'Vazifalar', icon: 'calendar', route: 'tasks', items: tasks });
    groups.push({
      title: 'Musiqa', icon: 'music', route: 'music',
      items: state.music.tracks.filter((t) => hit(t.title) || hit(t.artist)).map((t) => ({ id: t.id, title: t.title, sub: t.artist || 'Noma\'lum' })),
    });
    groups.push({
      title: 'Jildlar', icon: 'folder', route: 'music',
      items: state.music.folders.filter((f) => hit(f.name)).map((f) => ({ id: f.id, title: f.name, sub: `${state.music.tracks.filter((t) => t.folder === f.id).length} trek` })),
    });
  }
  const total = groups.reduce((s, g) => s + g.items.length, 0);
  const nonEmpty = groups.filter((g) => g.items.length);
  view.innerHTML = `<div class="stagger">
    ${pageHead({ title: 'Qidiruv', icon: 'search', badge: 'global izlash', sub: 'Hisoblar, tradlar, maqsadlar, izohlar, vazifalar va musiqadan bir zumda toping' })}
    <div class="card" style="margin-bottom:18px">
      <div class="top-search" style="max-width:100%">
        ${icon('search')}
        <input id="gSearch" placeholder="Nima izlayapsiz?" value="${esc(q)}" autocomplete="off" style="font-size:16px">
        <kbd>Enter</kbd>
      </div>
      <div class="chips" style="margin-top:12px">
        ${['trad', 'maqsad', 'musiqa', 'izoh', 'vazifa', 'cash'].map((w) => `<button class="chip" data-q="${w}">${w}</button>`).join('')}
      </div>
    </div>
    ${q ? (nonEmpty.length ? `<div class="tiny faint" style="margin-bottom:10px">${total} natija topildi</div>
      <div class="col" style="gap:16px">${nonEmpty.map((g) => `<div class="card">
        <div class="card-h"><div class="card-t">${icon(g.icon)}${esc(g.title)}</div>
          <button class="btn sm ghost" data-go="${g.route}">${icon('right')}Bo'limga o'tish</button></div>
        <div class="list">${g.items.slice(0, 8).map((it) => `<div class="item" data-go="${g.route}">
          <div class="avatar sm">${icon(g.icon)}</div>
          <div class="item-main"><div class="item-title search-hit">${mark(it.title)}</div><div class="item-sub">${mark(it.sub)}</div></div>
        </div>`).join('')}</div>
      </div>`).join('')}</div>`
      : empty({ icon: 'search', title: 'Natija topilmadi', sub: `«${q}» bo'yicha hech narsa yo'q — boshqa so'z bilan urinib ko'ring` }))
      : empty({ icon: 'sparkles', title: 'Qidiruvga so\'z yozing', sub: 'Masalan: XAUUSD, iPhone, maqsad nomi yoki mp3 nomi' })}
  </div>`;
  const inp = view.querySelector('#gSearch');
  if (inp) { inp.focus(); inp.addEventListener('input', (e) => { const v = e.target.value; const p = e.target.selectionStart; ctx.go('search', { q: v }).then(() => { const el = view.querySelector('#gSearch'); if (el) { el.focus(); el.setSelectionRange(p, p); } }); }); }
  on(view, 'click', '[data-q]', (e, b) => ctx.go('search', { q: b.dataset.q }));
}

/* ================= PROFILE ================= */
function tabProfile(view, ctx) {
  const p = state.profile;
  view.innerHTML = `<div class="stagger">
    ${pageHead({ title: 'Profil', icon: 'user', badge: 'sozlamalar', sub: 'Ism, rasm va shaxsiy ma\'lumotlaringiz',
    actions: `<button class="btn primary sm" data-act="edit-profile">${icon('pencil')}Profilni tahrirlash</button>` })}
    <div class="grid g2">
      <div class="card">
        <div class="row" style="gap:16px">
          <div style="width:104px;flex:0 0 auto">${thumb(p.avatar, { ratio: '1:1', pos: p.avatar_pos, zoom: p.avatar_zoom, icon: 'user', style: 'border-radius:26px' })}</div>
          <div class="grow">
            <div class="h2">${esc(p.name || 'Ism yo\'q')}</div>
            <div class="muted">${esc(p.role || '—')}</div>
            <div class="tiny faint" style="margin-top:6px">${esc(p.motto || '')}</div>
            <div class="row" style="gap:8px;margin-top:12px">
              <button class="btn sm soft" data-act="edit-profile">${icon('pencil')}Tahrirlash</button>
              <button class="btn sm ghost" data-act="edit-avatar">${icon('image')}Rasm</button>
            </div>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('doc')}Shaxsiy ma'lumotlar</div>
          <button class="icon-btn" data-act="edit-profile" title="Tahrirlash (qalamcha)">${icon('pencil')}</button></div>
        ${kv([
      ['Ism', esc(p.name || '—')], ['Rol', esc(p.role || '—')], ['Email', p.email ? `<a href="mailto:${esc(p.email)}">${esc(p.email)}</a>` : '—'],
      ['Telefon', p.phone ? `<a href="tel:${esc(p.phone)}">${esc(p.phone)}</a>` : '—'],
      ['Shahar', esc(p.country || '—')], ['Tug\'ilgan kun', p.birthday ? fmtDate(p.birthday) : '—'],
      ['Valyuta', esc(state.settings.currency)], ['Hisoblar', String(state.accounts.length)],
    ])}
        ${p.about ? `<div class="divider"></div><div class="tiny" style="white-space:pre-wrap">${esc(p.about)}</div>` : ''}
      </div>
    </div>
    <div class="grid g4" style="margin-top:16px">
      ${kpi({ label: 'Net Worth', value: money(netWorth(), { sensitive: true }), icon: 'dash' })}
      ${kpi({ label: 'Tradlar', value: String(state.trades.length), icon: 'chart' })}
      ${kpi({ label: 'Maqsadlar', value: String(state.goals.length), icon: 'target' })}
      ${kpi({ label: 'Izohlar', value: String(state.notes.length), icon: 'note' })}
    </div>
  </div>`;
  fillMedia(view);
  on(view, 'click', '[data-act]', (e, b) => {
    if (b.dataset.act === 'edit-profile') {
      openForm({
        title: 'Profilni tahrirlash', icon: 'user', schema: SCHEMAS.profile, data: { ...state.profile },
        onSave: (v) => {
          Object.assign(state.profile, v); save();
          if (v.name && state.profile.name !== v.name) { }
          toast('Profil saqlandi', { type: 'success' });
          if (typeof ctx.applyUi === 'function') ctx.applyUi();
          ctx.refresh();
        },
      });
    }
    if (b.dataset.act === 'edit-avatar') {
      openForm({
        title: 'Profil rasmi', icon: 'image',
        schema: [{ k: 'avatar', l: 'Profil rasmi (1:1)', t: 'ratioImage', ratio: '1:1', lockRatio: true, w: 200 }],
        data: { avatar: state.profile.avatar, avatar_pos: state.profile.avatar_pos, avatar_zoom: state.profile.avatar_zoom },
        onSave: (v) => { Object.assign(state.profile, v); save(); toast('Rasm yangilandi', { type: 'success' }); ctx.applyUi(); ctx.refresh(); },
      });
    }
  });
}

/* ================= SECURITY ================= */
function tabSecurity(view, ctx) {
  const s = state.security;
  view.innerHTML = `<div class="stagger">
    ${pageHead({ title: 'Xavfsizlik', icon: 'shield', badge: 'sozlamalar', sub: 'PIN kod, avto-qulf va zaxira nusxa' })}
    <div class="grid g2">
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('lock')}PIN kod</div></div>
        <div class="col">
          <div class="warnbox info">${icon('shield')}<div>PIN kod mahalliy qurilmada shifrlangan (SHA-256) holda saqlanadi. Internetga hech narsa yuborilmaydi.</div></div>
          <div class="switch-row"><span>${icon('lock')}Kirishda PIN so'rash</span>
            <button class="switch ${s.lockOnStart ? 'on' : ''}" data-switch="lockOnStart"></button></div>
          <div class="field"><label>${icon('clock')}Harakatsizlikdan keyin qulflash (daqiqa, 0 = o'chirilgan)</label>
            <input class="input" type="number" min="0" max="240" value="${s.autoLock || 0}" data-auto-lock></div>
          <div class="field"><label>${icon('sparkles')}PIN uchun eslatma (yordam)</label>
            <input class="input" data-hint value="${esc(s.hint || '')}" placeholder="Masalan: tug'ilgan yilim"></div>
          <div class="row wrap" style="gap:8px;margin-top:6px">
            <button class="btn soft sm" data-act="change-pin">${icon('refresh')}PIN kodni almashtirish</button>
            <button class="btn ghost sm" data-act="lock-now">${icon('lock')}Hozir qulflash</button>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('shield')}Xavfsizlik hisoboti</div></div>
        ${kv([
      ['PIN o\'rnatilgan', s.pinHash ? '<span class="badge win">Ha</span>' : '<span class="badge loss">Yo\'q</span>'],
      ['Oxirgi yangilanish', esc(fmtDate(s.changedAt || state.createdAt))],
      ['Avto-qulf', s.autoLock ? `${s.autoLock} daqiqa` : 'O\'chirilgan'],
      ['Ma\'lumot joyi', 'Brauzer (localStorage + IndexedDB)'],
      ['Offline ishlash', 'Ha — Service Worker'],
    ])}
        <div class="divider"></div>
        <div class="col">
          <div class="warnbox danger">${icon('trash')}<div><b>Diqqat:</b> barcha ma'lumotlarni o'chirish. Avval eksport qilib oling!</div></div>
          <div class="row" style="gap:8px">
            <button class="btn danger sm" data-act="wipe-data">${icon('trash')}Hamma ma'lumotni o'chirish</button>
            <button class="btn ghost sm" data-act="wipe-pin">${icon('lock-open')}PIN ni olib tashlash</button>
          </div>
        </div>
      </div>
    </div>
  </div>`;
  const sw = view.querySelector('[data-switch="lockOnStart"]');
  if (sw) sw.addEventListener('click', () => {
    sw.classList.toggle('on'); state.security.lockOnStart = sw.classList.contains('on'); saveNow();
    sfx(sw.classList.contains('on') ? 'check' : 'uncheck');
  });
  const al = view.querySelector('[data-auto-lock]');
  if (al) al.addEventListener('change', () => { state.security.autoLock = clamp(al.value, 0, 240); saveNow(); toast('Avto-qulf saqlandi', { type: 'success' }); });
  const hint = view.querySelector('[data-hint]');
  if (hint) hint.addEventListener('change', () => { state.security.hint = hint.value; saveNow(); });
  on(view, 'click', '[data-act]', async (e, b) => {
    const act = b.dataset.act;
    if (act === 'change-pin') {
      const old = await promptDialog('Hozirgi PIN', 'Eski PIN kodni kiriting', { type: 'password', icon: 'lock' });
      if (old == null) return;
      if (!(await verifyPin(old))) { sfx('error'); return toast('Eski PIN xato', { type: 'error' }); }
      const np = await promptDialog('Yangi PIN', '4–6 xonali yangi PIN kiriting', { type: 'password', icon: 'lock' });
      if (!np || np.length < 4) { return toast('PIN kamida 4 xonali bo\'lishi kerak', { type: 'warn' }); }
      const np2 = await promptDialog('Tasdiqlash', 'Yangi PIN ni qayta kiriting', { type: 'password', icon: 'check' });
      if (np !== np2) { sfx('error'); return toast('PIN lar mos kelmadi', { type: 'error' }); }
      await setPin(np); s.changedAt = new Date().toISOString(); saveNow();
      sfx('success'); toast('PIN kod almashtirildi', { type: 'success' });
      return;
    }
    if (act === 'lock-now') return ctx.lockNow();
    if (act === 'wipe-data') {
      const ok = await confirmDialog('Hamma ma\'lumotni o\'chirish?', 'Hisoblar, tradlar, maqsadlar, izohlar, musiqa — barchasi o\'chadi. Avval eksport qilib oling!', { danger: true, okLabel: 'Hammasini o\'chirish' });
      if (!ok) return;
      await wipeAll(true); sfx('delete'); toast('Barcha ma\'lumotlar o\'chirildi', { type: 'warn' }); ctx.refresh(); return;
    }
    if (act === 'wipe-pin') {
      const ok = await confirmDialog('PIN kodni olib tashlash?', 'Keyingi ochilishda PIN so\'ralmaydi.', { danger: true, okLabel: 'Olib tashlash' });
      if (!ok) return;
      state.security.pinHash = ''; state.security.salt = ''; saveNow();
      toast('PIN olib tashlandi', { type: 'warn' }); ctx.refresh(); return;
    }
  });
}

/* ================= APPEARANCE / UI ================= */
function tabAppearance(view, ctx) {
  const ui = state.settings.ui, fx = state.settings.effects;
  const slider = (k, label, ic, val, min, max, unit = '') => `
    <div class="field"><label>${icon(ic)}${esc(label)}</label>
      <div class="range-row"><input type="range" data-ui="${k}" min="${min}" max="${max}" value="${val}" style="--fill:${((val - min) / (max - min)) * 100}%">
        <span class="range-val" data-ui-val="${k}">${val}${unit}</span></div></div>`;
  view.innerHTML = `<div class="stagger">
    ${pageHead({ title: 'Ko\'rinish va UI', icon: 'palette', badge: 'sozlamalar', sub: 'Mavzu rangini, panel uslubini va animatsiya kuchini boshqaring' })}
    ${section({
    title: 'Rang mavzusi', icon: 'palette', sub: 'Qizil-sariq, yashil-qora, ko\'k-qora va boshqalar',
    body: `<div class="theme-grid">
        ${THEMES.map(([k, label, dots]) => `<button class="theme-swatch ${state.settings.theme === k ? 'active' : ''}" data-theme="${k}">
          <div class="sw-dots">${dots.map((d) => `<i style="background:${d}"></i>`).join('')}</div>
          <div class="item-title" style="font-size:13px">${esc(label)}</div>
          <div class="tiny faint">${k}</div>
        </button>`).join('')}
      </div>`
  })}
    ${section({
    title: 'UI formati (panellar uslubi)', icon: 'grid', sub: 'Fon videosi qo\'yilganda ham menyular shunga moslashadi',
    body: `<div class="theme-grid">
        ${PRESETS.map(([k, label, desc]) => {
      const p = PRESET_UI[k] || PRESET_UI.glass;
      const rgb = p.tint === 'solid' ? '20,26,34' : '255,255,255';
      return `<button class="theme-swatch preset-card ${state.settings.preset === k ? 'active' : ''}" data-preset="${k}">
          <div class="preset-prev pp-${k}" style="--pv-rgb:${rgb};--pv-a:${p.panelAlpha / 100};--pv-b:${p.borderAlpha / 100};--pv-glass:${p.glass}px;--pv-radius:${p.radius}px;--pv-sh:${p.shadow}">
            <div class="pp-side"></div>
            <div class="pp-main"><div class="pp-bar"></div><div class="pp-card"></div></div>
            <div class="pp-accent"></div>
          </div>
          <div class="item-title">${esc(label)}</div><div class="tiny faint">${esc(desc)}</div></button>`;
    }).join('')}
      </div>`
  })}
    ${section({
    title: 'Interfeys o\'lchamlari', icon: 'sliders', sub: 'Real vaqtda qo\'llaniladi',
    body: `<div class="grid g2">
        <div class="card">
          ${slider('glass', 'Panel xiraligi (glass blur)', 'sparkles', ui.glass, 0, 44, 'px')}
          ${slider('radius', 'Burchak radiusi', 'grid', ui.radius, 0, 40, 'px')}
          ${slider('panelAlpha', 'Panel shaffofligi', 'eye', Math.round(ui.panelAlpha), 2, 70, '%')}
          ${slider('borderAlpha', 'Chegara (border) kuchliligi', 'list', Math.round(ui.borderAlpha == null ? 11 : ui.borderAlpha), 0, 40, '%')}
          ${slider('shadow', 'Soyalar chuqurligi', 'sparkles', Math.round((ui.shadow == null ? 1 : ui.shadow) * 100), 0, 200, '%')}
          ${slider('dim', 'Fon qoraytirish', 'image', ui.dim, 0, 90, '%')}
        </div>
        <div class="card">
          ${slider('fontScale', 'Shrift kattaligi', 'doc', ui.fontScale, 85, 125, '%')}
          ${slider('anim', 'Animatsiya kuchi', 'sparkles', ui.anim, 0, 150, '%')}
          <div class="field"><label>${icon('list')}Zichlik</label>
            <select class="select" data-density>
              <option value="cozy" ${ui.density === 'cozy' ? 'selected' : ''}>Qulay (cozy)</option>
              <option value="compact" ${ui.density === 'compact' ? 'selected' : ''}>Ixcham (compact)</option>
              <option value="roomy" ${ui.density === 'roomy' ? 'selected' : ''}>Keng (roomy)</option>
            </select></div>
          <div class="field"><label>${icon('calendar')}Hafta boshlanishi</label>
            <select class="select" data-weekstart>
              <option value="1" ${state.settings.weekStart === 1 ? 'selected' : ''}>Dushanba</option>
              <option value="0" ${state.settings.weekStart === 0 ? 'selected' : ''}>Yakshanba</option>
            </select></div>
          <div class="row wrap" style="gap:8px">
            <button class="btn ghost sm" data-act="reset-ui">${icon('refresh')}Standart holatga qaytarish</button>
          </div>
        </div>
      </div>`
  })}
    ${section({
    title: 'Effektlar (motion)', icon: 'sparkles', sub: 'Animatsiyalar va jonli effektlar',
    body: `<div class="grid g2">
        ${[['particles', 'Zarrachalar (particle) effekti', 'sparkles'], ['cursorGlow', 'Kursor nur effekti', 'cursor'],
      ['ripple', 'Bosilganda to\'lqin (ripple)', 'target'], ['tilt', 'Kartalar 3D burchagi', 'grid']].map(([k, label, ic]) => `
          <div class="switch-row"><span>${icon(ic)}${esc(label)}</span>
            <button class="switch ${fx[k] ? 'on' : ''}" data-fx="${k}"></button></div>`).join('')}
      </div>
      <div class="field" style="margin-top:14px"><label>${icon('sliders')}Ishlash rejimi (tezlik)</label>
        <select class="select" data-perf>
          <option value="auto" ${(state.settings.perf || 'auto') === 'auto' ? 'selected' : ''}>Avtomatik — qurilmaga moslashadi (tavsiya)</option>
          <option value="full" ${state.settings.perf === 'full' ? 'selected' : ''}>To'liq effektlar — kuchli kompyuter uchun</option>
          <option value="lite" ${state.settings.perf === 'lite' ? 'selected' : ''}>Yengil rejim — sayt sekin ishlasa</option>
        </select>
        <div class="tiny faint" style="margin-top:6px">Yengil rejim zarrachalar, aurora va og'ir blur effektlarini kamaytiradi — sahifalar bir zumda ochiladi.</div></div>`
  })}
  </div>`;
  on(view, 'click', '[data-theme]', (e, b) => {
    state.settings.theme = b.dataset.theme; save();
    document.documentElement.dataset.theme = b.dataset.theme;
    ctx.applyUi();
    sfx('success'); toast(`Mavzu: ${b.dataset.theme}`, { type: 'success' }); ctx.refresh();
  });
  on(view, 'click', '[data-preset]', async (e, b) => {
    /* applyPreset app.js da — dinamik import (aylanma bog'lanishsiz) */
    const { applyPreset } = await import('./app.js');
    sfx('success');
    applyPreset(b.dataset.preset);
    ctx.refresh();
  });
  on(view, 'click', '[data-fx]', (e, b) => {
    const k = b.dataset.fx; state.settings.effects[k] = !state.settings.effects[k];
    b.classList.toggle('on'); save(); sfx('tap'); ctx.applyUi();
  });
  on(view, 'input', '[data-ui]', (e, b) => {
    const k = b.dataset.ui; const v = Number(b.value);
    state.settings.ui[k] = k === 'shadow' ? v / 100 : v;
    const val = view.querySelector(`[data-ui-val="${k}"]`);
    if (val) val.textContent = v + (k === 'glass' || k === 'radius' ? 'px' : '%');
    b.style.setProperty('--fill', ((v - b.min) / (b.max - b.min)) * 100 + '%');
    ctx.applyUi(); save();
  });
  const pf = view.querySelector('[data-perf]');
  if (pf) pf.addEventListener('change', async () => {
    state.settings.perf = pf.value; save();
    const { runPerfCheck } = await import('./app.js');
    runPerfCheck();
    sfx('tap');
    toast(pf.value === 'lite' ? 'Yengil rejim yoqildi' : pf.value === 'full' ? "To'liq effektlar yoqildi" : 'Avtomatik rejim — qurilma sinovdan o\'tmoqda…', { type: 'success' });
    ctx.refresh();
  });
  const den = view.querySelector('[data-density]');
  if (den) den.addEventListener('change', () => { state.settings.ui.density = den.value; save(); ctx.applyUi(); toast('Zichlik o\'zgardi', { type: 'success' }); });
  const ws = view.querySelector('[data-weekstart]');
  if (ws) ws.addEventListener('change', () => { state.settings.weekStart = Number(ws.value); save(); toast('Saqlandi', { type: 'success' }); });
  on(view, 'click', '[data-act="reset-ui"]', async () => {
    const { PRESET_UI } = await import('./app.js');
    const preset = PRESET_UI[state.settings.preset] || PRESET_UI.glass;
    state.settings.ui = { dim: 44, fontScale: 100, anim: 100, density: 'cozy', ...preset };
    Object.assign(state.settings.effects, { particles: true, cursorGlow: true, ripple: true, tilt: true });
    save(); ctx.applyUi(); sfx('success'); toast('UI standart holatga qaytdi', { type: 'success' }); ctx.refresh();
  });
}

/* ================= BACKGROUND ================= */
function bgPanel(which, title, ic, desc) {
  const bg = state.settings.bg[which];
  const isVid = bg.type === 'video';
  const zoom = bg.zoom || 100;
  return `<div class="card">
    <div class="card-h"><div class="card-t">${icon(ic)}${esc(title)}</div>
      <div class="row" style="gap:6px">
        <button class="btn sm" data-act="pick-bg" data-which="${which}">${icon('upload')}Rasm / Video</button>
        ${bg.mediaId ? `<button class="btn sm ghost" data-act="lib-bg" data-which="${which}">${icon('grid')}Kutubxona</button>
          <button class="btn sm danger" data-act="clear-bg" data-which="${which}">${icon('trash')}O'chirish</button>` : ''}
      </div></div>
    <div class="bg-preview" data-prev="${which}"
      style="--pv-blur:${(bg.blur * .6).toFixed(1)}px;--pv-zoom:${(zoom / 100).toFixed(3)};--pv-pos:${esc(bg.pos || '50% 50%')};--pv-dim:${(bg.dim / 100).toFixed(2)}">
      <div class="pv-demo"></div>
      ${bg.mediaId ? `<div class="pv-media" data-media="${esc(bg.mediaId)}"></div>` : ''}
      <div class="pv-dim"></div>
      <div class="pv-hint">${bg.mediaId ? (isVid ? 'VIDEO FON' : 'RASM FON') : 'NAMUNA — rasm yoki video tanlang'}</div>
      <div class="pv-meta" data-pv-meta="${which}">Blur ${bg.blur}px · Zoom ${zoom}% · Qoraytirish ${bg.dim}%</div>
    </div>
    <div class="tiny faint" style="margin:9px 0 14px">${esc(desc)}</div>
    <div class="field"><label>${icon('sparkles')}Xiralik (blur) — orqa fon yumshaydi</label>
      <div class="range-row"><input type="range" data-bg="blur" data-which="${which}" min="0" max="100" value="${bg.blur}" style="--fill:${bg.blur}%">
        <span class="range-val" data-bgv="blur" data-which-lab="${which}">${bg.blur}px</span></div></div>
    <div class="field"><label>${icon('zoom')}Kattalashtirish (zoom)</label>
      <div class="range-row"><input type="range" data-bg="zoom" data-which="${which}" min="100" max="220" value="${zoom}" style="--fill:${((zoom - 100) / 120) * 100}%">
        <span class="range-val" data-bgv="zoom" data-which-lab="${which}">${zoom}%</span></div></div>
    <div class="field"><label>${icon('eye')}Qoraytirish — matn o'qilishi uchun</label>
      <div class="range-row"><input type="range" data-bg="dim" data-which="${which}" min="0" max="95" value="${bg.dim}" style="--fill:${bg.dim}%">
        <span class="range-val" data-bgv="dim" data-which-lab="${which}">${bg.dim}%</span></div></div>
    <div class="row" style="gap:12px;align-items:flex-start">
      <div class="field grow"><label>${icon('left')}Kadr — chap / o'ng</label>
        <input type="range" data-bg="posx" data-which="${which}" min="0" max="100" value="${parseFloat(bg.pos) || 50}" style="--fill:${parseFloat(bg.pos) || 50}%"></div>
      <div class="field grow"><label>${icon('up-arrow')}Kadr — tepa / past</label>
        <input type="range" data-bg="posy" data-which="${which}" min="0" max="100" value="${parseFloat((bg.pos || '50% 50%').split(' ')[1]) || 50}" style="--fill:${parseFloat((bg.pos || '50% 50%').split(' ')[1]) || 50}%"></div>
    </div>
    <div class="row wrap" style="gap:7px;margin-top:10px">
      ${[['markaz', '50% 50%', 'target'], ['tepa', '50% 12%', 'up-arrow'], ['past', '50% 88%', 'down-arrow'],
      ['chap', '12% 50%', 'left'], ["o'ng", '88% 50%', 'right']].map(([l, p, i]) =>
        `<button class="btn ghost sm" data-kadr="${p}" data-which="${which}">${icon(i)}${l}</button>`).join('')}
    </div>
    ${which === 'main' ? `<div class="switch-row" style="margin-top:12px"><span>${icon('eye-off')}Faqat gradient ko'rinsin (rasm/videoni yashirish)</span>
      <button class="switch ${bg.hide ? 'on' : ''}" data-hide-bg></button></div>` : ''}
  </div>`;
}
function tabBackground(view, ctx) {
  view.innerHTML = `<div class="stagger">
    ${pageHead({
    title: 'Fon (rasm / video)', icon: 'image', badge: 'sozlamalar',
    sub: "Asosiy ekran va PIN (qulf) ekrani uchun alohida fon. Blur, zoom va kadrni shu yerda sozlaysiz.",
    actions: `<button class="btn ghost sm" data-act="reset-bg">${icon('refresh')}Standart holat</button>`
  })}
    <div class="warnbox info" style="margin-bottom:16px">${icon('sparkles')}<div>Fon <b>faqat orqada</b> turadi — panellar, yozuvlar va tugmalar hech qachon xiralashmaydi. Siz faqat orqa fonning xiraligini boshqarasiz.</div></div>
    <div class="grid g2">
      ${bgPanel('main', 'Asosiy ekran foni', 'dash', "Tizim ochilganda orqada ko'rinadi. Video bo'lsa avtomatik, ovozsiz va takrorlanib ijro etiladi.")}
      ${bgPanel('lock', 'PIN / qulf ekrani foni', 'lock', 'PIN kiritish ekranida alohida fon — telefon blokirovka ekraniga o\'xshab.')}
    </div>
  </div>`;
  fillMedia(view);
  $$('.bg-preview video, .bg-preview img', view).forEach((el) => { if (el.tagName === 'VIDEO') { el.autoplay = true; el.muted = true; el.loop = true; el.play && el.play().catch(() => { }); } });
  const syncPrev = (which) => {
    const bg = state.settings.bg[which];
    const el = view.querySelector(`[data-prev="${which}"]`);
    if (!el) return;
    el.style.setProperty('--pv-blur', (bg.blur * .6).toFixed(1) + 'px');
    el.style.setProperty('--pv-zoom', (bg.zoom || 100) / 100);
    el.style.setProperty('--pv-pos', bg.pos || '50% 50%');
    el.style.setProperty('--pv-dim', (bg.dim / 100).toFixed(2));
    const meta = el.querySelector('[data-pv-meta]');
    if (meta) meta.textContent = `Blur ${bg.blur}px · Zoom ${bg.zoom || 100}% · Qoraytirish ${bg.dim}%`;
  };
  on(view, 'click', '[data-act]', async (e, b) => {
    const act = b.dataset.act, which = b.dataset.which;
    if (act === 'pick-bg') {
      const files = await pickFiles('image/*,video/*');
      if (!files.length) return;
      const f = files[0];
      const isVid = (f.type || '').startsWith('video/');
      if (isVid && f.size > 140 * 1024 * 1024) { toast('Video juda katta (140MB dan oshmasin)', { type: 'warn' }); return; }
      toast('Yuklanmoqda…', { type: 'info' });
      const { mediaFromFile } = await import('./store.js');
      const rec = await mediaFromFile(f, { maxDim: isVid ? 0 : 2600 });
      const bg = state.settings.bg[which];
      bg.mediaId = rec.id; bg.type = isVid ? 'video' : 'image';
      if (!bg.zoom || bg.zoom < 100) bg.zoom = 100;
      save(); ctx.applyUi(); sfx('success'); toast('Fon yuklandi', { type: 'success' }); ctx.refresh();
      return;
    }
    if (act === 'lib-bg') {
      const chosen = await mediaPicker({ type: 'all', title: 'Fon uchun fayl tanlang' });
      if (!chosen) return;
      const bg = state.settings.bg[which];
      bg.mediaId = chosen.id;
      bg.type = (chosen.type || '').startsWith('video/') ? 'video' : 'image';
      save(); ctx.applyUi(); ctx.refresh(); return;
    }
    if (act === 'clear-bg') {
      const bg = state.settings.bg[which]; bg.mediaId = null; bg.type = 'none';
      save(); ctx.applyUi(); sfx('delete'); toast('Fon olib tashlandi', { type: 'warn' }); ctx.refresh(); return;
    }
    if (act === 'reset-bg') {
      state.settings.bg = {
        main: { mediaId: null, type: 'none', blur: 0, dim: 44, pos: '50% 50%', zoom: 100, hide: false },
        lock: { mediaId: null, type: 'none', blur: 18, dim: 48, pos: '50% 50%', zoom: 100 },
      };
      save(); ctx.applyUi(); toast('Fonlar standart holatga qaytdi', { type: 'success' }); ctx.refresh(); return;
    }
  });
  on(view, 'click', '[data-kadr]', (e, b) => {
    const which = b.dataset.which;
    state.settings.bg[which].pos = b.dataset.kadr;
    const el = view.querySelector(`[data-prev="${which}"]`);
    if (el) {
      $$(`[data-bg="posx"][data-which="${which}"]`, view).forEach((i) => { i.value = parseFloat(b.dataset.kadr); i.style.setProperty('--fill', i.value + '%'); });
      $$(`[data-bg="posy"][data-which="${which}"]`, view).forEach((i) => { i.value = parseFloat(String(b.dataset.kadr).split(' ')[1]); i.style.setProperty('--fill', i.value + '%'); });
    }
    syncPrev(which); ctx.applyUi(); save(); sfx('tap');
  });
  on(view, 'input', '[data-bg]', (e, b) => {
    const which = b.dataset.which, k = b.dataset.bg, v = Number(b.value);
    const bg = state.settings.bg[which];
    if (k === 'blur' || k === 'dim' || k === 'zoom') {
      bg[k] = v;
      const lab = view.querySelector(`[data-bgv="${k}"][data-which-lab="${which}"]`);
      if (lab) lab.textContent = v + (k === 'blur' ? 'px' : '%');
    } else if (k === 'posx' || k === 'posy') {
      const cur = String(bg.pos || '50% 50%').split(' ');
      const px = k === 'posx' ? v : (parseFloat(cur[0]) || 50);
      const py = k === 'posy' ? v : (parseFloat(cur[1]) || 50);
      bg.pos = `${px}% ${py}%`;
    }
    b.style.setProperty('--fill', ((v - b.min) / (b.max - b.min)) * 100 + '%');
    syncPrev(which);
    ctx.applyUi(); save();
  });
  on(view, 'click', '[data-hide-bg]', (e, b) => {
    const bg = state.settings.bg.main; bg.hide = !bg.hide;
    b.classList.toggle('on'); save(); ctx.applyUi(); sfx('tap');
    syncPrev('main');
  });
}

/* ================= MENUS ================= */
export const NAV_META = {
  dashboard: ['Net Worth', 'dash'], cash: ['Cash', 'wallet'], journal: ['Trading Journal', 'chart'],
  goals: ['Maqsadlar', 'target'], wishlist: ['Wishlist', 'star'], notes: ['Izohlar', 'note'],
  tasks: ['Kunlik vazifalar', 'calendar'], music: ['Musiqa', 'music'], search: ['Qidiruv', 'search'], settings: ['Sozlamalar', 'sliders'],
};
function tabMenus(view, ctx) {
  const nav = state.settings.nav;
  view.innerHTML = `<div class="stagger">
    ${pageHead({ title: 'Menyular', icon: 'list', badge: 'sozlamalar',
    sub: 'Har bir menyuni tahrirlang: nomini o\'zgartirish, yashirish yoki tartibini almashtirish',
    actions: `<button class="btn ghost sm" data-act="reset-nav">${icon('refresh')}Standart holat</button>` })}
    <div class="warnbox info" style="margin-bottom:16px">${icon('pencil')}<div>Qalamcha tugmasi bilan menyu nomini o'zgartirasiz, ko'z tugmasi bilan yashirasiz, strelkalar bilan tartibini almashtirasiz.</div></div>
    <div class="card">
      <div class="col" style="gap:8px">
        ${nav.order.map((k, i) => {
    const [label, ic] = NAV_META[k] || [k, 'grid'];
    const hidden = nav.hidden.includes(k);
    const custom = nav.labels[k];
    return `<div class="item" style="opacity:${hidden ? .55 : 1}">
            <div class="avatar sm">${icon(ic)}</div>
            <div class="item-main">
              <div class="item-title">${esc(custom || label)} ${custom ? `<span class="badge accent">o'zgartirilgan</span>` : ''}</div>
              <div class="item-sub">${esc(k)}${hidden ? ' · yashirin' : ''}</div>
            </div>
            <div class="item-actions" style="opacity:1">
              <button class="icon-btn" data-act="nav-up" data-id="${k}" title="Yuqoriga" ${i === 0 ? 'disabled' : ''}>${icon('up-arrow')}</button>
              <button class="icon-btn" data-act="nav-down" data-id="${k}" title="Pastga" ${i === nav.order.length - 1 ? 'disabled' : ''}>${icon('down-arrow')}</button>
              <button class="icon-btn" data-act="nav-rename" data-id="${k}" title="Nomini o'zgartirish">${icon('pencil')}</button>
              <button class="icon-btn" data-act="nav-hide" data-id="${k}" title="${hidden ? 'Ko\'rsatish' : 'Yashirish'}">${icon(hidden ? 'eye-off' : 'eye')}</button>
              ${custom ? `<button class="icon-btn danger" data-act="nav-reset-name" data-id="${k}" title="Nomni qaytarish">${icon('x')}</button>` : ''}
            </div>
          </div>`;
  }).join('')}
      </div>
    </div>
    <div class="card" style="margin-top:16px">
      <div class="card-h"><div class="card-t">${icon('sparkles')}Namuna</div></div>
      <div class="nav-list" style="max-width:280px">
        ${nav.order.filter((k) => !nav.hidden.includes(k)).map((k) => {
    const [label, ic] = NAV_META[k] || [k, 'grid'];
    return `<div class="nav-item ${k === ctx.route ? 'active' : ''}">${icon(ic)}<span class="nav-label">${esc(state.settings.nav.labels[k] || label)}</span></div>`;
  }).join('')}
      </div>
    </div>
  </div>`;
  on(view, 'click', '[data-act]', async (e, b) => {
    const act = b.dataset.act, id = b.dataset.id, nav2 = state.settings.nav;
    const i = nav2.order.indexOf(id);
    if (act === 'nav-up' && i > 0) { nav2.order.splice(i, 1); nav2.order.splice(i - 1, 0, id); save(); sfx('tap'); return ctx.refresh(); }
    if (act === 'nav-down' && i < nav2.order.length - 1) { nav2.order.splice(i, 1); nav2.order.splice(i + 1, 0, id); save(); sfx('tap'); return ctx.refresh(); }
    if (act === 'nav-hide') {
      if (nav2.hidden.includes(id)) nav2.hidden = nav2.hidden.filter((x) => x !== id);
      else nav2.hidden.push(id);
      save(); ctx.applyUi(); sfx('tap'); return ctx.refresh();
    }
    if (act === 'nav-rename') {
      const [label] = NAV_META[id] || [id];
      const v = await promptDialog('Menyu nomini o\'zgartirish', 'Yangi nom kiriting', { value: nav2.labels[id] || label, icon: 'pencil' });
      if (v == null) return;
      if (v.trim()) nav2.labels[id] = v.trim(); else delete nav2.labels[id];
      save(); ctx.applyUi(); toast('Menyu nomi yangilandi', { type: 'success' }); return ctx.refresh();
    }
    if (act === 'nav-reset-name') { delete nav2.labels[id]; save(); ctx.applyUi(); return ctx.refresh(); }
    if (act === 'reset-nav') {
      nav2.order = [...DEFAULT_NAV]; nav2.labels = {}; nav2.hidden = [];
      save(); ctx.applyUi(); toast('Menyular standart holatga qaytdi', { type: 'success' }); return ctx.refresh();
    }
  });
}

/* ================= SOUND ================= */
const PACKS_LABEL = (k) => (SOUND_PACKS.find((p) => p[0] === k) || [, k])[1];
function tabSound(view, ctx) {
  const pack = state.settings.soundPack || 'glass';
  view.innerHTML = `<div class="stagger">
    ${pageHead({ title: 'Ovoz effektlari', icon: 'volume', badge: 'sozlamalar', sub: 'Har bir tugma, menyu va amal uchun ovozli javob' })}
    ${section({
    title: 'Ovoz paketi', icon: 'music', sub: "O'zingizga yoqqan uslubni tanlang — bosing va tinglang",
    body: `<div class="theme-grid">
        ${SOUND_PACKS.map(([k, label, desc]) => {
      const ic = k === 'retro' ? 'sparkles' : k === 'mech' ? 'grid' : k === 'bubble' ? 'heart' : k === 'marimba' ? 'music' : k === 'soft' ? 'volume' : 'bell';
      return `<button class="theme-swatch ${pack === k ? 'active' : ''}" data-pack="${k}">
          <div class="row" style="gap:8px"><div class="avatar sm">${icon(ic)}</div>
          <div class="item-title" style="font-size:13.5px">${esc(label)}</div>
          <span class="grow"></span><span class="tiny faint">${icon('play')}</span></div>
          <div class="tiny faint">${esc(desc)}</div></button>`;
    }).join('')}
      </div>`
  })}
    <div class="grid g2">
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('volume')}Asosiy ovoz</div></div>
        <div class="col">
          <div class="switch-row"><span>${icon('volume')}Ovoz effektlari yoqilgan</span>
            <button class="switch ${state.settings.sound ? 'on' : ''}" data-sfx></button></div>
          <div class="field"><label>${icon('sliders')}Ovoz balandligi</label>
            <div class="range-row"><input type="range" data-volume min="0" max="100" value="${Math.round((state.settings.volume || .5) * 100)}" style="--fill:${Math.round((state.settings.volume || .5) * 100)}%">
              <span class="range-val">${Math.round((state.settings.volume || .5) * 100)}%</span></div></div>
          <div class="switch-row"><span>${icon('music')}Ambient fon ovozi (tinchlantiruvchi pad)</span>
            <button class="switch ${ambient.playing ? 'on' : ''}" data-ambient></button></div>
          <div class="row wrap" style="gap:8px">
            ${[['click', 'Bosish'], ['tap', 'Tegish'], ['hover', 'Hover'], ['nav', 'Menyu'], ['open', 'Ochish'], ['close', 'Yopish'],
      ['success', 'Muvaffaqiyat'], ['error', 'Xatolik'], ['warn', 'Ogohlantirish'], ['coin', 'Tanga'], ['save', 'Saqlash'],
      ['unlock', 'Qulf ochish'], ['lock', 'Qulflash'], ['delete', "O'chirish"], ['boot', 'Ishga tushish']].map(([k, l]) => `<button class="btn sm ghost" data-test="${k}">${esc(l)}</button>`).join('')}
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('upload')}O'z ovozim (MP3 / WAV)</div>
          <span class="badge ${((state.settings.customSfx || {}).ui) ? 'accent' : ''}">${((state.settings.customSfx || {}).ui) ? 'yoqilgan' : 'ixtiyoriy'}</span></div>
        <div class="tiny faint" style="margin-bottom:12px">O'zingiz yoqtirgan ovoz faylini yuklang — u bosish, menyu va boshqa harakatlarda chalinadi. Fayl qurilmada saqlanadi va offline ham ishlaydi.</div>
        <div class="col" style="gap:10px">
          ${[['ui', 'Asosiy ovoz — bosish, menyu, tegish', 'volume'],
      ['ok', 'Muvaffaqiyat ovozi — saqlash, qulf ochish', 'check'],
      ['err', 'Xatolik ovozi — ogohlantirish', 'bell']].map(([k, l, ic]) => {
        const id = (state.settings.customSfx || {})[k];
        return `<div class="item">
              <div class="avatar sm">${icon(ic)}</div>
              <div class="item-main"><div class="item-title">${esc(l)}</div>
                <div class="item-sub">${id ? 'Yuklangan fayl ishlatilmoqda ✔' : 'Hozircha sintez ovozi ishlatiladi'}</div></div>
              <div class="item-actions" style="opacity:1">
                ${id ? `<button class="icon-btn" data-csfx-play="${k}" title="Tinglash">${icon('play')}</button>` : ''}
                <button class="icon-btn" data-csfx-up="${k}" title="Fayl yuklash">${icon('upload')}</button>
                ${id ? `<button class="icon-btn danger" data-csfx-del="${k}" title="O'chirish">${icon('x')}</button>` : ''}
              </div>
            </div>`;
      }).join('')}
        </div>
      </div>
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('sparkles')}Ovoz haqida</div></div>
        <div class="tiny" style="line-height:1.85">
          Ovozlar <b>Web Audio</b> dvigateli orqali real vaqtda sintezlanadi: ikki qavatli "hit" (tishcha + ohang),
          attack/decay konvertlar, lowpass/highpass filtr, kompressor va <b>reverb (xona effekti)</b>.<br><br>
          Nima uchun tayyor audio fayl emas? Internetdan (YouTube va h.k.) olingan ovozlarni tarqatish <b>litsenziya</b> jihatidan
          xavfli, ular saytni og'irlashtiradi va offline rejimda ishlamasligi mumkin. Shu sababli har bir paket professional
          sintez usulida, sizning tizimingizda o'zi quriladi — <b>hech qanday fayl, internet yoki litsenziya muammosi yo'q</b>.<br><br>
          <b>Glass</b> — tiniq, premium · <b>Soft</b> — juda yumshoq, bo'g'iq · <b>Mech</b> — quruq mexanik klaviatura ·
          <b>Bubble</b> — suv tomchisi · <b>Marimba</b> — iliq yog'och ohang · <b>Retro</b> — 8-bit o'yin uslubi.<br><br>
          <b>Muhim:</b> agar o'zingizda yoqqan ovoz fayli bo'lsa (masalan, yuklab olgan mp3), uni yuqoridagi
          <b>«O'z ovozim»</b> bo'limidan qo'shishingiz mumkin — o'shanda tizim o'sha faylni chaladi, sintez ovozi o'rniga.
        </div>
      </div>
    </div>
  </div>`;
  const sw = view.querySelector('[data-sfx]');
  if (sw) sw.addEventListener('click', () => {
    state.settings.sound = !state.settings.sound; sound.on = state.settings.sound; sw.classList.toggle('on');
    saveNow(); if (state.settings.sound) sfx('success'); toast(state.settings.sound ? 'Ovoz yoqildi' : 'Ovoz o\'chirildi', { type: 'info' });
  });
  const vol = view.querySelector('[data-volume]');
  if (vol) vol.addEventListener('input', () => {
    const v = Number(vol.value); state.settings.volume = v / 100; sound.vol = v / 100;
    vol.style.setProperty('--fill', v + '%');
    vol.parentElement.querySelector('.range-val').textContent = v + '%';
    save();
  });
  const am = view.querySelector('[data-ambient]');
  if (am) am.addEventListener('click', () => {
    const on = ambient.toggle(); am.classList.toggle('on', on);
    state.settings.ambient = on; save(); toast(on ? 'Ambient ovoz yoqildi' : 'Ambient ovoz o\'chirildi', { type: 'info' });
  });
  on(view, 'click', '[data-test]', (e, b) => sfx(b.dataset.test));
  on(view, 'click', '[data-csfx-up]', async (e, b) => {
    const slot = b.dataset.csfxUp;
    const files = await pickFiles('audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac');
    if (!files.length) return;
    const f = files[0];
    if (f.size > 12 * 1024 * 1024) { toast('Fayl juda katta (12 MB dan oshmasin)', { type: 'warn' }); return; }
    toast('Ovoz fayli saqlanmoqda…', { type: 'info', ms: 1600 });
    try {
      const rec = await mediaFromFile(f, { keepOriginal: true });
      state.settings.customSfx = Object.assign({ ui: null, ok: null, err: null }, state.settings.customSfx || {});
      state.settings.customSfx[slot] = rec.id;
      if (!state.settings.sound) { state.settings.sound = true; sound.on = true; }
      saveNow();
      const url = await media.url(rec.id);
      playSampleUrl(url, sound.vol);
      toast('Ovoz yuklandi ✔ — hoziroq eshitdingiz', { type: 'success' });
      ctx.refresh();
    } catch (err) { toast('Yuklash amalga oshmadi: ' + err.message, { type: 'error' }); }
  });
  on(view, 'click', '[data-csfx-play]', async (e, b) => {
    const id = (state.settings.customSfx || {})[b.dataset.csfxPlay];
    const url = id ? await media.url(id) : null;
    if (url) { if (!state.settings.sound) sound.on = true; playSampleUrl(url, sound.vol); }
    else sfx('click');
  });
  on(view, 'click', '[data-csfx-del]', (e, b) => {
    const slot = b.dataset.csfxDel;
    if (state.settings.customSfx) { state.settings.customSfx[slot] = null; saveNow(); }
    sfx('delete');
    toast('O\'z ovoz o\'chirildi — endi sintez ovozi ishlatiladi', { type: 'info' });
    ctx.refresh();
  });
  on(view, 'click', '[data-pack]', (e, b) => {
    const k = b.dataset.pack;
    state.settings.soundPack = k;
    if (!state.settings.sound) { state.settings.sound = true; sound.on = true; }
    sound.setPack(k); save();
    /* tanlangan paket darhol eshitiladi */
    sound.preview(k);
    toast(`Ovoz paketi: ${PACKS_LABEL(k)} — tinglang`, { type: 'success' });
    ctx.refresh();
  });
}

/* ================= DATA ================= */
function tabData(view, ctx) {
  view.innerHTML = `<div class="stagger">
    ${pageHead({ title: 'Ma\'lumotlar', icon: 'coins', badge: 'sozlamalar',
    sub: 'Eksport / import — kompyuter buzilsa ham hamma ma\'lumot saqlanadi' })}
    <div class="grid g2">
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('download')}Eksport (zaxira nusxa)</div></div>
        <div class="tiny faint" style="margin-bottom:12px">Barcha ma'lumotlar + yuklangan rasm, video va mp3 fayllar bitta ZIP arxivga yig'iladi va avtomatik kompyuteringizga yuklanadi.</div>
        <div class="col">
          <button class="btn primary" data-act="export-zip">${icon('download')}ZIP zaxira nusxa yuklab olish</button>
          <button class="btn ghost" data-act="export-json">${icon('doc')}Faqat JSON (yengil)</button>
          <div class="tiny faint">Tavsiya: haftada bir marta ZIP zaxira qiling.</div>
        </div>
      </div>
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('upload')}Import (tiklash)</div></div>
        <div class="tiny faint" style="margin-bottom:12px">Yangi kompyuterga o'tganingizda shu yerdan ZIP yoki JSON faylni yuklang.</div>
        <div class="col">
          <button class="btn soft" data-act="import-replace">${icon('refresh')}To'liq tiklash (hammasini almashtirish)</button>
          <button class="btn ghost" data-act="import-merge">${icon('plus')}Qo'shish (mavjudlar bilan birlashtirish)</button>
          <div class="warnbox" style="margin-top:6px">${icon('shield')}<div>Import qilishdan oldin hozirgi holatni eksport qilib olishni tavsiya qilamiz.</div></div>
        </div>
      </div>
    </div>
    <div class="card" style="margin-top:16px">
      <div class="card-h"><div class="card-t">${icon('grid')}Xotira holati</div></div>
      <div id="usageBox" class="grid g4">${statMini('Hisoblar', String(state.accounts.length))}${statMini('Tradlar', String(state.trades.length))}${statMini('Vazifalar', String(Object.values(state.tasks).flat().length))}${statMini('Musiqa', String(state.music.tracks.length))}</div>
      <div class="divider"></div>
      <div id="storageBox" class="tiny faint">Hisoblanmoqda…</div>
    </div>
  </div>`;
  (async () => {
    const all = await media.all();
    const size = all.reduce((s, m) => s + (m.size || 0), 0);
    const st = new Blob([localStorage.getItem('khumoyun-os.state.v1') || '']).size;
    const el = view.querySelector('#storageBox');
    if (el) el.innerHTML = `
      <div class="kv"><span class="k">Media fayllar</span><span class="v">${all.length} ta · ${humanSize(size)}</span></div>
      <div class="kv"><span class="k">Ma'lumotlar bazasi (state)</span><span class="v">${humanSize(st)}</span></div>
      <div class="kv"><span class="k">Jami</span><span class="v">${humanSize(size + st)}</span></div>
      <div class="kv"><span class="k">Brauzer limiti</span><span class="v">odatda bir necha GB (IndexedDB)</span></div>`;
  })();
  on(view, 'click', '[data-act]', async (e, b) => {
    const act = b.dataset.act;
    if (act === 'export-zip') {
      const m = modal.open({ title: 'Zaxira nusxa tayyorlanmoqda', icon: 'download', size: 'small', body: `<div class="col"><div class="tiny faint" id="expMsg">Fayllar yig'ilmoqda…</div><div class="progress"><span class="progress-fill" id="expBar" data-w="4"></span></div></div>`, foil: '' });
      const bar = m.root.querySelector('#expBar'); bar.style.transform = 'scaleX(.04)';
      try {
        const res = await exportAll((i, total, name) => {
          const p = Math.round((i / Math.max(1, total)) * 100);
          bar.style.transform = 'scaleX(' + (p / 100) + ')';
          const msg = m.root.querySelector('#expMsg'); if (msg) msg.textContent = `${i}/${total} · ${String(name).slice(0, 40)}`;
        });
        download(res.blob, `khumoyun-os-zaxira-${todayISO()}.zip`);
        m.close(); sfx('success');
        toast(`Zaxira yuklandi (${humanSize(res.size)})`, { type: 'success', ms: 3600 });
      } catch (err) { m.close(); toast('Eksport xatosi: ' + err.message, { type: 'error' }); }
      return;
    }
    if (act === 'export-json') {
      const blob = await exportJSON();
      download(blob, `khumoyun-os-${todayISO()}.json`);
      sfx('success'); toast('JSON yuklandi', { type: 'success' }); return;
    }
    if (act === 'import-replace' || act === 'import-merge') {
      const mode = act === 'import-replace' ? 'replace' : 'merge';
      if (mode === 'replace') {
        const ok = await confirmDialog('To\'liq tiklash?', 'Hozirgi barcha ma\'lumotlar import qilinayotgan fayl bilan almashtiriladi.', { danger: true, okLabel: 'Tiklash' });
        if (!ok) return;
      }
      const files = await pickFiles('.zip,.json,application/zip,application/json');
      if (!files.length) return;
      const mm = modal.open({ title: 'Import qilinmoqda', icon: 'upload', size: 'small', body: `<div class="col"><div class="tiny faint" id="impMsg">Fayl o'qilmoqda…</div><div class="progress"><span class="progress-fill" data-w="5"></span></div></div>` });
      const bar = mm.root.querySelector('.progress-fill'); bar.style.transform = 'scaleX(.05)';
      try {
        const res = await importFile(files[0], mode, (i, total, name) => {
          bar.style.transform = 'scaleX(' + (i / Math.max(1, total)) + ')';
          const msg = mm.root.querySelector('#impMsg');
          if (msg) msg.textContent = `${i}/${total} media · ${String(name).slice(0, 34)}`;
        });
        mm.close(); sfx('success');
        toast(`Import tayyor: ${res.media} media fayl tiklandi`, { type: 'success', ms: 3800 });
        ctx.applyUi(); ctx.refresh();
      } catch (err) { mm.close(); toast('Import xatosi: ' + err.message, { type: 'error', ms: 4000 }); }
      return;
    }
  });
}

/* ================= ABOUT ================= */
function tabAbout(view, ctx) {
  view.innerHTML = `<div class="stagger">
    ${pageHead({ title: 'Yordam', icon: 'sparkles', badge: 'hujjatlar', sub: 'Klaviatura tugmalari, offline rejim va maslahatlar' })}
    <div class="grid g2">
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('cursor')}Klaviatura tugmalari</div></div>
        ${kv([['<span class="kbd">/</span>', 'Qidiruvga o\'tish'], ['<span class="kbd">1…9</span>', 'Menyular orasida o\'tish'], ['<span class="kbd">N</span>', 'Yangi yozuv (bo\'limga qarab)'], ['<span class="kbd">L</span>', 'Tizimni qulflash'], ['<span class="kbd">M</span>', 'Musiqa ijro / pauza'], ['<span class="kbd">Space</span>', 'Musiqa ijro / pauza'], ['<span class="kbd">Ctrl/⌘ + S</span>', 'Zaxira nusxa (ZIP)'], ['<span class="kbd">Esc</span>', 'Oynani yopish']])}
      </div>
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('download')}Offline o'rnatish</div></div>
        <div class="tiny" style="line-height:1.8">
          1) Chrome/Edge da manzil qatoridagi <b>o'rnatish</b> belgisini bosing.<br>
          2) Yoki menyu → <b>Boshqa asboblar → Ilova sifatida o'rnatish</b>.<br>
          3) Telefonda Safari/Chrome: <b>Ulashish → Asosiy ekranga qo'shish</b>.<br><br>
          Shundan keyin tizim internetsiz ham ishlaydi — barcha ma'lumotlar qurilmada saqlanadi.
        </div>
      </div>
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('sparkles')}Maslahatlar</div></div>
        <div class="tiny" style="line-height:1.8">
          • Asosiy fondagi videoni <b>0%</b> blur bilan qo'ysangiz kino effekti bo'ladi, matn o'qilishi uchun <b>20–40%</b> blur tavsiya etiladi.<br>
          • Trading skrinshotlari faqat <b>16:9</b> formatda saqlanadi — TradingView uchun ideal.<br>
          • Musiqa jild muqovalari faqat <b>1:1</b> formatda.<br>
          • Maqsadlarni har oy yangilab turing — progress yashil rangda ko'rinadi.
        </div>
      </div>
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('shield')}Maxfiylik</div></div>
        <div class="tiny" style="line-height:1.8">
          Hech qanday ma'lumot serverga yuborilmaydi. PIN kod shifrlangan holda faqat shu qurilmada saqlanadi.<br><br>
          <b>Eslatma:</b> brauzer keshini tozalashdan oldin albatta eksport qiling.
        </div>
      </div>
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('refresh')}Versiya va yangilash</div></div>
        <div class="tiny" style="line-height:1.8">
          Joriy versiya: <b>v${APP_BUILD}</b> · yangilanish sanasi: <b>${APP_BUILD_DATE}</b><br>
          Yangi versiya chiqsa, ekranning pastida <b>"Yangilash"</b> paneli o'zi paydo bo'ladi.
          Agar eski ko'rinish "yopishib" qolsa (brauzer keshi), quyidagi tugma hammasini tozalab, eng yangi versiyani yuklaydi.
        </div>
        <div class="row wrap" style="gap:8px;margin-top:12px">
          <button class="btn primary sm" data-act="hard-refresh">${icon('refresh')}Keshni tozalash va yangilash</button>
          <button class="btn ghost sm" data-act="check-update">${icon('download')}Yangilanishni tekshirish</button>
        </div>
        <div class="tiny faint" style="margin-top:8px" data-update-info></div>
      </div>
    </div>
    <div class="card" style="margin-top:16px;text-align:center">
      <div class="h2 gradient-text">KHUMOYUN OS</div>
      <div class="tiny faint">v${APP_BUILD} · ${esc(state.profile.name)} uchun shaxsiy tizim · ${esc(String(state.createdAt || '').slice(0, 10))} dan beri</div>
    </div>
  </div>`;
  on(view, 'click', '[data-act="hard-refresh"]', async () => { sfx('success'); hardRefresh(); });
  on(view, 'click', '[data-act="check-update"]', async () => {
    const info = view.querySelector('[data-update-info]');
    if (info) info.textContent = 'Tekshirilmoqda…';
    const has = await checkUpdate();
    if (info) info.textContent = has ? 'Yangi versiya topildi — pastdagi paneldan yangilang.' : `Yangilanish yo'q — sizda eng yangi versiya (v${APP_BUILD}).`;
    if (!has) toast('Sizda eng yangi versiya ✔', { type: 'success' });
  });
}

/* ================= RENDER ================= */
export function render(view, ctx) {
  if (ctx.route === 'search') return renderSearch(view, ctx);
  const tab = ctx.query.get('tab') || 'profile';
  view.innerHTML = `<div class="stagger">
    <div class="tabs" style="margin-bottom:18px">${TABS.map(([k, l, ic]) => `<button class="tab ${k === tab ? 'active' : ''}" data-tab="${k}">${icon(ic)}${esc(l)}</button>`).join('')}</div>
  </div>`;
  const holder = view.querySelector('.stagger');
  const sub = document.createElement('div');
  sub.className = 'stagger';
  holder.after(sub);
  if (tab === 'profile') tabProfile(sub, ctx);
  else if (tab === 'security') tabSecurity(sub, ctx);
  else if (tab === 'appearance') tabAppearance(sub, ctx);
  else if (tab === 'background') tabBackground(sub, ctx);
  else if (tab === 'menus') tabMenus(sub, ctx);
  else if (tab === 'sound') tabSound(sub, ctx);
  else if (tab === 'data') tabData(sub, ctx);
  else tabAbout(sub, ctx);
  on(view, 'click', '[data-tab]', (e, b) => { sfx('nav'); ctx.go('settings', { tab: b.dataset.tab }); });
  fillMedia(view);
  barFillLocal(view);
}
function barFillLocal(root) {
  const els = $$('.progress-fill[data-w]', root);
  if (!els.length) return;
  requestAnimationFrame(() => { for (const el of els) el.style.transform = 'scaleX(' + (clamp(el.dataset.w) / 100) + ')'; });
}

export { render as default };
