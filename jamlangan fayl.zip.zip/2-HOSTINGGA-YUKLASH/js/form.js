/* ============================================================
   KHUMOYUN OS — schema driven forms + media pickers
   ============================================================ */
import { $, $$, esc, icon, toast, modal, sfx, clamp, confirmDialog, on } from './util.js';
import { media, mediaFromFile, state, ACC_TYPE_LABEL, ACC_TYPES } from './store.js';

export const OPT = {
  side: [['long', 'LONG (sotib olish)'], ['short', 'SHORT (sotish)']],
  result: [['win', 'Foyda'], ['loss', 'Zarar'], ['be', 'Breakeven'], ['open', 'Ochiq']],
  session: [['asia', 'Osiyo'], ['london', 'London'], ['newyork', 'New York'], ['other', 'Boshqa']],
  emotion: [['calm', 'Xotirjam'], ['confident', 'Ishonchli'], ['fomo', 'FOMO'], ['revenge', 'Qasos'], ['greedy', 'Ochko\'z'], ['tired', 'Charchagan']],
  priority: [['high', 'Yuqori'], ['mid', 'O\'rta'], ['low', 'Past']],
  noteType: [['daily', 'Kunlik izoh'], ['problem', 'Muammo'], ['idea', 'G\'oya'], ['plan', 'Reja'], ['lesson', 'Saboq']],
  goalCat: [['money', 'Moliyaviy'], ['trading', 'Trading'], ['study', 'Ta\'lim'], ['health', 'Salomatlik'], ['travel', 'Sayohat'], ['business', 'Biznes'], ['personal', 'Shaxsiy']],
  wishCat: [['tech', 'Texnika'], ['car', 'Avtomobil'], ['home', 'Uy/Interyer'], ['clothes', 'Kiyim'], ['travel', 'Sayohat'], ['study', 'Ta\'lim'], ['other', 'Boshqa']],
  accCurrency: [['USD', 'USD $'], ['UZS', 'UZS so\'m'], ['EUR', 'EUR €'], ['RUB', 'RUB ₽']],
  icons: [['wallet', 'Hamyon'], ['bank', 'Bank'], ['coins', 'Tanga/Kripto'], ['chart', 'Grafik'], ['dash', 'Uy'], ['store', 'Do\'kon'], ['star', 'Yulduz'], ['tag', 'Teg'], ['heart', 'Sevimli'], ['fire', 'Olov']],
  mood: [['😄', 'Ajoyib'], ['🙂', 'Yaxshi'], ['😐', 'O\'rtacha'], ['😔', 'Tushkun'], ['😤', 'G\'azab'], ['🤯', 'Stress']],
};
export const sel = (opts, v) => opts.map(([k, l]) => `<option value="${esc(k)}" ${String(v) === String(k) ? 'selected' : ''}>${esc(l)}</option>`).join('');
const accSel = (v) => `<option value="">— hisob tanlang —</option>` + state.accounts.map((a) => `<option value="${a.id}" ${v === a.id ? 'selected' : ''}>${esc(a.name)}</option>`).join('');

export function fieldHTML(f, data = {}) {
  const v = data[f.k] != null ? data[f.k] : (f.def != null ? f.def : '');
  const wrap = (inner, cls = '') => `<div class="field ${cls} ${f.full ? 'span-2' : ''}" data-fk="${esc(f.k)}">
      <label>${f.icon ? icon(f.icon) : ''}${esc(f.l)}${f.req ? ' <span class="accent">*</span>' : ''}</label>${inner}
      ${f.hint ? `<div class="hint">${esc(f.hint)}</div>` : ''}</div>`;
  const type = f.t || 'text';
  switch (type) {
    case 'num': case 'money': return wrap(`<input class="input num" data-in type="number" step="${f.step || 'any'}" value="${v === '' ? '' : esc(v)}" placeholder="${esc(f.ph || '0')}">`);
    case 'date': return wrap(`<input class="input" data-in type="date" value="${esc(v || '')}">`);
    case 'time': return wrap(`<input class="input" data-in type="time" value="${esc(v || '')}">`);
    case 'textarea': return wrap(`<textarea class="textarea" data-in rows="${f.rows || 4}" placeholder="${esc(f.ph || '')}">${esc(v || '')}</textarea>`);
    case 'select': return wrap(`<select class="select" data-in>${sel(f.opts || [], v)}</select>`);
    case 'account': return wrap(`<select class="select" data-in>${accSel(v)}</select>`);
    case 'tags': return wrap(`<input class="input" data-in value="${esc(Array.isArray(v) ? v.join(', ') : (v || ''))}" placeholder="teg1, teg2, teg3"><div class="hint">Vergul bilan ajratib yozing</div>`);
    case 'color': return wrap(`<input class="input" data-in type="color" style="width:70px;padding:4px;height:42px" value="${esc(v || '#22e07a')}">`);
    case 'switch': return wrap(`<div class="switch-row"><span>${esc(f.l2 || 'Yoqish')}</span><button type="button" class="switch ${v ? 'on' : ''}" data-switch></button><input type="hidden" data-in value="${v ? '1' : ''}"></div>`);
    case 'range': return wrap(`<div class="range-row"><input type="range" data-in min="${f.min || 0}" max="${f.max || 100}" value="${clamp(v, f.min || 0, f.max || 100)}"><span class="range-val">${clamp(v, f.min || 0, f.max || 100)}${f.unit || ''}</span></div>`);
    case 'stars': return wrap(`<div class="row" data-stars data-val="${esc(v || 0)}">${[1, 2, 3, 4, 5].map((n) => `<button type="button" class="stars" data-star="${n}" style="background:none;border:0;padding:0;cursor:pointer">${icon('star', n <= (Number(v) || 0) ? 'on' : '')}</button>`).join('')}</div>`);
    case 'checklist': return wrap(`<div class="col" data-checklist>
        ${(Array.isArray(v) ? v : []).map((it) => checkRow(it)).join('')}
        <button type="button" class="btn ghost sm" data-add-check>${icon('plus')}Qadam qo'shish</button>
        <input type="hidden" data-in value=""></div>`);
    case 'ratioImage': case 'image': case 'video': {
      const ratio = data[f.k + '_ratio'] || f.ratio || '16:9';
      const pos = data[f.k + '_pos'] || '50% 50%';
      const zoom = data[f.k + '_zoom'] || 100;
      const isVid = type === 'video';
      return wrap(`
        <div class="row wrap" style="align-items:flex-start;gap:12px">
          <div class="thumb ratio-${ratio.replace(':', '-')}" style="width:${f.w || 190}px;flex:0 0 auto;--pos:${esc(pos)}" data-media="${esc(v || '')}" data-zoom="${zoom}">
            ${v ? '' : `<div class="ph">${icon(isVid ? 'video' : 'image')}</div>`}
          </div>
          <div class="col grow" style="gap:7px">
            <div class="row wrap" data-img-actions>
              <button type="button" class="btn sm" data-pick>${icon('upload')}${isVid ? 'Fayl yuklash' : 'Rasm yuklash'}</button>
              ${v ? `<button type="button" class="btn sm ghost" data-picklib>${icon('grid')}Kutubxona</button><button type="button" class="btn sm danger" data-clear>${icon('trash')}O'chirish</button>` : ''}
            </div>
            ${f.lockRatio ? `<div class="hint">Format: ${ratio} (faqat shu format)</div>` : `<div class="chips" data-ratio>
              ${['16:9', '1:1', '9:16', '4:3', '21:9'].map((r) => `<button type="button" class="chip ${r === ratio ? 'active' : ''}" data-rat="${r}">${r}</button>`).join('')}
            </div>`}
            <div class="row"><span class="tiny faint nowrap">Kadr X</span><input type="range" data-pos-x min="0" max="100" value="${parseFloat(pos) || 50}"></div>
            <div class="row"><span class="tiny faint nowrap">Kadr Y</span><input type="range" data-pos-y min="0" max="100" value="${parseFloat((pos.split(' ')[1] || '50'))}"></div>
            <div class="row"><span class="tiny faint nowrap">Zoom</span><input type="range" data-zoom min="100" max="220" value="${zoom}"><span class="range-val" data-zoomval style="min-width:58px">${zoom}%</span></div>
          </div>
        </div>
        <input type="hidden" data-in value="${esc(v || '')}">
        <input type="hidden" data-in-ratio value="${esc(ratio)}">
        <input type="hidden" data-in-pos value="${esc(pos)}">
        <input type="hidden" data-in-zoom value="${zoom}">`);
    }
    case 'gallery': {
      const arr = Array.isArray(v) ? v : [];
      return wrap(`<div class="col" data-gallery>
        <div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(120px,1fr))" data-glist>
          ${arr.map((g) => `<div class="thumb ratio-16-9" data-media="${esc(g.id)}" style="--pos:${esc(g.pos || '50% 50%')}">
            <button type="button" class="icon-btn danger" data-gdel="${esc(g.id)}" style="position:absolute;top:6px;right:6px;z-index:3">${icon('trash')}</button></div>`).join('')}
        </div>
        <button type="button" class="btn ghost sm" data-gadd>${icon('upload')}Rasm qo'shish</button>
        <input type="hidden" data-in value="${esc(JSON.stringify(arr))}"></div>`);
    }
    case 'folder': return wrap(`<select class="select" data-in><option value="">— jild tanlanmagan —</option>${state.music.folders.map((fld) => `<option value="${fld.id}" ${v === fld.id ? 'selected' : ''}>${esc(fld.name)}</option>`).join('')}</select>`);
    default: return wrap(`<input class="input" data-in type="text" value="${esc(v)}" placeholder="${esc(f.ph || '')}">`);
  }
}
function checkRow(it = {}) {
  return `<div class="row" data-check-item>
    <button type="button" class="cbox ${it.done ? 'done' : ''}" data-ctoggle>${icon('check')}</button>
    <input class="input" data-ctext value="${esc(it.text || '')}" placeholder="Qadam nomi">
    <button type="button" class="icon-btn danger" data-cdel>${icon('x')}</button></div>`;
}
export function formBody(schema, data = {}) {
  return `<div class="form-grid">${schema.map((f) => fieldHTML(f, data)).join('')}</div>`;
}

export async function fillMedia(root = document) {
  const nodes = $$('[data-media]', root);
  for (const node of nodes) {
    const id = node.dataset.media;
    if (node.dataset.filled === id) continue;
    if (!id) { if (!node.querySelector('.ph')) node.innerHTML = `<div class="ph">${icon('image')}</div>`; node.dataset.filled = ''; continue; }
    const rec = await media.get(id);
    if (!rec) continue;
    const url = await media.url(id);
    if (!url) continue;
    const isVideo = (rec.type || '').startsWith('video/');
    node.dataset.filled = id;
    node.innerHTML = isVideo ? `<video src="${url}" muted playsinline loop preload="metadata"></video>`
      : `<img src="${url}" alt="${esc(rec.name || '')}" loading="lazy">`;
    const el = node.firstElementChild;
    const zoom = Number(node.dataset.zoom || 100) / 100;
    if (el && zoom !== 1) el.style.transform = `scale(${zoom})`;
  }
}

export function bindForm(root) {
  $$('[data-switch]', root).forEach((sw) => sw.addEventListener('click', () => {
    sw.classList.toggle('on');
    sw.parentElement.querySelector('input[type=hidden]').value = sw.classList.contains('on') ? '1' : '';
    sfx(sw.classList.contains('on') ? 'check' : 'uncheck');
  }));
  $$('input[type=range]', root).forEach((r) => {
    const upd = () => {
      const min = Number(r.min || 0), max = Number(r.max || 100);
      r.style.setProperty('--fill', (((r.value - min) / (max - min)) * 100) + '%');
      const field = r.closest('[data-fk]');
      if (r.hasAttribute('data-zoom')) {
        const zv = field.querySelector('[data-zoomval]'); if (zv) zv.textContent = r.value + '%';
        const hz = field.querySelector('[data-in-zoom]'); if (hz) hz.value = r.value;
        const thumb = field.querySelector('.thumb'); if (thumb) thumb.dataset.zoom = r.value;
        const mEl = thumb && thumb.firstElementChild; if (mEl) mEl.style.transform = `scale(${Number(r.value) / 100})`;
      } else if (r.hasAttribute('data-pos-x') || r.hasAttribute('data-pos-y')) {
        const px = field.querySelector('[data-pos-x]').value, py = field.querySelector('[data-pos-y]').value;
        const hp = field.querySelector('[data-in-pos]'); if (hp) hp.value = `${px}% ${py}%`;
        const thumb = field.querySelector('.thumb'); if (thumb) thumb.style.setProperty('--pos', `${px}% ${py}%`);
      } else {
        const val = r.parentElement.querySelector('.range-val');
        if (val) val.textContent = r.value + (r.dataset.unit || '');
      }
    };
    r.addEventListener('input', upd); upd();
  });
  $$('[data-stars]', root).forEach((box) => {
    if (box.dataset.bound) return; box.dataset.bound = '1';
    box.addEventListener('click', (e) => {
      const b = e.target.closest('[data-star]'); if (!b) return;
      const n = Number(b.dataset.star);
      box.dataset.val = n;
      $$('[data-star] .ic', box).forEach((sv, i) => sv.classList.toggle('on', i < n));
      sfx('tick');
    });
  });
  $$('[data-checklist]', root).forEach((cl) => {
    if (cl.dataset.bound) return; cl.dataset.bound = '1';
    const add = cl.querySelector('[data-add-check]');
    cl.addEventListener('click', (e) => {
      if (e.target.closest('[data-add-check]')) {
        const tmp = document.createElement('div'); tmp.innerHTML = checkRow({ text: '' });
        cl.insertBefore(tmp.firstElementChild, add);
        add.previousElementSibling.querySelector('[data-ctext]').focus(); sfx('tap');
      }
      const del = e.target.closest('[data-cdel]'); if (del) { del.closest('[data-check-item]').remove(); sfx('delete'); }
      const tg = e.target.closest('[data-ctoggle]'); if (tg) { tg.classList.toggle('done'); sfx('tick'); }
    });
  });
  $$('[data-ratio]', root).forEach((box) => {
    if (box.dataset.bound) return; box.dataset.bound = '1';
    box.addEventListener('click', (e) => {
      const b = e.target.closest('[data-rat]'); if (!b) return;
      $$('.chip', box).forEach((c) => c.classList.remove('active')); b.classList.add('active');
      const field = box.closest('[data-fk]');
      field.querySelector('[data-in-ratio]').value = b.dataset.rat;
      const thumb = field.querySelector('.thumb');
      thumb.className = thumb.className.replace(/ratio-[\d\-]+/, 'ratio-' + b.dataset.rat.replace(':', '-'));
      sfx('tap');
    });
  });
  $$('[data-pick],[data-picklib]', root).forEach((btn) => {
    if (btn.dataset.bound) return; btn.dataset.bound = '1';
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      const field = btn.closest('[data-fk]');
      if (!field) return;
      const isAudio = field.dataset.fk === 'file';
      if (btn.hasAttribute('data-picklib')) {
        const chosen = await mediaPicker({ type: isAudio ? 'audio' : 'all' });
        if (chosen) { setMediaField(field, chosen.id); fillMedia(field); }
        return;
      }
      const file = await pickFile(isAudio ? 'audio/*,video/*' : 'image/*');
      if (!file) return;
      toast('Yuklanmoqda…', { type: 'info' });
      const rec = await mediaFromFile(file);
      setMediaField(field, rec.id);
      fillMedia(field);
      toast('Fayl yuklandi', { type: 'success' });
    });
  });
  $$('[data-clear]', root).forEach((b) => {
    if (b.dataset.bound) return; b.dataset.bound = '1';
    b.addEventListener('click', (e) => { e.preventDefault(); setMediaField(b.closest('[data-fk]'), ''); sfx('delete'); });
  });
  $$('[data-gallery]', root).forEach((g) => {
    if (g.dataset.bound) return; g.dataset.bound = '1';
    g.addEventListener('click', async (e) => {
      const del = e.target.closest('[data-gdel]');
      if (del) { e.stopPropagation(); setGallery(g, collectGallery(g).filter((x) => x.id !== del.dataset.gdel)); sfx('delete'); return; }
      if (e.target.closest('[data-gadd]')) {
        const files = await pickFiles('image/*,video/*');
        if (!files || !files.length) return;
        const arr = collectGallery(g);
        for (const f of files) { const rec = await mediaFromFile(f); arr.push({ id: rec.id, pos: '50% 50%' }); }
        setGallery(g, arr); toast('Fayllar qo\'shildi', { type: 'success' });
      }
    });
  });
}
function setMediaField(field, id) {
  if (!field) return;
  const hid = field.querySelector('[data-in]'); if (hid) hid.value = id || '';
  const thumb = field.querySelector('.thumb');
  if (thumb) { thumb.dataset.media = id || ''; delete thumb.dataset.filled; thumb.innerHTML = id ? '' : `<div class="ph">${icon('image')}</div>`; }
  const actions = field.querySelector('[data-img-actions]');
  if (actions) {
    if (id) {
      actions.innerHTML = `<button type="button" class="btn sm" data-pick>${icon('upload')}Almashtirish</button>
        <button type="button" class="btn sm ghost" data-picklib>${icon('grid')}Kutubxona</button>
        <button type="button" class="btn sm danger" data-clear>${icon('trash')}O'chirish</button>`;
    } else {
      actions.innerHTML = `<button type="button" class="btn sm" data-pick>${icon('upload')}Rasm yuklash</button>`;
    }
    delete actions.dataset.bound;
    bindForm(actions);
  }
}
export function collectGallery(g) {
  return $$('[data-glist] .thumb', g).filter((t) => t.dataset.media).map((t) => ({ id: t.dataset.media, pos: t.style.getPropertyValue('--pos') || '50% 50%' }));
}
function setGallery(g, arr) {
  g.querySelector('[data-in]').value = JSON.stringify(arr);
  g.querySelector('[data-glist]').innerHTML = arr.map((item) => `<div class="thumb ratio-16-9" data-media="${esc(item.id)}" style="--pos:${esc(item.pos || '50% 50%')}">
    <button type="button" class="icon-btn danger" data-gdel="${esc(item.id)}" style="position:absolute;top:6px;right:6px;z-index:3">${icon('trash')}</button></div>`).join('');
  fillMedia(g);
}
export function pickFile(accept = 'image/*') {
  return new Promise((resolve) => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = accept;
    inp.onchange = () => resolve(inp.files && inp.files[0]);
    inp.click();
  });
}
export function pickFiles(accept = 'image/*') {
  return new Promise((resolve) => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = accept; inp.multiple = true;
    inp.onchange = () => resolve(Array.from(inp.files || []));
    inp.click();
  });
}
export async function mediaPicker({ type = 'all', title = 'Kutubxonadan tanlash' } = {}) {
  const all = await media.all();
  const list = all.filter((m) => type === 'all' || (m.type || '').startsWith(type + '/'));
  return new Promise((resolve) => {
    const m = modal.open({
      title, icon: 'grid', size: 'wide',
      body: list.length ? `<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(130px,1fr))">
          ${list.map((f) => `<button class="thumb ratio-1-1" data-pid="${esc(f.id)}" style="cursor:pointer" title="${esc(f.name)}"><div class="ph">${icon('image')}</div></button>`).join('')}
        </div>` : `<div class="empty">${icon('image')}<div class="empty-title">Kutubxona bo'sh</div><div class="tiny">Avval fayl yuklang</div></div>`,
      footer: `<button class="btn ghost" data-x>Yopish</button><button class="btn primary" data-up>${icon('upload')}Yangi fayl yuklash</button>`,
    });
    fillMedia(m.root);
    m.root.querySelector('[data-up]').onclick = async () => {
      const files = await pickFiles(type === 'audio' ? 'audio/*' : type === 'video' ? 'video/*' : 'image/*');
      if (!files || !files.length) return;
      const rec = await mediaFromFile(files[0]);
      m.close(); resolve({ id: rec.id, name: rec.name, type: rec.type });
    };
    m.root.querySelector('[data-x]').onclick = () => { m.close(); resolve(null); };
    on(m.root, 'click', '[data-pid]', (e, b) => {
      const rec = list.find((f) => f.id === b.dataset.pid);
      m.close(); resolve(rec ? { id: rec.id, name: rec.name, type: rec.type } : null);
    });
    m.root.addEventListener('mousedown', (e) => { if (e.target === m.root) { m.close(); resolve(null); } });
  });
}

export function collect(root, schema) {
  const out = {};
  schema.forEach((f) => {
    const field = root.querySelector(`[data-fk="${f.k}"]`);
    if (!field) return;
    const type = f.t || 'text';
    if (type === 'checklist') {
      out[f.k] = $$('[data-check-item]', field).filter((r) => r.querySelector('[data-ctext]').value.trim())
        .map((r) => ({ text: r.querySelector('[data-ctext]').value.trim(), done: r.querySelector('[data-ctoggle]').classList.contains('done') }));
      return;
    }
    if (type === 'stars') { out[f.k] = Number(field.querySelector('[data-stars]').dataset.val || 0); return; }
    if (type === 'switch') { out[f.k] = !!field.querySelector('[data-in]').value; return; }
    if (type === 'gallery') { try { out[f.k] = JSON.parse(field.querySelector('[data-in]').value || '[]'); } catch (e) { out[f.k] = []; } return; }
    if (type === 'ratioImage' || type === 'image' || type === 'video') {
      out[f.k] = field.querySelector('[data-in]').value || null;
      out[f.k + '_ratio'] = field.querySelector('[data-in-ratio]').value;
      out[f.k + '_pos'] = field.querySelector('[data-in-pos]').value;
      out[f.k + '_zoom'] = Number(field.querySelector('[data-in-zoom]').value);
      return;
    }
    if (type === 'range') { out[f.k] = Number(field.querySelector('[data-in]').value); return; }
    const input = field.querySelector('[data-in]');
    let v = input ? input.value : '';
    if (type === 'num' || type === 'money') v = v === '' ? 0 : Number(v);
    if (type === 'tags') v = v.split(',').map((s) => s.trim()).filter(Boolean);
    out[f.k] = v;
  });
  return out;
}

export function openForm({ title, icon: ic = 'pencil', schema, data = {}, size = '', saveLabel = 'Saqlash', onSave, extraBody = '', allowDelete = false, onDelete, subtitle = '' }) {
  const body = (subtitle ? `<div class="tiny faint">${esc(subtitle)}</div>` : '') + formBody(schema, data) + extraBody;
  const m = modal.open({
    title, icon: ic, size, body,
    footer: `${allowDelete ? `<button class="btn danger" data-del>${icon('trash')}O'chirish</button>` : ''}
      <button class="btn ghost" data-close>Bekor qilish</button>
      <button class="btn primary" data-save>${icon('check')}${esc(saveLabel)}</button>`,
    onMount: (mm) => {
      fillMedia(mm.root);
      bindForm(mm.root);
      const first = mm.root.querySelector('input:not([type=hidden]):not([type=color]):not([type=range]),textarea,select');
      if (first) setTimeout(() => first.focus(), 120);
      mm.root.querySelector('[data-save]').onclick = async () => {
        const values = collect(mm.root, schema);
        for (const f of schema.filter((x) => x.req)) {
          const val = values[f.k];
          if (val === '' || val == null || (Array.isArray(val) && !val.length)) {
            toast(`«${f.l}» maydonini to'ldiring`, { type: 'warn' }); sfx('warn');
            const el = mm.root.querySelector(`[data-fk="${f.k}"] input, [data-fk="${f.k}"] textarea, [data-fk="${f.k}"] select`);
            if (el) el.focus();
            return;
          }
        }
        await (onSave ? onSave(values, mm) : 0);
        m.close();
      };
      if (allowDelete) mm.root.querySelector('[data-del]').onclick = async () => {
        const ok = await confirmDialog('O\'chirishni tasdiqlaysizmi?', 'Bu yozuv butunlay o\'chib ketadi va qaytarilmaydi.', { danger: true, okLabel: 'O\'chirish', icon: 'trash' });
        if (!ok) return;
        if (onDelete) await onDelete();
        m.close();
      };
      mm.root.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) mm.root.querySelector('[data-save]').click(); });
    },
  });
  return m;
}

/* ================= SCHEMAS ================= */
const today = () => new Date().toISOString().slice(0, 10);
export const SCHEMAS = {
  account: [
    { k: 'name', l: 'Hisob nomi', icon: 'wallet', req: true, ph: 'Naqd pul / Kapital Bank' },
    { k: 'type', l: 'Turi', t: 'select', opts: ACC_TYPES.map((t) => [t, ACC_TYPE_LABEL[t]]), def: 'cash' },
    { k: 'balance', l: 'Balans', t: 'num', req: true, def: 0 },
    { k: 'currency', l: 'Valyuta', t: 'select', opts: OPT.accCurrency, def: 'USD' },
    { k: 'icon', l: 'Ikonka', t: 'select', opts: OPT.icons, def: 'wallet' },
    { k: 'color', l: 'Rang', t: 'color', def: '#22e07a' },
    { k: 'hidden', l: 'Yashirin hisob', t: 'switch', l2: 'Net Worth hisobida ko\'rinmasin' },
    { k: 'note', l: 'Izoh', t: 'textarea', full: true, rows: 2 },
  ],
  income: [
    { k: 'amount', l: 'Summa', t: 'num', req: true, def: 0 },
    { k: 'date', l: 'Sana', t: 'date', def: today() },
    { k: 'account', l: 'Hisob', t: 'account', req: true },
    { k: 'category', l: 'Kategoriya', t: 'text', ph: 'Ish haqi, Freelance, Trading' },
    { k: 'note', l: 'Izoh', t: 'text', full: true, ph: 'Qisqa izoh' },
  ],
  expense: [
    { k: 'amount', l: 'Summa', t: 'num', req: true, def: 0 },
    { k: 'date', l: 'Sana', t: 'date', def: today() },
    { k: 'account', l: 'Hisob', t: 'account', req: true },
    { k: 'category', l: 'Kategoriya', t: 'text', ph: 'Ijara, Oziq-ovqat, Transport' },
    { k: 'note', l: 'Izoh', t: 'text', full: true, ph: 'Qisqa izoh' },
  ],
  transfer: [
    { k: 'amount', l: 'Summa', t: 'num', req: true, def: 0 },
    { k: 'date', l: 'Sana', t: 'date', def: today() },
    { k: 'account', l: 'Qaysi hisobdan', t: 'account', req: true },
    { k: 'toAccount', l: 'Qaysi hisobga', t: 'account', req: true },
    { k: 'fee', l: 'Komissiya', t: 'num', def: 0 },
    { k: 'note', l: 'Izoh', t: 'text', full: true },
  ],
  trade: [
    { k: 'pair', l: 'Instrument', icon: 'chart', req: true, ph: 'XAUUSD, EURUSD, BTCUSDT' },
    { k: 'side', l: 'Yo\'nalish', t: 'select', opts: OPT.side, def: 'long' },
    { k: 'date', l: 'Sana', t: 'date', def: today() },
    { k: 'session', l: 'Sessiya', t: 'select', opts: OPT.session, def: 'london' },
    { k: 'entry', l: 'Kirish narxi', t: 'num', step: 'any' },
    { k: 'sl', l: 'Stop Loss', t: 'num', step: 'any' },
    { k: 'tp', l: 'Take Profit', t: 'num', step: 'any' },
    { k: 'lots', l: 'Hajm (lot)', t: 'num', step: 'any', def: 0.01 },
    { k: 'pnl', l: 'Natija (P/L, $)', t: 'num', step: 'any', def: 0 },
    { k: 'rr', l: 'R koeffitsiyent', t: 'num', step: 'any', hint: 'Masalan 2.5 → 2.5R foyda' },
    { k: 'result', l: 'Holat', t: 'select', opts: OPT.result, def: 'win' },
    { k: 'emotion', l: 'Hissiyot', t: 'select', opts: OPT.emotion, def: 'calm' },
    { k: 'strategy', l: 'Strategiya / Setup', t: 'text', ph: 'Breakout, Order block…' },
    { k: 'tags', l: 'Teglar', t: 'tags' },
    { k: 'image', l: 'Skrinshot — faqat 16:9', t: 'ratioImage', ratio: '16:9', lockRatio: true, icon: 'image', w: 230, hint: 'TradingView skrinshotini yuklang' },
    { k: 'notes', l: 'Xulosa va tahlil', t: 'textarea', full: true, rows: 5, ph: 'Kirish sababi, xatolar, keyingi safar nima qilish kerak…' },
  ],
  goal: [
    { k: 'title', l: 'Maqsad nomi', icon: 'target', req: true, ph: '1 000 000$ portfel' },
    { k: 'category', l: 'Kategoriya', t: 'select', opts: OPT.goalCat, def: 'money' },
    { k: 'target', l: 'Maqsad summasi', t: 'num', req: true, def: 0 },
    { k: 'saved', l: 'Yig\'ilgan', t: 'num', def: 0 },
    { k: 'deadline', l: 'Muddat', t: 'date' },
    { k: 'priority', l: 'Muhimlik', t: 'stars', def: 3 },
    { k: 'color', l: 'Rang', t: 'color', def: '#22e07a' },
    { k: 'cover', l: 'Maqsad rasmi', t: 'ratioImage', ratio: '16:9', w: 230 },
    { k: 'steps', l: 'Qadamlar', t: 'checklist', full: true },
    { k: 'note', l: 'Izoh / reja', t: 'textarea', full: true, rows: 3 },
  ],
  wish: [
    { k: 'title', l: 'Nima olishni xohlaysiz?', icon: 'star', req: true, ph: 'iPhone 17 Pro Max' },
    { k: 'category', l: 'Kategoriya', t: 'select', opts: OPT.wishCat, def: 'tech' },
    { k: 'price', l: 'Narxi', t: 'num', req: true, def: 0 },
    { k: 'saved', l: 'Yig\'ilgan', t: 'num', def: 0 },
    { k: 'priority', l: 'Muhimlik', t: 'stars', def: 3 },
    { k: 'url', l: 'Havola', t: 'text', ph: 'https://…' },
    { k: 'cover', l: 'Rasm', t: 'ratioImage', ratio: '1:1', w: 190 },
    { k: 'purchased', l: 'Sotib olindi', t: 'switch', l2: 'Xarid qilingan deb belgilash' },
    { k: 'note', l: 'Izoh', t: 'textarea', full: true, rows: 2 },
  ],
  note: [
    { k: 'title', l: 'Sarlavha', icon: 'note', req: true, ph: 'Bugungi tahlil / muammo nomi' },
    { k: 'type', l: 'Turi', t: 'select', opts: OPT.noteType, def: 'daily' },
    { k: 'date', l: 'Sana', t: 'date', def: today() },
    { k: 'mood', l: 'Kayfiyat', t: 'select', opts: OPT.mood, def: '🙂' },
    { k: 'status', l: 'Holat (muammolar uchun)', t: 'select', opts: [['open', 'Ochiq'], ['progress', 'Hal qilinmoqda'], ['done', 'Hal qilindi']], def: 'open' },
    { k: 'important', l: 'Muhim', t: 'switch', l2: 'Ro\'yxat boshida qadab qo\'yish' },
    { k: 'tags', l: 'Teglar', t: 'tags' },
    { k: 'body', l: 'Izoh matni', t: 'textarea', full: true, rows: 6, ph: 'Muammo, fikr, yechim…' },
    { k: 'images', l: 'Rasmlar / videolar', t: 'gallery', full: true },
  ],
  task: [
    { k: 'date', l: 'Sana', t: 'date', def: today() },
    { k: 'text', l: 'Vazifa', icon: 'check', req: true, ph: 'Nima qilish kerak?' },
    { k: 'time', l: 'Vaqt', t: 'time' },
    { k: 'priority', l: 'Muhimlik', t: 'select', opts: OPT.priority, def: 'mid' },
    { k: 'note', l: 'Izoh', t: 'text', full: true },
    { k: 'image', l: 'Vazifa rasmi', t: 'ratioImage', ratio: '16:9', w: 230, hint: 'Format va o\'lchamni o\'zingiz tanlaysiz' },
  ],
  folder: [
    { k: 'name', l: 'Jild nomi', icon: 'folder', req: true, ph: 'Phonk, Rep, Chill…' },
    { k: 'color', l: 'Rang', t: 'color', def: '#22e07a' },
    { k: 'cover', l: 'Muqova — faqat 1:1', t: 'ratioImage', ratio: '1:1', lockRatio: true, w: 180 },
    { k: 'note', l: 'Izoh', t: 'text', full: true },
  ],
  track: [
    { k: 'title', l: 'Musiqa nomi', icon: 'music', req: true },
    { k: 'artist', l: 'Ijrochi', t: 'text' },
    { k: 'folder', l: 'Jild', t: 'folder' },
    { k: 'mood', l: 'Kayfiyat', t: 'select', opts: [['chill', 'Chill'], ['energy', 'Energiya'], ['focus', 'Focus'], ['sad', 'G\'amgin'], ['party', 'Party']], def: 'chill' },
    { k: 'file', l: 'Audio fayl (mp3 / wav / m4a)', t: 'video', w: 190 },
  ],
  profile: [
    { k: 'name', l: 'Ism', icon: 'user', req: true, ph: 'Khumoyun' },
    { k: 'role', l: 'Kasb / rol', t: 'text', ph: 'Trader, Investor' },
    { k: 'avatar', l: 'Profil rasmi', t: 'ratioImage', ratio: '1:1', lockRatio: true, w: 190 },
    { k: 'motto', l: 'Shior', t: 'text', full: true, ph: 'Intizom — boylikning kaliti' },
    { k: 'bio', l: 'Qisqa izoh', t: 'text', full: true },
    { k: 'email', l: 'Email', t: 'text' },
    { k: 'phone', l: 'Telefon', t: 'text' },
    { k: 'country', l: 'Shahar / davlat', t: 'text' },
    { k: 'birthday', l: 'Tug\'ilgan kun', t: 'date' },
    { k: 'about', l: 'Shaxsiy ma\'lumotlar / eslatma', t: 'textarea', full: true, rows: 4 },
  ],
};
