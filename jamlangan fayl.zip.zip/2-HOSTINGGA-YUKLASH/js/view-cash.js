/* ============================================================
   KHUMOYUN OS — Cash: hisoblar, kirim, chiqim, o'tkazma, hisobot
   ============================================================ */
import { $, $$, esc, icon, on, toast, sfx, uid, fmtDate, todayISO, MON_SHORT } from './util.js';
import { state, save, money, netWorth, netWorthByType, monthStats, lastMonths, expenseByCategory, ACC_TYPES, ACC_TYPE_LABEL, ACC_TYPE_ICON, logActivity, monthKey as mk } from './store.js';
import { areaChart, donut, barChart } from './charts.js';
import { pageHead, section, empty, bar, kpi, statMini, kv, thumb, editBtn, delBtn } from './kit.js';
import { fillMedia, openForm, SCHEMAS } from './form.js';

export function applyTx(tx, dir = 1) {
  const acc = (id) => state.accounts.find((a) => a.id === id);
  const amt = Number(tx.amount) || 0, fee = Number(tx.fee) || 0;
  if (tx.type === 'income') { const a = acc(tx.account); if (a) a.balance += dir * amt; }
  else if (tx.type === 'expense') { const a = acc(tx.account); if (a) a.balance -= dir * amt; }
  else if (tx.type === 'transfer') {
    const f = acc(tx.account), t = acc(tx.toAccount);
    if (f) f.balance -= dir * (amt + fee);
    if (t) t.balance += dir * amt;
  }
}

export function openTxForm(type, data, ctx) {
  const schema = SCHEMAS[type];
  const editing = !!(data && data.id);
  const title = { income: editing ? 'Kirimni tahrirlash' : 'Yangi kirim', expense: editing ? 'Chiqimni tahrirlash' : 'Yangi chiqim', transfer: editing ? 'O\'tkazmani tahrirlash' : 'Yangi o\'tkazma' }[type];
  openForm({
    title, icon: type === 'income' ? 'download' : type === 'expense' ? 'upload' : 'swap', schema, data: data || {},
    subtitle: type === 'income' ? 'Daromadni hisobga qo\'shish' : type === 'expense' ? 'Xarajatni hisobga olish' : 'Hisoblar orasida pul o\'tkazish',
    allowDelete: editing, onDelete: () => {
      applyTx(data, -1);
      state.transactions = state.transactions.filter((t) => t.id !== data.id);
      save(); toast('O\'chirildi, balans qaytarildi', { type: 'warn' }); ctx.refresh();
    },
    onSave: (v) => {
      if (editing) { applyTx(data, -1); Object.assign(data, v); applyTx(data, 1); toast('Yangilandi', { type: 'success' }); }
      else {
        const tx = { id: uid('tx'), type, ...v, createdAt: new Date().toISOString() };
        state.transactions.push(tx); applyTx(tx, 1);
        logActivity(`${type === 'income' ? 'Kirim' : type === 'expense' ? 'Chiqim' : 'O\'tkazma'}: ${money(tx.amount)}`, type === 'income' ? 'download' : 'upload');
        toast('Saqlandi va balansga qo\'shildi', { type: 'success' });
      }
      save(); ctx.refresh();
    },
  });
}
export function openAccountForm(data, ctx) {
  const editing = !!(data && data.id);
  openForm({
    title: editing ? 'Hisobni tahrirlash' : 'Yangi hisob', icon: 'wallet', schema: SCHEMAS.account, data: data || {},
    allowDelete: editing, onDelete: () => { state.accounts = state.accounts.filter((a) => a.id !== data.id); save(); toast('Hisob o\'chirildi', { type: 'warn' }); ctx.refresh(); },
    onSave: (v) => {
      if (editing) Object.assign(data, v);
      else { state.accounts.push({ id: uid('acc'), ...v, createdAt: new Date().toISOString() }); logActivity(`Yangi hisob: ${v.name}`, 'wallet'); }
      save(); toast('Hisob saqlandi', { type: 'success' }); ctx.refresh();
    },
  });
}

export function render(view, ctx) {
  const tab = ctx.query.get('tab') || 'accounts';
  const tabs = [['accounts', 'Hisoblar', 'wallet'], ['income', 'Kirim', 'download'], ['expense', 'Chiqim', 'upload'], ['transfer', 'O\'tkazma', 'swap'], ['report', 'Hisobot', 'chart']];
  const nw = netWorth();
  const m = monthStats();
  const yuan = state.settings.currency;

  let body = '';
  if (tab === 'accounts') {
    const types = netWorthByType();
    body = `
      <div class="kpis" style="margin-bottom:20px">
        ${kpi({ label: 'Jami Net Worth', value: money(nw, { sensitive: true }), icon: 'dash' })}
        ${ACC_TYPES.map((t) => {
      const v = state.accounts.filter((a) => a.type === t).reduce((s, a) => s + (Number(a.balance) || 0), 0);
      return v ? kpi({ label: ACC_TYPE_LABEL[t], value: money(v, { sensitive: true }), icon: ACC_TYPE_ICON[t] }) : '';
    }).join('')}
      </div>
      ${section({
      title: 'Hisoblarim', icon: 'wallet', sub: `${state.accounts.length} ta hisob · har birini qalamcha tugmasi bilan tahrirlang`,
      actions: `<button class="btn sm ghost" data-act="reorder">${icon('swap')}Tartib</button><button class="btn primary sm" data-act="add-account">${icon('plus')}Hisob qo'shish</button>`,
      body: state.accounts.length ? `<div class="grid g3">${state.accounts.map((a) => `
        <div class="card lift reveal" style="border-left:3px solid ${esc(a.color || 'var(--accent)')}">
          <div class="card-h">
            <div class="row" style="gap:10px"><div class="avatar">${icon(a.icon || ACC_TYPE_ICON[a.type] || 'wallet')}</div>
              <div><div class="item-title">${esc(a.name)} ${a.hidden ? `<span class="badge">${icon('eye-off')}yashirin</span>` : ''}</div>
              <div class="tiny faint">${esc(ACC_TYPE_LABEL[a.type] || 'Boshqa')}</div></div></div>
            <div class="item-actions">${editBtn('edit-account', a.id)}${delBtn('del-account', a.id)}</div>
          </div>
          <div class="num" style="font-size:22px;font-weight:800;margin:6px 0">${money(a.balance, { sensitive: true, currency: a.currency })}</div>
          ${a.note ? `<div class="tiny faint">${esc(a.note)}</div>` : ''}
          <div class="row" style="gap:6px;margin-top:10px">
            <button class="btn sm soft" data-act="tx-from" data-id="${a.id}">${icon('download')}Kirim</button>
            <button class="btn sm ghost" data-act="tx-from" data-id="${a.id}" data-type="expense">${icon('upload')}Chiqim</button>
            <button class="btn sm ghost" data-act="toggle-hide" data-id="${a.id}">${icon(a.hidden ? 'eye' : 'eye-off')}</button>
          </div>
        </div>`).join('')}</div>`
        : empty({ icon: 'wallet', title: 'Hisoblar yo\'q', sub: 'Naqd, bank, kripto, aksiya — hammasini qo\'shing', action: `<button class="btn primary sm" data-act="add-account">${icon('plus')}Birinchi hisobni qo'shish</button>` })
    })}`;
  }

  if (tab === 'income' || tab === 'expense' || tab === 'transfer') {
    const list = state.transactions.filter((t) => t.type === tab).sort((a, b) => String(b.date).localeCompare(String(a.date)));
    const cur = mk(todayISO());
    const thisMonth = list.filter((t) => mk(t.date) === cur);
    const total = list.reduce((s, t) => s + (Number(t.amount) || 0), 0);
    const label = { income: 'Kirimlar', expense: 'Chiqimlar', transfer: 'O\'tkazmalar' }[tab];
    body = `
      <div class="kpis" style="margin-bottom:18px">
        ${kpi({ label: 'Bu oy jami', value: money(thisMonth.reduce((s, t) => s + (Number(t.amount) || 0), 0)), icon: 'calendar' })}
        ${kpi({ label: 'Umumiy jami', value: money(total), icon: 'coins' })}
        ${kpi({ label: 'Yozuvlar soni', value: String(list.length), icon: 'list' })}
        ${kpi({ label: OY_LABEL(cur), value: money(monthStats(cur)[tab === 'income' ? 'income' : tab === 'expense' ? 'expense' : 'transfer'] || 0), icon: 'chart' })}
      </div>
      ${section({
      title: label, icon: tab === 'income' ? 'download' : tab === 'expense' ? 'upload' : 'swap',
      sub: 'Har bir yozuvni qalamcha bilan tahrirlash mumkin',
      actions: `<button class="btn primary sm" data-act="add-tx" data-type="${tab}">${icon('plus')}Yangi qo'shish</button>`,
      body: list.length ? `<div class="card" style="padding:8px 12px">
          <div class="ledger-row head"><span>Nomi / izoh</span><span>Summa</span><span>Hisob</span><span>Sana</span></div>
          ${list.map((t) => `<div class="ledger-row">
            <div><div class="item-title">${icon(tab === 'income' ? 'down-arrow' : tab === 'expense' ? 'up-arrow' : 'swap')}${esc(t.category || t.note || label)}</div>
              ${t.note && t.category ? `<div class="tiny faint">${esc(t.note)}</div>` : ''}</div>
            <div class="num ${tab === 'income' ? 'up' : tab === 'expense' ? 'down' : ''}" style="font-weight:800">${money(t.amount)}</div>
            <div class="tiny">${esc(accName(t.account))}${t.toAccount ? ' → ' + esc(accName(t.toAccount)) : ''}</div>
            <div class="row between"><span class="tiny faint">${esc(fmtDate(t.date))}</span>
              <span class="item-actions">${editBtn('edit-tx', t.id, 'Tahrirlash')}${delBtn('del-tx', t.id)}</span></div>
          </div>`).join('')}
        </div>` : empty({ icon: 'coins', title: `${label} bo'sh`, sub: 'Birinchi yozuvni qo\'shing', action: `<button class="btn primary sm" data-act="add-tx" data-type="${tab}">${icon('plus')}Qo'shish</button>` })
    })}`;
  }

  if (tab === 'report') {
    const months = lastMonths(6);
    const cats = expenseByCategory();
    const sumIn = months.reduce((s, x) => s + x.income, 0), sumEx = months.reduce((s, x) => s + x.expense, 0);
    body = `
      <div class="kpis" style="margin-bottom:20px">
        ${kpi({ label: '6 oylik kirim', value: money(sumIn), icon: 'download' })}
        ${kpi({ label: '6 oylik chiqim', value: money(sumEx), icon: 'upload' })}
        ${kpi({ label: 'Sof natija', value: money(sumIn - sumEx), icon: 'trend', delta: { dir: sumIn - sumEx >= 0 ? 'up' : 'down', text: 'balans' } })}
        ${kpi({ label: 'Jamg\'arma darajasi', value: `${sumIn ? (((sumIn - sumEx) / sumIn) * 100).toFixed(1) : 0}%`, icon: 'target' })}
      </div>
      <div class="grid g2" style="margin-bottom:20px">
        <div class="card"><div class="card-h"><div class="card-t">${icon('trend')}Kirim / Chiqim dinamikasi</div></div>
          <div class="chart-wrap"><canvas data-chart="flow" data-h="250"></canvas></div></div>
        <div class="card"><div class="card-h"><div class="card-t">${icon('grid')}Chiqim kategoriyalari</div><span class="card-sub">${esc(OY_LABEL(mk(todayISO())))}</span></div>
          ${cats.length ? `<div class="row" style="gap:16px;flex-wrap:wrap">
            <div style="width:200px"><div class="chart-wrap"><canvas data-chart="cats"></canvas></div></div>
            <div class="col grow" style="gap:7px">${cats.map((c, i) => `<div class="row between">
              <span class="row" style="gap:8px"><i style="width:10px;height:10px;border-radius:3px;background:hsl(${(i * 47) % 360} 70% 60%);display:inline-block"></i>${esc(c.label)}</span>
              <b class="num">${money(c.value)}</b></div>`).join('')}</div>
          </div>` : empty({ icon: 'grid', title: 'Bu oy chiqim yo\'q', sub: 'Chiqim qo\'shsangiz, kategoriyalar shu yerda chiqadi' })}</div>
      </div>
      <div class="card"><div class="card-h"><div class="card-t">${icon('chart')}Oylik jadval</div></div>
        <div class="tbl-wrap"><table class="tbl">
          <thead><tr><th>Oy</th><th>Kirim</th><th>Chiqim</th><th>O'tkazma</th><th>Sof</th></tr></thead>
          <tbody>${months.map((x) => `<tr><td><b>${esc(x.label)}</b></td><td class="num up">${money(x.income)}</td>
            <td class="num down">${money(x.expense)}</td><td class="num faint">${money(x.transfer)}</td>
            <td class="num ${x.balance >= 0 ? 'up' : 'down'}"><b>${money(x.balance)}</b></td></tr>`).join('')}</tbody>
        </table></div></div>`;
  }

  view.innerHTML = `<div class="stagger">
    ${pageHead({
    title: 'Cash', icon: 'wallet', badge: 'moliya',
    sub: `${money(nw, { sensitive: true })} · kirim, chiqim, o'tkazma va hisobotlar`,
    actions: `<button class="btn sm" data-act="add-account">${icon('wallet')}Hisob</button>
        <button class="btn sm" data-act="add-tx" data-type="income">${icon('download')}Kirim</button>
        <button class="btn sm" data-act="add-tx" data-type="expense">${icon('upload')}Chiqim</button>
        <button class="btn primary sm" data-act="add-tx" data-type="transfer">${icon('swap')}O'tkazma</button>`
  })}
    <div class="tabs" style="margin-bottom:18px">${tabs.map(([k, l, ic]) => `<button class="tab ${k === tab ? 'active' : ''}" data-tab="${k}">${icon(ic)}${esc(l)}</button>`).join('')}</div>
    ${body}
  </div>`;

  const flowCv = view.querySelector('[data-chart="flow"]');
  if (flowCv) areaChart(flowCv, [
    { label: 'Kirim', values: lastMonths(6).map((x) => x.income), color: getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#22e07a' },
    { label: 'Chiqim', values: lastMonths(6).map((x) => x.expense), color: '#ff6b78', fill: false },
  ], lastMonths(6).map((x) => x.label), { height: 250 });
  const catCv = view.querySelector('[data-chart="cats"]');
  if (catCv) donut(catCv, expenseByCategory().map((c, i) => ({ ...c, color: `hsl(${(i * 47) % 360} 70% 60%)` })), { size: 200, label: 'Chiqim', fmt: (v) => money(v) });
  fillMedia(view);

  on(view, 'click', '[data-tab]', (e, b) => { sfx('nav'); ctx.go('cash', { tab: b.dataset.tab }); });
  on(view, 'click', '[data-act]', async (e, b) => {
    const act = b.dataset.act, id = b.dataset.id;
    if (act === 'add-account') return openAccountForm(null, ctx);
    if (act === 'edit-account') return openAccountForm(state.accounts.find((a) => a.id === id), ctx);
    if (act === 'del-account') {
      state.accounts = state.accounts.filter((a) => a.id !== id); save(); toast('Hisob o\'chirildi', { type: 'warn' }); return ctx.refresh();
    }
    if (act === 'toggle-hide') {
      const a = state.accounts.find((x) => x.id === id); if (a) { a.hidden = !a.hidden; save(); ctx.refresh(); } return;
    }
    if (act === 'tx-from') return openTxForm(b.dataset.type || 'income', { account: id, date: todayISO() }, ctx);
    if (act === 'add-tx') return openTxForm(b.dataset.type, { date: todayISO() }, ctx);
    if (act === 'edit-tx') { const t = state.transactions.find((x) => x.id === id); if (t) openTxForm(t.type, t, ctx); return; }
    if (act === 'del-tx') {
      const t = state.transactions.find((x) => x.id === id);
      if (t) { applyTx(t, -1); state.transactions = state.transactions.filter((x) => x.id !== id); save(); toast('O\'chirildi, balans qaytarildi', { type: 'warn' }); ctx.refresh(); }
      return;
    }
    if (act === 'reorder') {
      state.accounts = [...state.accounts].reverse(); save(); toast('Tartib o\'zgartirildi', { type: 'success' }); ctx.refresh(); return;
    }
  });
}
function accName(id) { const a = state.accounts.find((x) => x.id === id); return a ? a.name : '—'; }
function OY_LABEL(ym) { const [y, mo] = ym.split('-'); return `${MON_SHORT[Number(mo) - 1]} ${y}`; }

export { render as default };
