/* ============================================================
   KHUMOYUN OS — Izohlar (notes) + Kunlik vazifalar & Kalendar
   ============================================================ */
import { $, $$, esc, icon, on, toast, sfx, uid, fmtDate, fmtDateTime, todayISO, relTime, DAYS_UZ, MONTHS_UZ, modal, promptDialog, confirmDialog, clamp } from './util.js';
import { state, save, money, logActivity } from './store.js';
import { pageHead, section, empty, bar, ring, kpi, statMini, thumb, editBtn, delBtn, tagsRow, priorityBadge, viewBtn } from './kit.js';
import { fillMedia, openForm, SCHEMAS, OPT } from './form.js';

const TYPE_LABEL = Object.fromEntries(OPT.noteType);
const TYPE_ICON = { daily: 'note', problem: 'bell', idea: 'sparkles', plan: 'target', lesson: 'doc' };
const STATUS_LABEL = { open: ['loss', 'Ochiq'], progress: ['be', 'Hal qilinmoqda'], done: ['win', 'Hal qilindi'] };
let noteFilter = 'all', noteQuery = '';
let calDate = new Date();

/* ================= NOTES ================= */
export function openNoteForm(data, ctx) {
  const editing = !!(data && data.id);
  openForm({
    title: editing ? 'Izohni tahrirlash' : 'Yangi izoh', icon: 'note', schema: SCHEMAS.note, data: data || {}, size: 'wide',
    subtitle: 'Muammo, g\'oya, kunlik tahlil — rasm va videolar bilan',
    allowDelete: editing,
    onDelete: () => { state.notes = state.notes.filter((n) => n.id !== data.id); save(); toast('Izoh o\'chirildi', { type: 'warn' }); ctx.refresh(); },
    onSave: (v) => {
      if (editing) Object.assign(data, v);
      else { state.notes.push({ id: uid('nt'), ...v, createdAt: new Date().toISOString() }); logActivity(`Yangi izoh: ${v.title}`, 'note'); }
      save(); toast('Izoh saqlandi', { type: 'success' }); ctx.refresh();
    },
  });
}

function noteCard(n, ctx) {
  const [stCls, stLabel] = STATUS_LABEL[n.status] || STATUS_LABEL.open;
  return `<div class="card lift reveal">
    <div class="card-h">
      <div class="row" style="gap:10px">
        <span class="mood">${esc(n.mood || '📝')}</span>
        <div><div class="item-title">${esc(n.title)} ${n.important ? `<span class="pin-flag" title="Muhim">${icon('pin')}</span>` : ''}</div>
          <div class="item-sub">${icon('calendar')}${esc(fmtDate(n.date))} · ${icon(TYPE_ICON[n.type] || 'note')}${esc(TYPE_LABEL[n.type] || 'Izoh')}
            ${n.type === 'problem' ? `· <span class="badge ${stCls}">${esc(stLabel)}</span>` : ''}</div></div>
      </div>
      <div class="item-actions">${viewBtn('note-view', n.id)}${editBtn('edit-note', n.id)}${delBtn('del-note', n.id)}</div>
    </div>
    <div style="white-space:pre-wrap;font-size:13.6px;line-height:1.65">${esc((n.body || '').slice(0, 320))}${(n.body || '').length > 320 ? '…' : ''}</div>
    ${(n.images || []).length ? `<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(110px,1fr));margin-top:10px">
      ${n.images.slice(0, 4).map((g) => thumb(g.id, { ratio: '16:9', pos: g.pos })).join('')}</div>` : ''}
    ${(n.tags || []).length ? `<div style="margin-top:10px">${tagsRow(n.tags)}</div>` : ''}
  </div>`;
}

export function openNoteDetail(n, ctx) {
  const [stCls, stLabel] = STATUS_LABEL[n.status] || STATUS_LABEL.open;
  const m = modal.open({
    title: n.title, icon: TYPE_ICON[n.type] || 'note', size: 'wide',
    body: `
      <div class="row wrap" style="gap:8px">
        <span class="badge accent">${esc(TYPE_LABEL[n.type] || 'Izoh')}</span>
        <span class="badge">${icon('calendar')}${esc(fmtDate(n.date))}</span>
        <span class="mood">${esc(n.mood || '')}</span>
        ${n.type === 'problem' ? `<span class="badge ${stCls}">${esc(stLabel)}</span>` : ''}
        ${n.important ? `<span class="badge accent">${icon('pin')}Muhim</span>` : ''}
      </div>
      <div class="card flat" style="white-space:pre-wrap;line-height:1.7;font-size:14.5px">${esc(n.body || '')}</div>
      ${(n.images || []).length ? `<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(150px,1fr))">
        ${n.images.map((g) => thumb(g.id, { ratio: '16:9', pos: g.pos })).join('')}</div>` : ''}
      ${tagsRow(n.tags)}
      <div class="tiny faint">Yaratilgan: ${esc(fmtDateTime(n.createdAt || n.date))}</div>`,
    footer: `<button class="btn ghost" data-x>Yopish</button><button class="btn primary" data-e>${icon('pencil')}Tahrirlash</button>`,
  });
  m.root.querySelector('[data-x]').onclick = () => m.close();
  m.root.querySelector('[data-e]').onclick = () => { m.close(); openNoteForm(n, ctx); };
  fillMedia(m.root);
}

/* ================= TASKS / CALENDAR ================= */
export function openTaskForm(data, date, ctx) {
  const editing = !!(data && data.id);
  openForm({
    title: editing ? 'Vazifani tahrirlash' : 'Yangi vazifa', icon: 'check', schema: SCHEMAS.task, data: data || { date: date || todayISO() },
    subtitle: 'Kun, vaqt, muhimlik va rasm (16:9 / 1:1 / 9:16 — o\'zingiz tanlaysiz)',
    allowDelete: editing,
    onDelete: () => {
      const d = data.date || todayISO();
      state.tasks[d] = (state.tasks[d] || []).filter((t) => t.id !== data.id);
      save(); toast('Vazifa o\'chirildi', { type: 'warn' }); ctx.refresh();
    },
    onSave: (v) => {
      const d = v.date || todayISO();
      if (editing) {
        const oldD = data.date || d;
        const merged = { ...data, ...v, date: d };
        if (oldD !== d) state.tasks[oldD] = (state.tasks[oldD] || []).filter((t) => t.id !== data.id);
        state.tasks[d] = state.tasks[d] || [];
        const idx = state.tasks[d].findIndex((t) => t.id === data.id);
        if (idx >= 0) state.tasks[d][idx] = merged; else state.tasks[d].push(merged);
        Object.assign(data, merged);
      } else {
        state.tasks[d] = state.tasks[d] || [];
        state.tasks[d].push({ id: uid('tsk'), done: false, ...v });
        logActivity(`Yangi vazifa: ${v.text}`, 'check');
      }
      save(); toast('Vazifa saqlandi', { type: 'success' }); ctx.refresh();
    },
  });
}

function monthMatrix(year, month, weekStart = 1) {
  const first = new Date(year, month, 1);
  let offset = first.getDay() - weekStart;
  if (offset < 0) offset += 7;
  const cells = [];
  const start = new Date(year, month, 1 - offset);
  for (let i = 0; i < 42; i++) {
    const d = new Date(start.getFullYear(), start.getMonth(), start.getDate() + i);
    cells.push(d);
  }
  return cells;
}

export function render(view, ctx) {
  const route = ctx.route;
  if (route === 'notes') {
    let list = [...state.notes].sort((a, b) => String(b.date).localeCompare(String(a.date)));
    if (noteFilter !== 'all') list = list.filter((n) => n.type === noteFilter);
    if (noteQuery) { const q = noteQuery.toLowerCase(); list = list.filter((n) => `${n.title} ${n.body} ${(n.tags || []).join(' ')}`.toLowerCase().includes(q)); }
    list.sort((a, b) => (b.important ? 1 : 0) - (a.important ? 1 : 0));
    const problems = state.notes.filter((n) => n.type === 'problem' && n.status !== 'done');
    view.innerHTML = `<div class="stagger">
      ${pageHead({
      title: 'Izohlar', icon: 'note', badge: 'shaxsiy daftar',
      sub: 'Kunlik izohlar, muammolar va ularning yechimlari — rasm bilan',
      actions: `<button class="btn primary sm" data-act="add-note">${icon('plus')}Yangi izoh</button>`
    })}
      <div class="kpis" style="margin-bottom:18px">
        ${kpi({ label: 'Jami izohlar', value: String(state.notes.length), icon: 'note' })}
        ${kpi({ label: 'Ochiq muammolar', value: String(problems.length), icon: 'bell' })}
        ${kpi({ label: 'Muhim belgilangan', value: String(state.notes.filter((n) => n.important).length), icon: 'pin' })}
        ${kpi({ label: 'Bu hafta', value: String(state.notes.filter((n) => (Date.now() - new Date(n.date).getTime()) < 7 * 864e5).length), icon: 'calendar' })}
      </div>
      <div class="between" style="margin-bottom:14px">
        <div class="chips">
          <button class="chip ${noteFilter === 'all' ? 'active' : ''}" data-filter="all">Barchasi</button>
          ${OPT.noteType.map(([k, l]) => `<button class="chip ${noteFilter === k ? 'active' : ''}" data-filter="${k}">${esc(l)}</button>`).join('')}
        </div>
        <div class="top-search" style="max-width:280px">${icon('search')}<input id="nSearch" placeholder="Izohlardan qidirish…" value="${esc(noteQuery)}"></div>
      </div>
      ${list.length ? `<div class="grid g2">${list.map((n) => noteCard(n, ctx)).join('')}</div>`
        : empty({ icon: 'note', title: 'Izohlar yo\'q', sub: 'Bugungi fikr, muammo yoki g\'oyani yozib qo\'ying', action: `<button class="btn primary sm" data-act="add-note">${icon('plus')}Birinchi izohni yozish</button>` })}
    </div>`;
    fillMedia(view);
    const s = view.querySelector('#nSearch');
    if (s) s.addEventListener('input', (e) => { noteQuery = e.target.value; const p = e.target.selectionStart; ctx.refresh().then(() => { const el = view.querySelector('#nSearch'); if (el) { el.focus(); el.setSelectionRange(p, p); } }); });
    on(view, 'click', '[data-filter]', (e, b) => { noteFilter = b.dataset.filter; sfx('tap'); ctx.refresh(); });
    on(view, 'click', '[data-act]', async (e, b) => {
      const act = b.dataset.act, id = b.dataset.id;
      if (act === 'add-note') return openNoteForm(null, ctx);
      if (act === 'edit-note') return openNoteForm(state.notes.find((n) => n.id === id), ctx);
      if (act === 'note-view') { const n = state.notes.find((x) => x.id === id); if (n) return openNoteDetail(n, ctx); }
      if (act === 'del-note') {
        const ok = await confirmDialog('Izohni o\'chirish?', 'Bu izoh butunlay o\'chiriladi.', { danger: true, okLabel: 'O\'chirish' });
        if (!ok) return;
        state.notes = state.notes.filter((n) => n.id !== id); save(); toast('O\'chirildi', { type: 'warn' }); ctx.refresh(); return;
      }
    });
    return;
  }

  /* ---------- tasks ---------- */
  const weekStart = state.settings.weekStart == null ? 1 : state.settings.weekStart;
  const y = calDate.getFullYear(), mo = calDate.getMonth();
  const cells = monthMatrix(y, mo, weekStart);
  const sel = ctx.query.get('d') || todayISO();
  const selList = (state.tasks[sel] || []).slice().sort((a, b) => (a.time || '99').localeCompare(b.time || '99'));
  const st = { total: selList.length, done: selList.filter((t) => t.done).length };
  st.pct = st.total ? (st.done / st.total) * 100 : 0;
  const allTasks = Object.values(state.tasks).flat();
  const upcoming = Object.entries(state.tasks).filter(([d]) => d > todayISO()).sort().slice(0, 5);

  view.innerHTML = `<div class="stagger">
    ${pageHead({
    title: 'Kunlik vazifalar', icon: 'calendar', badge: 'kalendar va rejalar',
    sub: 'Har bir kunga alohida vazifalar, vaqt va rasm bilan reja tuzing',
    actions: `<button class="btn sm ghost" data-act="today">${icon('clock')}Bugun</button>
        <button class="btn primary sm" data-act="add-task">${icon('plus')}Vazifa qo'shish</button>`
  })}
    <div class="kpis" style="margin-bottom:18px">
      ${kpi({ label: 'Bugungi vazifalar', value: `${state.tasks[todayISO()] ? state.tasks[todayISO()].filter((t) => t.done).length : 0}/${(state.tasks[todayISO()] || []).length}`, icon: 'check' })}
      ${kpi({ label: 'Jami vazifalar', value: String(allTasks.length), icon: 'list' })}
      ${kpi({ label: 'Bajarilgan', value: String(allTasks.filter((t) => t.done).length), icon: 'check' })}
      ${kpi({ label: 'Seriya (streak)', value: streakDays() + ' kun', icon: 'fire' })}
    </div>

    <div class="grid" style="grid-template-columns:minmax(320px,1.1fr) minmax(300px,.9fr);margin-bottom:20px">
      <div class="card">
        <div class="card-h">
          <div class="card-t">${icon('calendar')}${esc(MONTHS_UZ[mo])} ${y}</div>
          <div class="row" style="gap:6px">
            <button class="icon-btn" data-act="prev-month">${icon('prev')}</button>
            <button class="icon-btn" data-act="next-month">${icon('next')}</button>
          </div>
        </div>
        <div class="cal">
          ${(weekStart === 1 ? ['Du', 'Se', 'Cho', 'Pay', 'Ju', 'Sha', 'Ya'] : ['Ya', 'Du', 'Se', 'Cho', 'Pay', 'Ju', 'Sha']).map((d) => `<div class="cal-dow">${d}</div>`).join('')}
          ${cells.map((d) => {
    const key = todayISO(d);
    const list = state.tasks[key] || [];
    const doneAll = list.length && list.every((t) => t.done);
    return `<button class="cal-day ${d.getMonth() !== mo ? 'other' : ''} ${key === todayISO() ? 'today' : ''} ${key === sel ? 'sel' : ''}" data-day="${key}">
              <span class="dn">${list.length ? list.length : ''}</span>
              <span>${d.getDate()}</span>
              <span class="dots">${list.length ? `<i style="${doneAll ? 'background:#3ce08a' : ''}"></i>` : ''}${list.length > 1 ? '<i></i>' : ''}</span>
            </button>`;
  }).join('')}
        </div>
        <div class="row" style="gap:12px;margin-top:12px">
          <span class="tiny faint">${icon('check')}Nuqta = vazifa bor</span>
          <span class="tiny faint" style="color:#3ce08a">${icon('check')}yashil = hammasi bajarilgan</span>
        </div>
      </div>

      <div class="card">
        <div class="card-h">
          <div class="card-t">${icon('clock')}${esc(fmtDate(sel))} · ${esc(DAYS_UZ[new Date(sel + 'T00:00:00').getDay()])}</div>
          <button class="btn sm ghost" data-act="add-task" data-date="${sel}">${icon('plus')}Qo'shish</button>
        </div>
        <div class="row" style="gap:14px;margin-bottom:12px">
          ${ring(st.pct, 78, st.total ? `${st.done}/${st.total}` : '0')}
          <div class="grow"><div class="h3">${st.total ? (st.pct === 100 ? 'Kun muvaffaqiyatli yakunlandi! 🎉' : 'Davom eting') : 'Vazifa yo\'q'}</div>
            <div style="margin-top:8px">${bar(st.pct)}</div>
            <div class="tiny faint" style="margin-top:6px">${st.pct.toFixed(0)}% bajarildi</div></div>
        </div>
        ${selList.length ? `<div class="col" style="gap:9px">${selList.map((t) => taskRow(t, sel)).join('')}</div>`
      : empty({ icon: 'check', title: 'Bu kunga vazifa yo\'q', sub: 'Reja tuzish — muvaffaqiyatning birinchi qadami', action: `<button class="btn soft sm" data-act="add-task" data-date="${sel}">${icon('plus')}Vazifa qo'shish</button>` })}
      </div>
    </div>

    <div class="grid g2 g-2">
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('right')}Keyingi kunlar</div></div>
        ${upcoming.length ? `<div class="col" style="gap:12px">${upcoming.map(([d, list]) => `<div>
          <div class="row between"><b>${esc(fmtDate(d))}</b><span class="tiny faint">${list.filter((t) => t.done).length}/${list.length} bajarildi</span></div>
          ${bar(list.length ? (list.filter((t) => t.done).length / list.length) * 100 : 0)}
          <div class="tiny faint" style="margin-top:5px">${esc(list.slice(0, 3).map((t) => t.text).join(' · '))}</div>
        </div>`).join('')}</div>` : empty({ icon: 'calendar', title: 'Rejalashtirilgan kunlar yo\'q', sub: 'Kalendardan kun tanlab, vazifa qo\'shing' })}
      </div>
      <div class="card">
        <div class="card-h"><div class="card-t">${icon('fire')}Kunlik intizom</div></div>
        <div class="row between" style="flex-wrap:wrap;gap:14px">
          ${ring(Math.min(100, streakDays() * 10), 96, streakDays() + ' kun')}
          <div class="grow col">
            ${statMini('Bugun', `${(state.tasks[todayISO()] || []).filter((t) => t.done).length}/${(state.tasks[todayISO()] || []).length}`, 'check')}
            ${statMini('Bu hafta', String(weekDone()), 'calendar')}
            ${statMini('Belgilangan kunlar', String(Object.keys(state.tasks).length), 'calendar')}
          </div>
        </div>
      </div>
    </div>
  </div>`;

  fillMedia(view);
  on(view, 'click', '[data-act]', (e, b) => {
    const act = b.dataset.act, id = b.dataset.id;
    if (act === 'prev-month') { calDate = new Date(y, mo - 1, 1); sfx('tap'); ctx.refresh(); return; }
    if (act === 'next-month') { calDate = new Date(y, mo + 1, 1); sfx('tap'); ctx.refresh(); return; }
    if (act === 'today') { calDate = new Date(); sfx('nav'); ctx.refresh(); return; }
    if (act === 'add-task') return openTaskForm(null, b.dataset.date || sel, ctx);
    if (act === 'edit-task') return openTaskForm((state.tasks[sel] || []).find((t) => t.id === id), sel, ctx);
    if (act === 'del-task') {
      state.tasks[sel] = (state.tasks[sel] || []).filter((t) => t.id !== id);
      save(); toast('Vazifa o\'chirildi', { type: 'warn' }); ctx.refresh(); return;
    }
    if (act === 'toggle-task') {
      const t = (state.tasks[sel] || []).find((x) => x.id === id);
      if (t) { t.done = !t.done; save(); sfx(t.done ? 'check' : 'uncheck'); if (t.done) toast('Bajarildi! ✔', { type: 'success', ms: 1400 }); ctx.refresh(); }
      return;
    }
  });
  on(view, 'click', '[data-day]', (e, b) => { sfx('tap'); ctx.go('tasks', { d: b.dataset.day }); });
}

function taskRow(t, date) {
  const ratio = t.image_ratio || '16:9';
  return `<div class="task ${t.done ? 'done' : ''}">
    <button class="cbox" data-act="toggle-task" data-id="${esc(t.id)}">${icon('check')}</button>
    <div class="grow">
      <div class="task-text">${esc(t.text)}</div>
      <div class="task-sub">
        ${t.time ? `<span>${icon('clock')}${esc(t.time)}</span>` : ''}
        ${priorityBadge(t.priority)}
        ${t.note ? `<span>${esc(t.note)}</span>` : ''}
        ${t.image ? `<span class="badge">${icon('image')}${esc(ratio)}</span>` : ''}
      </div>
      ${t.image ? `<div class="task-img" style="max-width:${ratio === '9:16' ? 210 : ratio === '1:1' ? 300 : 420}px">
        ${thumb(t.image, { ratio, pos: t.image_pos, zoom: t.image_zoom, icon: 'image' })}</div>` : ''}
    </div>
    <div class="item-actions" style="align-self:flex-start">
      ${editBtn('edit-task', t.id)}${delBtn('del-task', t.id)}
    </div>
  </div>`;
}
function streakDays() {
  let n = 0; const d = new Date();
  for (let i = 0; i < 400; i++) {
    const key = todayISO(d);
    const list = state.tasks[key] || [];
    if (list.length && list.every((t) => t.done)) { n++; d.setDate(d.getDate() - 1); }
    else if (i === 0) { d.setDate(d.getDate() - 1); continue; }
    else break;
  }
  return n;
}
function weekDone() {
  let n = 0;
  for (let i = 0; i < 7; i++) { const d = new Date(); d.setDate(d.getDate() - i); n += (state.tasks[todayISO(d)] || []).filter((t) => t.done).length; }
  return n;
}

export { render as default };
