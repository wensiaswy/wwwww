/* ============================================================
   KHUMOYUN OS — state, storage (localStorage + IndexedDB), export/import
   ============================================================ */
import { uid, debounce, todayISO, nowISO, clamp } from './util.js';
import { createZip, readZip } from './zip.js';

const LS_KEY = 'khumoyun-os.state.v1';
const IDB_NAME = 'khumoyun-os-media';

export const DEFAULT_NAV = ['dashboard', 'cash', 'journal', 'goals', 'wishlist', 'notes', 'tasks', 'music', 'search', 'settings'];

export function defaults() {
  return {
    v: 1,
    createdAt: nowISO(),
    profile: { name: 'Khumoyun', avatar: null, role: 'Trader', bio: '', email: '', phone: '', country: '', birthday: '', about: '', motto: 'Intizom — boylikning kaliti' },
    security: { pinHash: '', salt: '', pinLen: 0, autoLock: 0, lockOnStart: true, hint: 'PIN kodni eslab qoling' },
    settings: {
      theme: 'emerald', preset: 'glass', currency: 'USD', hideNetWorth: false,
      sound: true, volume: .5, ambient: false, soundPack: 'glass',
      ui: { glass: 22, radius: 18, dim: 44, fontScale: 100, anim: 100, panelAlpha: 6, borderAlpha: 11, shadow: 1, density: 'cozy' },
      bg: {
        main: { mediaId: null, type: 'none', blur: 0, dim: 44, pos: '50% 50%', zoom: 100, hide: false },
        lock: { mediaId: null, type: 'none', blur: 18, dim: 48, pos: '50% 50%', zoom: 100 },
      },
      effects: { particles: true, cursorGlow: true, ripple: true, tilt: true },
      perf: 'auto', lowfx: false,
      nav: { order: [...DEFAULT_NAV], labels: {}, hidden: [] },
      weekStart: 1,
    },
    accounts: [], transactions: [], trades: [], goals: [], wishes: [], notes: [], tasks: {}, snapshots: [], activity: [],
    music: { folders: [], tracks: [] },
  };
}

export let state = defaults();
const listeners = new Set();

export function subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); }
function emit(reason) { listeners.forEach((f) => { try { f(reason); } catch (e) { console.error(e); } }); }

export const saveNow = () => {
  try { localStorage.setItem(LS_KEY, JSON.stringify(state)); }
  catch (e) { console.warn('Saqlashda xatolik (xotira to\'ldi?)', e); }
};
export const save = debounce(() => { saveNow(); emit('save'); }, 180);

export function load() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return false;
    const data = JSON.parse(raw);
    state = deepMerge(defaults(), data);
    if (!state.settings.nav.order || !state.settings.nav.order.length) state.settings.nav.order = [...DEFAULT_NAV];
    DEFAULT_NAV.forEach((k) => { if (!state.settings.nav.order.includes(k)) state.settings.nav.order.push(k); });
    return true;
  } catch (e) { console.warn('State yuklanmadi', e); return false; }
}
function deepMerge(base, over) {
  if (Array.isArray(base)) return Array.isArray(over) ? over : base;
  if (base && typeof base === 'object') {
    const out = { ...base };
    if (over && typeof over === 'object') {
      Object.keys(over).forEach((k) => { out[k] = k in base ? deepMerge(base[k], over[k]) : over[k]; });
    }
    return out;
  }
  return over === undefined ? base : over;
}

export function logActivity(text, icon = 'sparkles', kind = 'generic') {
  state.activity.unshift({ id: uid('act'), text, icon, kind, at: nowISO() });
  state.activity = state.activity.slice(0, 80);
}

/* ---------------- MONEY / FORMAT ---------------- */
const SYMBOLS = { USD: '$', EUR: '€', UZS: 'so\'m', RUB: '₽', GBP: '£', TRY: '₺', JPY: '¥' };
export function money(n, opts = {}) {
  const cur = opts.currency || state.settings.currency || 'USD';
  const v = Number(n) || 0;
  const hide = opts.hide || (state.settings.hideNetWorth && opts.sensitive);
  if (hide) return '••••••';
  const sign = v < 0 ? '-' : (opts.plus && v > 0 ? '+' : '');
  const abs = Math.abs(v);
  const digits = cur === 'UZS' || cur === 'JPY' || cur === 'RUB' ? 0 : (abs < 1000 && abs % 1 !== 0 ? 2 : abs < 1000 ? 0 : 0);
  const num = abs.toLocaleString('en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
  if (cur === 'UZS') return `${sign}${num} so'm`;
  return `${sign}${SYMBOLS[cur] || ''}${num}`;
}
export const moneyFull = (n, opts = {}) => money(n, { ...opts, currency: opts.currency || state.settings.currency });
export function pct(n, digits = 1) { return `${(Number(n) || 0).toFixed(digits)}%`; }
export function short(n) {
  const v = Math.abs(Number(n) || 0); const s = n < 0 ? '-' : '';
  if (v >= 1e9) return s + (v / 1e9).toFixed(2) + 'B';
  if (v >= 1e6) return s + (v / 1e6).toFixed(2) + 'M';
  if (v >= 1e3) return s + (v / 1e3).toFixed(1) + 'k';
  return s + v.toFixed(0);
}

/* ---------------- MEDIA (IndexedDB) ---------------- */
let _db = null;
function db() {
  return new Promise((resolve, reject) => {
    if (_db) return resolve(_db);
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = () => {
      const d = req.result;
      if (!d.objectStoreNames.contains('media')) d.createObjectStore('media', { keyPath: 'id' });
    };
    req.onsuccess = () => { _db = req.result; resolve(_db); };
    req.onerror = () => reject(req.error);
  });
}
async function tx(mode, fn) {
  const d = await db();
  return new Promise((resolve, reject) => {
    const t = d.transaction('media', mode);
    const store = t.objectStore('media');
    const r = fn(store);
    t.oncomplete = () => resolve(r && r.result !== undefined ? r.result : r);
    t.onerror = () => reject(t.error);
  });
}
const urlCache = new Map();
export const media = {
  async put(record) { await tx('readwrite', (s) => s.put(record)); return record.id; },
  async get(id) { if (!id) return null; const d = await db(); return new Promise((res, rej) => { const r = d.transaction('media').objectStore('media').get(id); r.onsuccess = () => res(r.result || null); r.onerror = () => rej(r.error); }); },
  async del(id) {
    if (urlCache.has(id)) { URL.revokeObjectURL(urlCache.get(id)); urlCache.delete(id); }
    await tx('readwrite', (s) => s.delete(id));
  },
  async all() { const d = await db(); return new Promise((res, rej) => { const r = d.transaction('media').objectStore('media').getAll(); r.onsuccess = () => res(r.result || []); r.onerror = () => rej(r.error); }); },
  async url(id) {
    if (!id) return null;
    if (urlCache.has(id)) return urlCache.get(id);
    const rec = await this.get(id);
    if (!rec || !rec.blob) return null;
    const u = URL.createObjectURL(rec.blob);
    urlCache.set(id, u);
    return u;
  },
  async usage() { const all = await this.all(); return all.reduce((s, m) => s + (m.size || 0), 0); },
  async clear() { await tx('readwrite', (s) => s.clear()); urlCache.clear(); },
};
export async function mediaFromFile(file, opts = {}) {
  const maxDim = opts.maxDim || 2400;
  const isImg = (file.type || '').startsWith('image/');
  let blob = file;
  if (isImg && file.type !== 'image/svg+xml' && file.type !== 'image/gif') {
    blob = await compressImage(file, maxDim, opts.quality || .88);
  }
  const id = uid('m');
  const rec = { id, name: file.name || 'fayl', type: blob.type || file.type || 'application/octet-stream', size: blob.size, blob, addedAt: nowISO() };
  await media.put(rec);
  return { id, name: rec.name, type: rec.type, size: rec.size };
}
function compressImage(file, maxDim, quality) {
  return new Promise((resolve) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      let { width: w, height: h } = img;
      const scale = Math.min(1, maxDim / Math.max(w, h));
      w = Math.round(w * scale); h = Math.round(h * scale);
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      const ctx = c.getContext('2d');
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, 0, 0, w, h);
      c.toBlob((b) => { URL.revokeObjectURL(url); resolve(b || file); }, 'image/jpeg', quality);
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve(file); };
    img.src = url;
  });
}

/* ---------------- COMPUTED ---------------- */
export const activeAccounts = () => state.accounts.filter((a) => !a.hidden);
export function netWorth() {
  return state.accounts.reduce((s, a) => (a.hidden ? s : s + (Number(a.balance) || 0)), 0);
}
export function netWorthByType() {
  const map = new Map();
  state.accounts.filter((a) => !a.hidden).forEach((a) => {
    const t = a.type || 'other';
    map.set(t, (map.get(t) || 0) + (Number(a.balance) || 0));
  });
  return [...map.entries()].map(([k, v]) => ({ label: ACC_TYPE_LABEL[k] || k, value: v, key: k }));
}
export const ACC_TYPES = ['cash', 'bank', 'crypto', 'stock', 'realestate', 'vehicle', 'other'];
export const ACC_TYPE_LABEL = { cash: 'Naqd', bank: 'Bank', crypto: 'Kripto', stock: 'Aksiya', realestate: 'Ko\'chmas mulk', vehicle: 'Transport', other: 'Boshqa' };
export const ACC_TYPE_ICON = { cash: 'wallet', bank: 'bank', crypto: 'coins', stock: 'chart', realestate: 'dash', vehicle: 'cursor', other: 'grid' };

export function txOf(type) { return state.transactions.filter((t) => t.type === type); }
export function monthKey(iso) { return (iso || todayISO()).slice(0, 7); }
export function monthStats(ym = monthKey(todayISO())) {
  let income = 0, expense = 0, transfer = 0;
  state.transactions.forEach((t) => {
    if (t.type === 'transfer') { if (monthKey(t.date) === ym) transfer += Number(t.amount) || 0; return; }
    if (monthKey(t.date) !== ym) return;
    if (t.type === 'income') income += Number(t.amount) || 0; else expense += Number(t.amount) || 0;
  });
  return { income, expense, transfer, balance: income - expense, rate: income > 0 ? ((income - expense) / income) * 100 : 0 };
}
export function lastMonths(n = 6) {
  const out = [];
  const d = new Date();
  for (let i = n - 1; i >= 0; i--) {
    const dd = new Date(d.getFullYear(), d.getMonth() - i, 1);
    const ym = `${dd.getFullYear()}-${String(dd.getMonth() + 1).padStart(2, '0')}`;
    out.push({ ym, label: dd.toLocaleString('en-US', { month: 'short' }), ...monthStats(ym) });
  }
  return out;
}
export function expenseByCategory(ym = monthKey(todayISO())) {
  const map = new Map();
  state.transactions.filter((t) => t.type === 'expense' && monthKey(t.date) === ym).forEach((t) => {
    const k = t.category || 'Boshqa';
    map.set(k, (map.get(k) || 0) + (Number(t.amount) || 0));
  });
  return [...map.entries()].map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);
}

export function tradeStats(list = state.trades) {
  const closed = list.filter((t) => t.result && t.result !== 'open');
  const wins = closed.filter((t) => t.result === 'win');
  const losses = closed.filter((t) => t.result === 'loss');
  const gross = closed.reduce((s, t) => s + (Number(t.pnl) || 0), 0);
  const sumWin = wins.reduce((s, t) => s + Math.abs(Number(t.pnl) || 0), 0);
  const sumLoss = losses.reduce((s, t) => s + Math.abs(Number(t.pnl) || 0), 0);
  const rs = closed.map((t) => Number(t.rr) || 0).filter((x) => x);
  return {
    count: list.length, closed: closed.length, open: list.filter((t) => t.result === 'open').length,
    wins: wins.length, losses: losses.length,
    pnl: gross, winRate: closed.length ? (wins.length / closed.length) * 100 : 0,
    avgR: rs.length ? rs.reduce((a, b) => a + b, 0) / rs.length : 0,
    profitFactor: sumLoss > 0 ? sumWin / sumLoss : (sumWin > 0 ? 99 : 0),
    best: list.reduce((m, t) => Math.max(m, Number(t.pnl) || 0), 0),
    worst: list.reduce((m, t) => Math.min(m, Number(t.pnl) || 0), 0),
  };
}
export function goalProgress(g) {
  const target = Number(g.target) || 0, saved = Number(g.saved) || 0;
  return { target, saved, left: Math.max(0, target - saved), pct: target > 0 ? clamp((saved / target) * 100, 0, 100) : 0 };
}
export function wishProgress(w) { return goalProgress({ target: w.price, saved: w.saved }); }
export function tasksFor(date) { return state.tasks[date] || []; }
export function tasksBetween(fromISO, toISOStr) {
  const out = [];
  Object.keys(state.tasks).forEach((d) => { if (d >= fromISO && d <= toISOStr) state.tasks[d].forEach((t) => out.push({ ...t, date: d })); });
  return out;
}
export function todayStats(date = todayISO()) {
  const list = tasksFor(date);
  const done = list.filter((t) => t.done).length;
  return { total: list.length, done, pct: list.length ? (done / list.length) * 100 : 0 };
}
export function streak() {
  let n = 0;
  const d = new Date();
  for (let i = 0; i < 400; i++) {
    const key = todayISO(d);
    const list = state.tasks[key] || [];
    if (list.length && list.every((t) => t.done)) { n++; d.setDate(d.getDate() - 1); }
    else if (i === 0) { d.setDate(d.getDate() - 1); continue; }
    else break;
  }
  return n;
}
export function ensureSnapshot() {
  const t = todayISO();
  const last = state.snapshots[state.snapshots.length - 1];
  const value = netWorth();
  if (!last || last.date !== t) state.snapshots.push({ date: t, value });
  else last.value = value;
  state.snapshots = state.snapshots.slice(-400);
  save();
}
export function netWorthDelta(days = 30) {
  const t = new Date(); t.setDate(t.getDate() - days);
  const key = todayISO(t);
  const past = [...state.snapshots].reverse().find((s) => s.date <= key) || state.snapshots[0];
  const now = netWorth();
  if (!past || !past.value) return { abs: 0, pct: 0 };
  return { abs: now - past.value, pct: ((now - past.value) / Math.abs(past.value)) * 100 };
}

/* ---------------- PIN ---------------- */
async function sha(text) {
  const buf = new TextEncoder().encode(text);
  if (crypto && crypto.subtle) {
    const h = await crypto.subtle.digest('SHA-256', buf);
    return [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  let h = 0; for (const b of buf) h = (h * 31 + b) >>> 0;
  return 'fb' + h.toString(16);
}
export async function hashPin(pin, salt) {
  let out = await sha(salt + ':' + pin);
  for (let i = 0; i < 3; i++) out = await sha(out + salt);
  return out;
}
export async function setPin(pin) {
  const salt = uid('s');
  state.security.salt = salt;
  state.security.pinHash = await hashPin(pin, salt);
  state.security.pinLen = String(pin || '').length;   // PIN uzunligi — avtomatik ochilish uchun
  saveNow();
}
export async function verifyPin(pin) {
  if (!state.security.pinHash) return false;
  return (await hashPin(pin, state.security.salt)) === state.security.pinHash;
}

/* ---------------- EXPORT / IMPORT ---------------- */
export async function exportAll(onProgress) {
  const payload = JSON.parse(JSON.stringify(state));
  payload.exportedAt = nowISO();
  payload.app = 'KHUMOYUN OS';
  payload.version = 1;
  const files = [{
    name: 'README.txt', data: [
      'KHUMOYUN OS — zaxira nusxa',
      'Eksport sanasi: ' + new Date().toLocaleString(),
      '',
      'data.json      — barcha yozuvlar (hisoblar, tradlar, maqsadlar, vazifalar, musiqa ro\'yxati)',
      'media/         — yuklangan rasm, video va mp3 fayllar',
      '',
      'Import: Sozlamalar → Ma\'lumotlar → Import → shu ZIP faylni tanlang.',
    ].join('\n')
  }, { name: 'data.json', data: JSON.stringify(payload, null, 2) }];
  const all = await media.all();
  all.forEach((m) => {
    const ext = (m.name || '').includes('.') ? m.name.split('.').pop().slice(0, 8) : (m.type || '').split('/')[1] || 'bin';
    files.push({ name: `media/${m.id}__${(m.name || 'fayl').replace(/[^\w.\-]+/g, '_')}`, data: m.blob });
  });
  const blob = await createZip(files, onProgress);
  return { blob, count: files.length, media: all.length, size: blob.size };
}
export async function exportJSON() {
  const payload = JSON.parse(JSON.stringify(state));
  payload.exportedAt = nowISO(); payload.app = 'KHUMOYUN OS';
  return new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
}
export async function importFile(file, mode = 'replace', onProgress) {
  const result = { ok: false, media: 0, mode };
  const isZip = /\.zip$/i.test(file.name) || file.type === 'application/zip' || file.type === 'application/x-zip-compressed';
  if (isZip) {
    const entries = await readZip(await file.arrayBuffer());
    const dataEntry = entries.find((e) => /(^|\/)data\.json$/i.test(e.name)) || entries.find((e) => /\.json$/i.test(e.name));
    if (!dataEntry) throw new Error('ZIP ichida data.json topilmadi');
    const payload = JSON.parse(new TextDecoder().decode(dataEntry.data));
    await applyImport(payload, mode);
    const mediaEntries = entries.filter((e) => /(^|\/)media\//i.test(e.name));
    let i = 0;
    for (const e of mediaEntries) {
      const base = e.name.split('/').pop();
      const [id, ...rest] = base.split('__');
      const orig = rest.join('__') || base;
      const type = mimeFromName(orig);
      await media.put({ id, name: orig, type, size: e.data.length, blob: new Blob([e.data], { type }), addedAt: nowISO() });
      result.media++; i++;
      if (onProgress) onProgress(i, mediaEntries.length, orig);
    }
    result.ok = true;
  } else {
    const payload = JSON.parse(await file.text());
    await applyImport(payload, mode);
    result.ok = true;
  }
  saveNow();
  emit('import');
  return result;
}
function mimeFromName(name) {
  const ext = (name.split('.').pop() || '').toLowerCase();
  return ({
    jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif', svg: 'image/svg+xml', avif: 'image/avif',
    mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime', mkv: 'video/x-matroska',
    mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', m4a: 'audio/mp4', flac: 'audio/flac', aac: 'audio/aac',
  })[ext] || 'application/octet-stream';
}
async function applyImport(payload, mode) {
  if (!payload || typeof payload !== 'object') throw new Error('Fayl tuzilishi noto\'g\'ri');
  if (mode === 'replace') {
    state = deepMerge(defaults(), payload);
    DEFAULT_NAV.forEach((k) => { if (!state.settings.nav.order.includes(k)) state.settings.nav.order.push(k); });
  } else {
    ['accounts', 'transactions', 'trades', 'goals', 'wishes', 'notes', 'snapshots'].forEach((k) => {
      if (Array.isArray(payload[k])) {
        const ids = new Set(state[k].map((x) => x.id));
        payload[k].forEach((item) => { if (!ids.has(item.id)) state[k].push(item); });
      }
    });
    if (payload.profile) state.profile = { ...state.profile, ...payload.profile, avatar: state.profile.avatar || payload.profile.avatar };
    if (payload.tasks) Object.entries(payload.tasks).forEach(([d, list]) => {
      state.tasks[d] = state.tasks[d] || [];
      const ids = new Set(state.tasks[d].map((x) => x.id));
      list.forEach((t) => { if (!ids.has(t.id)) state.tasks[d].push(t); });
    });
    if (payload.music) {
      const fIds = new Set(state.music.folders.map((f) => f.id));
      (payload.music.folders || []).forEach((f) => { if (!fIds.has(f.id)) state.music.folders.push(f); });
      const tIds = new Set(state.music.tracks.map((t) => t.id));
      (payload.music.tracks || []).forEach((t) => { if (!tIds.has(t.id)) state.music.tracks.push(t); });
    }
  }
}
export async function wipeAll(keepPin = true) {
  const sec = { ...state.security };
  state = defaults();
  if (keepPin) state.security = sec;
  await media.clear();
  saveNow(); emit('wipe');
}
export function storageEstimate() {
  try {
    const used = new Blob([localStorage.getItem(LS_KEY) || '']).size;
    return { stateBytes: used };
  } catch (e) { return { stateBytes: 0 }; }
}
export function touch() { save(); }
