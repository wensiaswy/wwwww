/* ============================================================
   KHUMOYUN OS — Maqsadlar (foizli progress) + Wishlist
   ============================================================ */
import { $, $$, esc, icon, on, toast, sfx, uid, fmtDate, todayISO, promptDialog, confirmDialog, clamp, modal } from './util.js';
import { state, save, money, goalProgress, wishProgress, logActivity } from './store.js';
import { pageHead, section, empty, bar, ring, kpi, statMini, thumb, editBtn, delBtn, stars, kv, priorityBadge } from './kit.js';
import { fillMedia, openForm, SCHEMAS, OPT } from './form.js';

const CAT_LABEL = Object.fromEntries([...OPT.goalCat, ...OPT.wishCat]);

/* ================= GOALS ================= */
export function openGoalForm(data, ctx) {
  const editing = !!(data && data.id);
  openForm({
    title: editing ? 'Maqsadni tahrirlash' : 'Yangi maqsad', icon: 'target', schema: SCHEMAS.goal, data: data || {}, size: 'wide',
    subtitle: 'Maqsad, muddat, qadamlar va rasmni kiriting — progress foizlarda kuzatiladi',
    allowDelete: editing,
    onDelete: () => { state.goals = state.goals.filter((g) => g.id !== data.id); save(); toast('Maqsad o\'chirildi', { type: 'warn' }); ctx.refresh(); },
    onSave: (v) => {
      if (editing) Object.assign(data, v);
      else { state.goals.push({ id: uid('goal'), ...v, history: v.saved ? [{ at: new Date().toISOString(), amount: v.saved, note: 'Boshlang\'ich summa' }] : [], createdAt: new Date().toISOString() }); logActivity(`Yangi maqsad: ${v.title}`, 'target'); }
      save(); toast('Maqsad saqlandi', { type: 'success' }); ctx.refresh();
    },
  });
}
async function addFunds(g, ctx) {
  const v = await promptDialog('Pul qo\'shish', `«${g.title}» uchun qancha qo'shmoqchisiz?`, { type: 'number', icon: 'coins', placeholder: '100' });
  if (!v || isNaN(Number(v))) return;
  const amount = Number(v);
  const before = goalProgress(g).pct;
  g.saved = (Number(g.saved) || 0) + amount;
  g.history = g.history || [];
  g.history.unshift({ at: new Date().toISOString(), amount, note: 'Jamg\'arma qo\'shildi' });
  save();
  sfx('coin');
  const after = goalProgress(g).pct;
  if (after >= 100 && before < 100) { toast('🎉 Maqsad bajarildi! Tabriklaymiz!', { type: 'success', ms: 4200 }); sfx('success'); }
  else toast(`${money(amount)} qo'shildi · ${after.toFixed(1)}%`, { type: 'success' });
  logActivity(`Maqsadga ${money(amount)} qo'shildi: ${g.title}`, 'coins');
  ctx.refresh();
}
function goalCard(g, ctx) {
  const p = goalProgress(g);
  const days = g.deadline ? Math.ceil((new Date(g.deadline) - new Date()) / 86400000) : null;
  const done = p.pct >= 100;
  return `<div class="card goal-card lift reveal" style="border-color:${done ? 'color-mix(in srgb,var(--accent) 45%,transparent)' : ''}">
    <div style="position:relative">
      ${thumb(g.cover, { ratio: '16:9', pos: g.cover_pos, zoom: g.cover_zoom, icon: 'target', cls: 'shine' })}
      <div class="row" style="position:absolute;top:9px;left:9px;gap:6px;z-index:2">
        <span class="badge accent">${icon('target')}${esc(CAT_LABEL[g.category] || 'Maqsad')}</span>
        ${done ? `<span class="badge win">${icon('check')}Bajarildi</span>` : ''}
      </div>
      <div class="item-actions" style="position:absolute;top:9px;right:9px;z-index:3;opacity:1">
        ${editBtn('edit-goal', g.id)}${delBtn('del-goal', g.id)}
      </div>
    </div>
    <div class="goal-body">
      <div class="between">
        <div class="item-title">${esc(g.title)}</div>${stars(g.priority)}
      </div>
      <div>
        ${bar(p.pct, done ? 'green' : p.pct > 50 ? 'green' : 'warn')}
        <div class="pmeta">
          <span><b class="accent">${p.pct.toFixed(1)}%</b> bajarildi</span>
          <span>${money(p.saved)} / ${money(p.target)}</span>
        </div>
      </div>
      <div class="row wrap" style="gap:6px">
        <span class="badge">${icon('coins')}${p.left > 0 ? money(p.left) + ' qoldi' : 'To\'liq yig\'ildi'}</span>
        ${days != null ? `<span class="badge ${days < 0 ? 'loss' : days < 30 ? 'be' : ''}">${icon('clock')}${days < 0 ? Math.abs(days) + ' kun o\'tdi' : days + ' kun qoldi'}</span>` : ''}
        ${(g.steps || []).length ? `<span class="badge">${icon('list')}${(g.steps || []).filter((s) => s.done).length}/${g.steps.length} qadam</span>` : ''}
      </div>
      ${(g.steps || []).length ? `<div class="col" style="gap:6px">${g.steps.slice(0, 4).map((s, i) => `<div class="row" style="gap:9px;cursor:pointer" data-act="toggle-step" data-id="${g.id}" data-step="${i}">
        <span class="cbox ${s.done ? 'done' : ''}" style="width:19px;height:19px">${icon('check')}</span>
        <span class="tiny ${s.done ? 'faint' : ''}" style="${s.done ? 'text-decoration:line-through' : ''}">${esc(s.text)}</span></div>`).join('')}</div>` : ''}
      <div class="row" style="gap:6px;margin-top:2px">
        <button class="btn sm soft" data-act="fund" data-id="${g.id}">${icon('plus')}Pul qo'shish</button>
        <button class="btn sm ghost" data-act="goal-detail" data-id="${g.id}">${icon('eye')}Batafsil</button>
      </div>
    </div>
  </div>`;
}

/* ================= WISHLIST ================= */
export function openWishForm(data, ctx) {
  const editing = !!(data && data.id);
  openForm({
    title: editing ? 'Xohishni tahrirlash' : 'Yangi xohish', icon: 'star', schema: SCHEMAS.wish, data: data || {},
    subtitle: 'Narx, rasm va jamg\'arma — progress foizlarda ko\'rinadi',
    allowDelete: editing,
    onDelete: () => { state.wishes = state.wishes.filter((w) => w.id !== data.id); save(); toast('O\'chirildi', { type: 'warn' }); ctx.refresh(); },
    onSave: (v) => {
      if (editing) Object.assign(data, v);
      else { state.wishes.push({ id: uid('wish'), ...v, createdAt: new Date().toISOString() }); logActivity(`Xohishlar ro'yxatiga qo'shildi: ${v.title}`, 'star'); }
      save(); toast('Saqlandi', { type: 'success' }); ctx.refresh();
    },
  });
}
async function addWishFunds(w, ctx) {
  const v = await promptDialog('Jamg\'arma qo\'shish', `«${w.title}» uchun summa kiriting`, { type: 'number', icon: 'coins' });
  if (!v || isNaN(Number(v))) return;
  w.saved = (Number(w.saved) || 0) + Number(v);
  save(); sfx('coin');
  const p = wishProgress(w);
  toast(p.pct >= 100 ? '🎉 Yig\'ildi! Endi sotib olishingiz mumkin!' : `${p.pct.toFixed(1)}% yig'ildi`, { type: 'success' });
  ctx.refresh();
}
function wishCard(w, ctx) {
  const p = wishProgress(w);
  const done = w.purchased || p.pct >= 100;
  return `<div class="card wish-card lift reveal" style="${done ? 'border-color:color-mix(in srgb,#3ce08a 45%,transparent)' : ''}">
    <div style="position:relative">
      ${thumb(w.cover, { ratio: '1:1', pos: w.cover_pos, zoom: w.cover_zoom, icon: 'star', cls: 'shine' })}
      <div class="row" style="position:absolute;top:9px;left:9px;gap:6px;z-index:2">
        <span class="badge accent">${esc(CAT_LABEL[w.category] || 'Boshqa')}</span>
        ${w.purchased ? `<span class="badge win">${icon('check')}Sotib olindi</span>` : ''}
      </div>
      <div class="item-actions" style="position:absolute;top:9px;right:9px;z-index:3;opacity:1">
        ${editBtn('edit-wish', w.id)}${delBtn('del-wish', w.id)}
      </div>
    </div>
    <div class="goal-body">
      <div class="between"><div class="item-title">${esc(w.title)}</div>${stars(w.priority)}</div>
      ${bar(p.pct, p.pct >= 100 ? 'green' : 'warn')}
      <div class="pmeta"><span><b class="accent">${p.pct.toFixed(1)}%</b></span><span>${money(p.saved)} / ${money(p.target)}</span></div>
      <div class="row wrap" style="gap:6px">
        ${w.url ? `<a class="btn sm ghost" href="${esc(w.url)}" target="_blank" rel="noopener">${icon('right')}Havola</a>` : ''}
        <button class="btn sm soft" data-act="wish-fund" data-id="${w.id}">${icon('plus')}Jamg'arish</button>
        <button class="btn sm ghost" data-act="wish-buy" data-id="${w.id}">${icon(w.purchased ? 'x' : 'check')}${w.purchased ? 'Qaytarish' : 'Sotib olindi'}</button>
      </div>
    </div>
  </div>`;
}

/* ================= RENDER ================= */
export function render(view, ctx) {
  const route = ctx.route;
  if (route === 'wishlist') {
    const list = [...state.wishes].sort((a, b) => (Number(b.priority) || 0) - (Number(a.priority) || 0));
    const total = list.reduce((s, w) => s + (Number(w.price) || 0), 0);
    const saved = list.reduce((s, w) => s + (Number(w.saved) || 0), 0);
    const bought = list.filter((w) => w.purchased);
    view.innerHTML = `<div class="stagger">
      ${pageHead({
      title: 'Wishlist', icon: 'star', badge: 'xohishlar ro\'yxati',
      sub: 'Nima olishni istaysiz — narxini yozing va jamg\'arib boring',
      actions: `<button class="btn primary sm" data-act="add-wish">${icon('plus')}Xohish qo'shish</button>`
    })}
      <div class="kpis" style="margin-bottom:20px">
        ${kpi({ label: 'Jami qiymat', value: money(total), icon: 'star' })}
        ${kpi({ label: 'Yig\'ilgan', value: money(saved), icon: 'coins', delta: { dir: 'up', text: `${total ? ((saved / total) * 100).toFixed(0) : 0}% tayyor` } })}
        ${kpi({ label: 'Qolgan', value: money(Math.max(0, total - saved)), icon: 'target' })}
        ${kpi({ label: 'Sotib olingan', value: `${bought.length} / ${list.length}`, icon: 'check' })}
      </div>
      ${section({
      title: 'Xohishlarim', icon: 'grid', sub: 'Har bir kartani qalamcha bilan tahrirlashingiz mumkin',
      body: list.length ? `<div class="grid g4">${list.map((w) => wishCard(w, ctx)).join('')}</div>`
        : empty({ icon: 'star', title: 'Xohishlar yo\'q', sub: 'Masalan: avtomobil, telefon, sayohat…', action: `<button class="btn primary sm" data-act="add-wish">${icon('plus')}Birinchi xohishni qo'shish</button>` })
    })}
    </div>`;
    fillMedia(view);
    on(view, 'click', '[data-act]', async (e, b) => {
      const act = b.dataset.act, id = b.dataset.id;
      if (act === 'add-wish') return openWishForm(null, ctx);
      if (act === 'edit-wish') return openWishForm(state.wishes.find((w) => w.id === id), ctx);
      if (act === 'del-wish') { state.wishes = state.wishes.filter((w) => w.id !== id); save(); toast('O\'chirildi', { type: 'warn' }); return ctx.refresh(); }
      if (act === 'wish-fund') { const w = state.wishes.find((x) => x.id === id); if (w) return addWishFunds(w, ctx); }
      if (act === 'wish-buy') { const w = state.wishes.find((x) => x.id === id); if (w) { w.purchased = !w.purchased; save(); toast(w.purchased ? 'Tabriklaymiz! 🎉' : 'Belgi olib tashlandi', { type: 'success' }); sfx('coin'); ctx.refresh(); } }
    });
    return;
  }

  /* ---------- goals ---------- */
  const goals = [...state.goals].sort((a, b) => goalProgress(b).pct - goalProgress(a).pct);
  const totalTarget = goals.reduce((s, g) => s + (Number(g.target) || 0), 0);
  const totalSaved = goals.reduce((s, g) => s + (Number(g.saved) || 0), 0);
  const doneCount = goals.filter((g) => goalProgress(g).pct >= 100).length;
  const avg = goals.length ? goals.reduce((s, g) => s + goalProgress(g).pct, 0) / goals.length : 0;

  view.innerHTML = `<div class="stagger">
    ${pageHead({
    title: 'Maqsadlar', icon: 'target', badge: 'kelajak rejalari',
    sub: 'Har bir maqsad alohida progress bilan — foizlar yashil rangda',
    actions: `<button class="btn sm ghost" data-act="go-wish">${icon('star')}Wishlist</button>
        <button class="btn primary sm" data-act="add-goal">${icon('plus')}Maqsad qo'shish</button>`
  })}
    <div class="kpis" style="margin-bottom:20px">
      ${kpi({ label: 'Jami maqsad summasi', value: money(totalTarget), icon: 'target' })}
      ${kpi({ label: 'Yig\'ilgan', value: money(totalSaved), icon: 'coins' })}
      ${kpi({ label: 'Qolgan', value: money(Math.max(0, totalTarget - totalSaved)), icon: 'clock' })}
      ${kpi({ label: 'Bajarilgan maqsadlar', value: `${doneCount} / ${goals.length}`, icon: 'check' })}
    </div>
    ${goals.length ? `<div class="card" style="margin-bottom:20px">
      <div class="row between" style="flex-wrap:wrap;gap:14px">
        ${ring(avg, 92, avg.toFixed(0) + '%')}
        <div class="grow"><div class="h2">Umumiy progress</div>
          <div class="tiny faint">Barcha maqsadlar bo'yicha o'rtacha bajarilish darajasi</div>
          <div style="margin-top:8px">${bar(avg)}</div></div>
        <div class="row wrap" style="gap:8px">
          ${statMini('Maqsadlar', String(goals.length), 'target')}
          ${statMini('Bajarilgan', String(doneCount), 'check')}
        </div>
      </div>
    </div>` : ''}
    ${section({
    title: 'Maqsadlarim', icon: 'grid', sub: 'Rasm, muddat, qadamlar va foizli progress',
    body: goals.length ? `<div class="grid g3">${goals.map((g) => goalCard(g, ctx)).join('')}</div>`
      : empty({ icon: 'target', title: 'Hali maqsad yo\'q', sub: 'Aniq raqamli maqsad qo\'ying — progress avtomatik hisoblanadi', action: `<button class="btn primary sm" data-act="add-goal">${icon('plus')}Birinchi maqsadni qo'shish</button>` })
  })}
  </div>`;

  fillMedia(view);
  on(view, 'click', '[data-act]', async (e, b) => {
    const act = b.dataset.act, id = b.dataset.id;
    if (act === 'go-wish') return ctx.go('wishlist');
    if (act === 'add-goal') return openGoalForm(null, ctx);
    if (act === 'edit-goal') return openGoalForm(state.goals.find((g) => g.id === id), ctx);
    if (act === 'del-goal') {
      const g = state.goals.find((x) => x.id === id);
      const ok = await confirmDialog('Maqsadni o\'chirish?', `«${g ? g.title : ''}» butunlay o'chiriladi.`, { danger: true, okLabel: 'O\'chirish' });
      if (!ok) return;
      state.goals = state.goals.filter((x) => x.id !== id); save(); toast('O\'chirildi', { type: 'warn' }); return ctx.refresh();
    }
    if (act === 'fund') { const g = state.goals.find((x) => x.id === id); if (g) return addFunds(g, ctx); }
    if (act === 'toggle-step') {
      const g = state.goals.find((x) => x.id === id); const i = Number(b.dataset.step);
      if (g && g.steps && g.steps[i]) { g.steps[i].done = !g.steps[i].done; save(); sfx(g.steps[i].done ? 'check' : 'uncheck'); ctx.refresh(); }
      return;
    }
    if (act === 'goal-detail') { const g = state.goals.find((x) => x.id === id); if (g) return openGoalDetail(g, ctx); }
  });
}

export function openGoalDetail(g, ctx) {
  const p = goalProgress(g);
  const m = modal.open({
    title: g.title, icon: 'target', size: 'wide',
    body: `
      <div class="row wrap" style="gap:8px"><span class="badge accent">${esc(CAT_LABEL[g.category] || 'Maqsad')}</span>${stars(g.priority)}</div>
      ${thumb(g.cover, { ratio: '16:9', pos: g.cover_pos, zoom: g.cover_zoom, icon: 'target' })}
      <div class="row between" style="flex-wrap:wrap;gap:16px">
        ${ring(p.pct, 92)}
        <div class="grow">${bar(p.pct)}
          <div class="pmeta"><span>${money(p.saved)} yig'ildi</span><span>Maqsad: ${money(p.target)}</span></div>
          <div class="pmeta"><span>Qoldi: <b>${money(p.left)}</b></span><span>${g.deadline ? 'Muddat: ' + esc(fmtDate(g.deadline)) : ''}</span></div>
        </div>
      </div>
      ${(g.steps || []).length ? `<div><div class="lbl">${icon('list')}Qadamlar</div>
        ${g.steps.map((s) => `<div class="task ${s.done ? 'done' : ''}"><div class="cbox">${icon('check')}</div><div class="task-text">${esc(s.text)}</div></div>`).join('')}</div>` : ''}
      ${g.note ? `<div><div class="lbl">${icon('note')}Izoh</div><div class="card flat" style="white-space:pre-wrap">${esc(g.note)}</div></div>` : ''}
      ${(g.history || []).length ? `<div><div class="lbl">${icon('coins')}Jamg'arma tarixi</div><div class="col" style="gap:7px">
        ${g.history.slice(0, 12).map((h) => `<div class="row between"><span class="tiny faint">${esc(fmtDate(h.at))} · ${esc(h.note || '')}</span><b class="num up">+${money(h.amount)}</b></div>`).join('')}</div></div>` : ''}
    `,
    footer: `<button class="btn ghost" data-x>Yopish</button><button class="btn soft" data-fund>${icon('plus')}Pul qo'shish</button><button class="btn primary" data-e>${icon('pencil')}Tahrirlash</button>`,
  });
  m.root.querySelector('[data-x]').onclick = () => m.close();
  m.root.querySelector('[data-fund]').onclick = async () => { m.close(); await addFunds(g, ctx); };
  m.root.querySelector('[data-e]').onclick = () => { m.close(); openGoalForm(g, ctx); };
  fillMedia(m.root);
}

export { render as default };
