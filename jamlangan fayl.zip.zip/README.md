# KHUMOYUN OS — shaxsiy boylik va trading tizimi

To'liq offline ishlaydigan, animatsiyali va ovozli shaxsiy dashboard: **Net Worth**, **Cash**,
**Trading Journal**, **Maqsadlar**, **Wishlist**, **Izohlar**, **Kunlik vazifalar + kalendar**,
**Musiqa** kutubxonasi va **Sozlamalar** (PIN, mavzu, fon, UI formati, eksport/import).

## Ishga tushirish (lokal)

```bash
node tools/dev-server.mjs        # http://localhost:3000
```

Yoki istalgan statik server: `npx serve public` — build qadami yo'q, tashqi kutubxona ishlatilmagan.

## Imkoniyatlar

| Bo'lim | Nima bor |
| --- | --- |
| Net Worth | Umumiy boylik, 30 kunlik o'zgarish, taqsimot (donut), oylik cash flow grafigi, menyu kartalari |
| Cash | Hisoblar (naqd/bank/kripto/aksiya/…), kirim, chiqim, o'tkazma (komissiya bilan), oylik hisobot |
| Trading Journal | TP/SL, R koeffitsiyent, P/L, win rate, **faqat 16:9 skrinshot**, xulosa matni, CSV eksport |
| Maqsadlar | Rasm, muddat, qadamlar (checklist), foizli yashil progress, "pul qo'shish" |
| Wishlist | Rasm (1:1), narx, jamg'arma progressi, "sotib olindi" belgisi |
| Izohlar | Kunlik izoh / muammo / g'oya / reja, kayfiyat, teg, ko'p rasm va video |
| Vazifalar | Kalendar (oy bo'yicha), har kunga alohida reja, rasm **16:9 / 1:1 / 9:16**, kunlik progress |
| Musiqa | MP3 import, jildlar (1:1 muqova), custom player + spektr vizualizatsiya |
| Sozlamalar | Profil va shaxsiy ma'lumotlar, PIN (uzunlikni tanlash, avtomatik kirish, avto-qulf), 6 mavzu, **5 UI formati (Glass / Solid / Neon / Minimal / Cinematic — har biri haqiqiy qiymatlarga ega)**, fon rasm/video + **blur / zoom / qoraytirish / kadr**, menyularni tahrirlash, **4 ovoz paketi**, ZIP eksport/import |

## Ovoz (yangi)
Ovozlar tashqi faylsiz, **Web Audio** dvigateli bilan real vaqtda sintezlanadi: ADSR konvertlar,
lowpass filtr, kompressor va reverb (xona effekti). 4 xil paket: **Glass** (premium va tiniq),
**Drop** (suv tomchisidek mayin), **Mech** (quruq, aniq mexanik), **Retro** (8-bit). Alohida audio fayl
ishlatilmagani uchun tizim internetsiz ham to'liq ovozli ishlaydi (Sozlamalar → Ovoz → paketni bosing va tinglang).

## PIN oqimi
Birinchi ochilishda kod uzunligini tanlaysiz (4 / 5 / 6), kodni ikki marta kiritasiz — **tasdiqlash tugmasi yo'q**,
kod to'liq kiritilishi bilan tizim avtomatik ochiladi. Keyingi kirishlarda uzunlik eslab qolinadi.

## Xavfsizlik va ma'lumotlar

- PIN kod **SHA-256** bilan shifrlanib, faqat qurilmada saqlanadi. Kirishda bir marta tasdiqlanadi.
- Barcha ma'lumotlar: `localStorage` (sozlamalar, yozuvlar) + `IndexedDB` (rasm, video, mp3).
- Service Worker tufayli **internetsiz** ishlaydi (ilova sifatida o'rnatish mumkin).
- Eksport: ZIP (barcha yozuvlar + media fayllar) — kompyuter almashtirilganda Import orqali tiklanadi.

## Klaviatura

`/` qidiruv · `1…9` menyular · `N` tez qo'shish · `L` qulflash · `M`/`Space` musiqa · `Ctrl/⌘+S` ZIP zaxira
