/* KHUMOYUN OS — Cloudflare Worker entry (static assets + SPA fallback) */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const res = await env.ASSETS.fetch(request);
    if (res.status === 404 && request.method === 'GET' && (request.headers.get('accept') || '').includes('text/html')) {
      return env.ASSETS.fetch(new Request(new URL('/index.html', url), request));
    }
    const out = new Response(res.body, res);
    /* sw.js, version.json va HTML keshlanmasin — yangi versiya darhol ko'rinadi */
    if (/^\/(sw\.js|version\.json|index\.html)$/.test(url.pathname) || url.pathname === '/') {
      out.headers.set('cache-control', 'no-cache, must-revalidate');
    }
    return out;
  }
};
