/* KHUMOYUN OS — Netlify uchun tayyor paket yasash.
   Ishlatish:  node tools/build-netlify.mjs
   Natija:
     deploy/netlify-static/       → to'liq statik sayt (PWA + offline)  ← TAVSIYA
     deploy/netlify-drop/index.html → yakka fayl (Netlify Drop uchun)
     deploy/khumoyun-os-netlify.zip → statik sayt arxivi (Drop'ga tashlash mumkin)
*/
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root = path.resolve(import.meta.dirname, '..');
const pub = path.join(root, 'public');
const deploy = path.join(root, 'deploy');
const stat = path.join(deploy, 'netlify-static');
const SKIP = new Set(['download', 'node_modules']);

fs.rmSync(stat, { recursive: true, force: true });
fs.mkdirSync(stat, { recursive: true });
const copy = (from, to) => {
  for (const e of fs.readdirSync(from, { withFileTypes: true })) {
    if (SKIP.has(e.name)) continue;
    const a = path.join(from, e.name), b = path.join(to, e.name);
    if (e.isDirectory()) { fs.mkdirSync(b, { recursive: true }); copy(a, b); }
    else fs.copyFileSync(a, b);
  }
};
copy(pub, stat);

fs.writeFileSync(path.join(stat, '_headers'), `/sw.js
  Cache-Control: no-cache, must-revalidate

/version.json
  Cache-Control: no-cache, must-revalidate

/index.html
  Cache-Control: no-cache, must-revalidate

/css/*
  Cache-Control: no-cache, must-revalidate

/js/*
  Cache-Control: no-cache, must-revalidate

/fonts/*
  Cache-Control: public, max-age=31536000, immutable

/icons/*
  Cache-Control: public, max-age=31536000, immutable
`);
fs.writeFileSync(path.join(stat, '_redirects'), '/*    /index.html   200\n');
fs.writeFileSync(path.join(stat, 'netlify.toml'), `[build]
  publish = "."

[[headers]]
  for = "/sw.js"
  [headers.values]
    Cache-Control = "no-cache, must-revalidate"

[[headers]]
  for = "/version.json"
  [headers.values]
    Cache-Control = "no-cache, must-revalidate"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
`);

/* yakka fayl build */
execFileSync(process.execPath, [path.join(root, 'tools', 'build-standalone.mjs')], { stdio: 'inherit' });

/* ZIP (python — tashqi paket kerak emas) */
const zip = path.join(deploy, 'khumoyun-os-netlify.zip');
fs.rmSync(zip, { force: true });
execFileSync('python3', ['-c', `
import zipfile, os, sys
root = sys.argv[1]; out = sys.argv[2]
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for base, dirs, files in os.walk(root):
        for f in files:
            p = os.path.join(base, f)
            z.write(p, os.path.relpath(p, root))
print('zip:', round(os.path.getsize(out)/1024), 'KB')
`, stat, zip], { stdio: 'inherit' });

const total = (d) => fs.readdirSync(d).reduce((n, f) => {
  const p = path.join(d, f);
  return n + (fs.statSync(p).isDirectory() ? total(p) : fs.statSync(p).size);
}, 0);
console.log('✔ netlify-static:', (total(stat) / 1024).toFixed(0), 'KB ·', fs.readdirSync(stat).length, 'element');
