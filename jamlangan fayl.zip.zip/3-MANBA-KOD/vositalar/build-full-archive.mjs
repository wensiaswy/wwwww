/* KHUMOYUN OS — TO'LIQ loyiha arxivi (bir ZIP ichida hamma narsa).
   Natija: deploy/KHUMOYUN-OS-TOLIQ-LOYIHA.zip                                */
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root = path.resolve(import.meta.dirname, '..');
const pub = path.join(root, 'public');
const stage = path.join(root, 'deploy', 'full-stage');
const zip = path.join(root, 'deploy', 'KHUMOYUN-OS-TOLIQ-LOYIHA.zip');
fs.rmSync(stage, { recursive: true, force: true });
fs.mkdirSync(stage, { recursive: true });

const copy = (from, to, skip = []) => {
  fs.mkdirSync(to, { recursive: true });
  for (const e of fs.readdirSync(from, { withFileTypes: true })) {
    if (skip.includes(e.name)) continue;
    const a = path.join(from, e.name), b = path.join(to, e.name);
    if (e.isDirectory()) copy(a, b, skip); else fs.copyFileSync(a, b);
  }
};

/* 1) Saytni ochish uchun bitta fayl */
copy(path.join(root, 'deploy', 'netlify-drop'), path.join(stage, '1-SAYTNI-OCHISH'), ['.bundle.js']);

/* 2) Netlify / istalgan hosting uchun tayyor statik sayt */
const stat = path.join(root, 'deploy', 'netlify-static');
copy(stat, path.join(stage, '2-HOSTINGGA-YUKLASH'));

/* 3) To'liq manba kod + yig'ish vositalari */
copy(pub, path.join(stage, '3-MANBA-KOD', 'sayt'), ['download']);
copy(path.join(root, 'tools'), path.join(stage, '3-MANBA-KOD', 'vositalar'));
fs.copyFileSync(path.join(root, 'worker.js'), path.join(stage, '3-MANBA-KOD', 'worker.js'));
fs.copyFileSync(path.join(root, 'sites.manifest.json'), path.join(stage, '3-MANBA-KOD', 'sites.manifest.json'));

/* 3b) eski qo'llanmalar */
for (const f of ['README.md', 'README-NETLIFY.md']) {
  const src = path.join(root, f);
  if (fs.existsSync(src)) fs.copyFileSync(src, path.join(stage, f));
}

/* 4) O'zbekcha qo'llanma */
const ver = JSON.parse(fs.readFileSync(path.join(pub, 'version.json'), 'utf8'));
fs.writeFileSync(path.join(stage, 'OQING-BIRINCHI.txt'), `KHUMOYUN OS — TO'LIQ LOYIHA ARXIVI
Versiya: v${ver.version}  ·  yig'ilgan sana: ${ver.build}
${'='.repeat(64)}

Bu ZIP ichida saytning HAMMA narsasi bor. Kompyuteringizni tozalasangiz ham,
bu bitta fayl bilan hammasini tiklab, istalgan kompyuterda ochib ishlatasiz.

ICHIDA NIMA BOR
----------------
1-SAYTNI-OCHISH/
   index.html        → shu faylni ikki marta bossangiz sayt ochiladi.
                       Internet ham, server ham, o'rnatish ham kerak emas —
                       HTML + CSS + JS + shrift + ikonka hammasi shu bitta
                       faylning ichida (offline ishlaydi).

2-HOSTINGGA-YUKLASH/
   index.html, css/, js/, fonts/, icons/, sw.js, manifest.webmanifest,
   version.json, _headers, _redirects, netlify.toml
   → Netlify'ga yuklash uchun tayyor sayt (pastroqda batafsil).
     Bu nusxa "O'rnatiladigan ilova" (PWA) bo'lib ishlaydi va offline keshga
     ega bo'ladi (service worker).

3-MANBA-KOD/
   sayt/       → saytning asl manba fayllari (index.html, css/, js/)
   vositalar/  → qayta yig'ish skriptlari:
                   node vositalar/build-standalone.mjs   → bitta fayl yasash
                   node vositalar/build-netlify.mjs      → hosting to'plami + ZIP
                   node vositalar/dev-server.mjs         → lokal preview (3000-port)
   worker.js, sites.manifest.json → Cloudflare Workers uchun variant

Bitta faylni qayta yasash (ixtiyoriy):  node vositalar/build-netlify.mjs

NETLIFY'GA QANDAY YUKLAYDI
--------------------------
1-usul (eng oson, "drag & drop"):
   app.netlify.com → Sites → "Add new site" → "Deploy manually"
   → 2-HOSTINGGA-YUKLASH papkasini sichqoncha bilan sudrab tashlang. Tamom.

2-usul (ZIP bilan):
   Netlify'da "Deploy manually" oynasiga shu ZIP ni tashlash ham mumkin
   (faqat ichidagi sayt fayllari ildizda bo'lishi kerak — ya'ni
   2-HOSTINGGA-YUKLASH papkasidan ZIP yasab tashlang).

3-usul (Git orqali): 2-HOSTINGGA-YUKLASH mazmunini repoga qo'yib, Netlify'da
   build buyrug'ini bo'sh, "publish directory" ni "." qilib qo'ying
   (netlify.toml fayli buni o'zi sozlab beradi).

DIQQAT: MA'LUMOTLAR (balans, treyd, maqsadlar, musiqa...) SAYT FAYLLARIDA EMAS
--------------------------------------------------------------------------------
Saytning barcha ma'lumotlari brauzer xotirasida (localStorage + IndexedDB)
saqlanadi — serverga hech narsa yuborilmaydi. Shu sababli ZIP ni boshqa
kompyuterga ko'chirsangiz ham, O'SHA MA'LUMOTLAR o'zi bilan ko'chmaydi.

Ma'lumotlaringizni ko'chirish uchun saytning o'zida:
   Sozlamalar → Ma'lumotlar → "Zaxira (ZIP) yuklab olish"
Keyin yangi kompyuterda:
   Sozlamalar → Ma'lumotlar → "Zaxira import qilish"
Shunda barcha yozuvlaringiz, rasmlaringiz, videolaringiz va mp3 laringiz
ham qaytadi (ZIP ichida media fayllar ham bo'ladi).

QISQA ESda:  birinchi bo'lib SHU ZAXIRA ZIP ni oling — u kod emas, sizning
shaxsiy ma'lumotlaringiz. Kod uchun esa shu arxiv yetarli.

Muammo bo'lsa: sayt ichida Sozlamalar → Yordam → "Keshni tozalash va yangilash".
`);

/* 5) ZIP */
fs.rmSync(zip, { force: true });
execFileSync('python3', ['-c', `
import zipfile, os, sys
root, out = sys.argv[1], sys.argv[2]
n = 0
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for base, dirs, files in os.walk(root):
        for f in files:
            p = os.path.join(base, f)
            z.write(p, os.path.join('KHUMOYUN-OS', os.path.relpath(p, root)))
            n += 1
print('zip fayllar:', n, '· hajm:', round(os.path.getsize(out)/1024), 'KB')
`, stage, zip], { stdio: 'inherit' });
fs.rmSync(stage, { recursive: true, force: true });
