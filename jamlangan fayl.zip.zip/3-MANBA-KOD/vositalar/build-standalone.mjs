/* KHUMOYUN OS — yakka fayl (single-file) build.
   CSS + JS + shriftlar + ikonka hammasi bitta index.html ichiga joylanadi.
   Ishlatish:  node tools/build-standalone.mjs                                */
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root = path.resolve(import.meta.dirname, '..');
const pub = path.join(root, 'public');
const outDir = path.join(root, 'deploy', 'netlify-drop');
fs.mkdirSync(outDir, { recursive: true });

/* 1) JS ni bitta faylga yig'amiz (esbuild) */
const bundlePath = path.join(outDir, '.bundle.js');
const esbuild = process.env.ESBUILD || path.join(process.env.HOME, 'pw', 'node_modules', '.bin', 'esbuild');
execFileSync(esbuild, [
  path.join(pub, 'js', 'app.js'), '--bundle', '--format=iife', '--minify',
  '--target=es2020', '--charset=utf8', `--outfile=${bundlePath}`,
], { stdio: 'inherit' });
const js = fs.readFileSync(bundlePath, 'utf8');

/* 2) CSS + shriftlar (base64 data URI) */
const faces = ['400', '600', '700', '800'];
let css = ['base', 'components', 'effects']
  .map((n) => fs.readFileSync(path.join(pub, 'css', `${n}.css`), 'utf8')).join('\n');
for (const w of faces) {
  const b64 = fs.readFileSync(path.join(pub, 'fonts', `inter-${w}.woff2`)).toString('base64');
  css = css.split(`../fonts/inter-${w}.woff2`).join(`data:font/woff2;base64,${b64}`);
}

/* 3) HTML: tashqi havolalarni ichkariga joylaymiz */
let html = fs.readFileSync(path.join(pub, 'index.html'), 'utf8');
const iconB64 = Buffer.from(fs.readFileSync(path.join(pub, 'icons', 'icon.svg'))).toString('base64');
const manifest = fs.readFileSync(path.join(pub, 'manifest.webmanifest'), 'utf8');
const manifestB64 = Buffer.from(manifest).toString('base64');

html = html
  .replace(/\s*<link rel="manifest"[^>]*>/, '')
  .replace(/\s*<link rel="icon"[^>]*>/, `\n<link rel="icon" href="data:image/svg+xml;base64,${iconB64}">`)
  .replace(/\s*<link rel="stylesheet" href="\.\/css\/[^"]+">/g, '')
  .replace('</head>', `<style>\n${css}\n</style>\n</head>`)
  .replace(/\s*<script type="module" src="\.\/js\/app\.js"><\/script>/,
    `\n<script>window.__NO_SW=1;</script>\n<script>\n${js}\n</script>`)
  .replace('<title>', `<!-- KHUMOYUN OS — yakka fayl nusxa · offline PWA uchun deploy/netlify-static ishlating -->\n<title>`);

/* manifest'ni ham data sifatida qoldiramiz (brauzer qabul qilsa o'rnatiladi) */
html = html.replace('</head>', `<link rel="manifest" href="data:application/manifest+json;base64,${manifestB64}">\n</head>`);

fs.writeFileSync(path.join(outDir, 'index.html'), html);
fs.rmSync(bundlePath, { force: true });
const kb = (n) => (n / 1024).toFixed(0) + ' KB';
console.log('✔ deploy/netlify-drop/index.html yaratildi:', kb(Buffer.byteLength(html)), '| JS:', kb(Buffer.byteLength(js)));
