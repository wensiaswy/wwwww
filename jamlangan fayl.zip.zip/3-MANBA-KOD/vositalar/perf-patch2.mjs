import fs from 'node:fs';
import path from 'node:path';
const p = path.resolve(import.meta.dirname, '..', 'public', 'js', 'app.js');
let src = fs.readFileSync(p, 'utf8');
const edits = [];
const E = (find, repl, note) => edits.push({ find, repl, note });

/* 1) applyUi — rAF bilan birlashtirish + memoizatsiya */
E(`export function applyUi() {
  const s = state.settings, ui = s.ui;
  const root = document.documentElement;`,
`let uiRaf = 0, uiSig = '';
/* rAF bilan birlashtiriladi: bir freymda bir necha marta chaqirilsa ham FAQAT bir marta
   qo'llanadi. Shu bilan slayder surishda style/layout thrashing bo'lmaydi. */
export function applyUi() {
  if (uiRaf) return;
  uiRaf = requestAnimationFrame(() => { uiRaf = 0; try { applyUiNow(); } catch (e) { console.error(e); } });
}
function applyUiNow() {
  const s = state.settings, ui = s.ui;
  const root = document.documentElement;
  /* qiymatlar o'zgarmagan bo'lsa — umuman qayta hisoblamaymiz */
  const sig = [s.theme, s.preset, ui.density, s.perf, !!s.lowfx, !!s.effects.cursorGlow, ui.glass, ui.radius, ui.dim,
    ui.fontScale, ui.anim, ui.panelAlpha, ui.borderAlpha, ui.shadow, ui.tint || ''].join('|');
  if (sig === uiSig) return;
  uiSig = sig;`, 'applyUi: rAF + memo');

/* 2) applyBg — blur 0 bo'lsa filtr o'chadi, blur chegaralanadi (full-screen blur eng qimmat operatsiya) */
E(`    mainWrap.style.setProperty('--bg-blur', (blur * .6).toFixed(1) + 'px');`,
`    /* Full-screen blur eng og'ir operatsiya: 22px dan oshirilmaydi va 0 bo'lsa butunlay o'chadi */
    mainWrap.style.setProperty('--bg-blur', Math.min(22, blur * .6).toFixed(1) + 'px');
    mainWrap.dataset.blur = blur > 0 ? '1' : '0';`, 'bg blur chegarasi');

E(`    lockWrap.style.setProperty('--lock-blur', (lb * .6).toFixed(1) + 'px');`,
`    lockWrap.style.setProperty('--lock-blur', Math.min(22, lb * .6).toFixed(1) + 'px');
    lockWrap.dataset.blur = lb > 0 ? '1' : '0';`, 'lock blur chegarasi');

/* 3) Zarrachalar: getComputedStyle har freymda EMAS + rang keshlanadi */
E(`    const accent = () => getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#22e07a';
    const loop = () => {
      requestAnimationFrame(loop);
      if (document.hidden) return;                    /* fon oynada resurs tejaladi */
      if (document.body.classList.contains('lowfx')) { ctx.clearRect(0, 0, W, H); return; }
      if (!state.settings.effects.particles) { ctx.clearRect(0, 0, W, H); return; }
      ctx.clearRect(0, 0, W, H);
      const col = accent();
      parts.forEach((p) => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = W; if (p.x > W) p.x = 0;
        if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = col; ctx.globalAlpha = p.a * .55; ctx.fill();
      });
      ctx.globalAlpha = 1;
    };
    loop();
  }`,
`    /* MUHIM: getComputedStyle va fillStyle parsing har freymda chaqirilmasin —
       rang bir marta o'qiladi (tema o'zgarganda yangilanadi). Bu 60fps uchun katta yutuq. */
    let col = '#22e07a', colDirty = true;
    const readAccent = () => { colDirty = true; };
    window.addEventListener('kx:theme', readAccent);
    window.addEventListener('kwttheme', readAccent);
    let wasActive = true, idleFrames = 0;
    const loop = () => {
      requestAnimationFrame(loop);
      if (document.hidden) return;                    /* fon oynada resurs tejaladi */
      const active = !document.body.classList.contains('lowfx') && !!state.settings.effects.particles;
      if (!active) {
        if (wasActive) { ctx.clearRect(0, 0, W, H); wasActive = false; }
        idleFrames++;
        if (idleFrames % 30 === 0) readAccent();      /* o'chiq holatda ham temasiz qolmaymiz */
        return;
      }
      wasActive = true; idleFrames = 0;
      if (colDirty) { col = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#22e07a'; colDirty = false; }
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = col;                            /* bir marta — tsikl ichida emas */
      for (let i = 0; i < parts.length; i++) {
        const pt = parts[i];
        pt.x += pt.vx; pt.y += pt.vy;
        if (pt.x < 0) pt.x = W; else if (pt.x > W) pt.x = 0;
        if (pt.y < 0) pt.y = H; else if (pt.y > H) pt.y = 0;
        ctx.globalAlpha = pt.a * .55;
        ctx.beginPath(); ctx.arc(pt.x, pt.y, pt.r, 0, 6.28318);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    };
    loop();
  }`, 'particles: rang keshi + bekorga chizmaslik');

/* 4) cursor glow + tilt: bitta rAF, rect faqat kartaga kirganda o'qiladi */
E(`  /* cursor glow */
  const cur = $('#fxCursor');
  if (cur) document.addEventListener('mousemove', throttle((e) => {
    cur.style.transform = \`translate(\${e.clientX}px, \${e.clientY}px) translate(-50%,-50%)\`;
  }, 30));
  /* ripples */
  document.addEventListener('pointerdown', (e) => {
    if (!state.settings.effects.ripple) return;
    if (e.target.closest('.modal, .lock, .splash')) return;
    ripple(e.clientX, e.clientY);
  });
  /* tilt */
  document.addEventListener('mousemove', throttle((e) => {
    if (!state.settings.effects.tilt || innerWidth < 900) return;
    const card = e.target.closest && e.target.closest('.tile, .card.lift');
    $$('.tilt').forEach((el) => { if (el !== card) { el.classList.remove('tilt'); el.style.transform = ''; } });
    if (!card) return;
    const r = card.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - .5, py = (e.clientY - r.top) / r.height - .5;
    card.classList.add('tilt');
    card.style.transform = \`perspective(1100px) rotateY(\${px * 3}deg) rotateX(\${-py * 3}deg) translateY(-2px)\`;
  }, 40));
  document.addEventListener('mouseleave', () => {
    $$('.tilt').forEach((el) => { el.classList.remove('tilt'); el.style.transform = ''; });
  });`,
`  /* ripples */
  document.addEventListener('pointerdown', (e) => {
    if (!state.settings.effects.ripple) return;
    if (e.target.closest('.modal, .lock, .splash')) return;
    ripple(e.clientX, e.clientY);
  });
  /* ---- cursor glow + card tilt ----
     Ilgari ikki alohida mousemove tinglovchisi bor edi va har harakatda barcha
     .tilt elementlar bo'ylab yurib, getBoundingClientRect (layout o'qish) qilardi.
     Endi: bitta rAF navbatga qo'yish, rect faqat karta O'ZGARGANDA o'qiladi. */
  const cur = $('#fxCursor');
  let mx = innerWidth / 2, my = innerHeight / 2, fxRaf = 0, tiltCard = null, tiltRect = null;
  const paintFx = () => {
    fxRaf = 0;
    if (cur) cur.style.transform = 'translate3d(' + mx + 'px,' + my + 'px,0) translate(-50%,-50%)';
    if (tiltCard && tiltRect) {
      const px = (mx - tiltRect.left) / tiltRect.width - .5;
      const py = (my - tiltRect.top) / tiltRect.height - .5;
      tiltCard.style.transform = 'perspective(1100px) rotateY(' + (px * 3).toFixed(2) + 'deg) rotateX(' + (-py * 3).toFixed(2) + 'deg) translate3d(0,-2px,0)';
    }
  };
  const queueFx = () => { if (!fxRaf) fxRaf = requestAnimationFrame(paintFx); };
  const clearTilt = () => {
    if (tiltCard) { tiltCard.classList.remove('tilt'); tiltCard.style.transform = ''; }
    tiltCard = null; tiltRect = null;
  };
  document.addEventListener('mousemove', (e) => {
    mx = e.clientX; my = e.clientY;
    const canTilt = state.settings.effects.tilt && innerWidth >= 900 && !!e.target.closest;
    const card = canTilt ? e.target.closest('.tile, .card.lift') : null;
    if (card !== tiltCard) {                 /* layout o'qish FAQAT shu yerda */
      clearTilt();
      if (card) { tiltCard = card; tiltRect = card.getBoundingClientRect(); card.classList.add('tilt'); }
    }
    queueFx();
  }, { passive: true });
  /* sahifa aylantirilsa karta koordinatalari eskiradi — tilt tozalanadi */
  window.addEventListener('scroll', () => { if (tiltCard) clearTilt(); }, { passive: true });
  document.addEventListener('mouseleave', clearTilt);`, 'cursor+tilt: bitta rAF, rect keshi');

let ok = 0; const miss = [];
for (const e of edits) {
  if (!src.includes(e.find)) { miss.push(e.note); continue; }
  src = src.replace(e.find, e.repl); ok++;
}
fs.writeFileSync(p, src);
console.log('✔ app.js yamog\'i:', ok + '/' + edits.length);
if (miss.length) { console.log('✖ topilmadi:', miss.join(' | ')); process.exit(1); }
