/* KHUMOYUN OS — mahalliy preview uchun oddiy statik server (faqat ishlab chiqish uchun) */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif',
  '.ico': 'image/x-icon', '.mp3': 'audio/mpeg', '.mp4': 'video/mp4', '.webm': 'video/webm', '.txt': 'text/plain; charset=utf-8',
};
const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://localhost');
  let file = path.join(ROOT, decodeURIComponent(url.pathname));
  if (url.pathname === '/' || url.pathname === '') file = path.join(ROOT, 'index.html');
  if (!file.startsWith(ROOT)) { res.writeHead(403); return res.end('403'); }
  fs.stat(file, (err, st) => {
    const isSpa = !err && st.isDirectory();
    if (err || isSpa) {
      fs.readFile(path.join(ROOT, 'index.html'), (e2, buf) => {
        if (e2) { res.writeHead(404); return res.end('404'); }
        res.writeHead(200, { 'content-type': MIME['.html'], 'cache-control': 'no-cache' });
        res.end(buf);
      });
      return;
    }
    fs.readFile(file, (e3, buf) => {
      if (e3) { res.writeHead(404); return res.end('404'); }
      const ext = path.extname(file).toLowerCase();
      res.writeHead(200, { 'content-type': MIME[ext] || 'application/octet-stream', 'cache-control': 'no-cache' });
      res.end(buf);
    });
  });
});
server.listen(PORT, HOST, () => console.log(`[dev] http://${HOST}:${PORT} — papka: ${ROOT}`));
