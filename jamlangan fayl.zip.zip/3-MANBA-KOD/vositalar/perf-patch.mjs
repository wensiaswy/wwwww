/* KHUMOYUN OS — unumdorlik (GPU) yamog'i: animatsiyalar transform/opacity ga,
   JS esa rAF bilan birlashtirilib, layout thrashing yo'q qilinadi. */
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..', 'public');
const edits = [];
const E = (file, find, repl, note) => edits.push({ file, find, repl, note });

/* ---------------- CSS: base.css ---------------- */
E('css/base.css',
`.bg-dim{position:absolute;inset:0;background:
  radial-gradient(120% 90% at 50% 40%,transparent 25%,rgba(2,4,8,calc(var(--dim) * .75)) 100%),
  rgba(3,5,9,var(--dim));transition:background .3s linear}`,
`.bg-dim{position:absolute;inset:0;opacity:var(--dim,0);will-change:opacity;transform:translateZ(0);backface-visibility:hidden;background:
  radial-gradient(120% 90% at 50% 40%,transparent 25%,rgba(2,4,8,.75) 100%),
  rgba(3,5,9,1);transition:opacity .22s linear}`, 'bg-dim: background→opacity (kompozitlanadi)');

E('css/base.css',
`.bg-aurora{position:absolute;inset:-10%;opacity:.42;animation:auroraDrift`,
`.bg-aurora{position:absolute;inset:-10%;opacity:.42;transform:translateZ(0);backface-visibility:hidden;contain:paint;will-change:transform;animation:auroraDrift`, 'aurora: o\'z qatlami (GPU)');

E('css/base.css',
`.bg-media{position:absolute;inset:-12%;transform:scale(var(--bg-zoom,1));transform-origin:center;
  filter:blur(var(--bg-blur,0px));will-change:filter,transform;
  transition:filter .25s var(--ease),transform .5s var(--ease)}`,
`.bg-media{position:absolute;inset:-12%;transform:scale(var(--bg-zoom,1));transform-origin:center;backface-visibility:hidden;
  filter:blur(var(--bg-blur,0px));will-change:filter,transform;
  transition:filter .25s var(--ease),transform .5s var(--ease)}
/* blur 0 bo'lsa filtr umuman qo'llanmaydi — ortiqcha qatlam/repaint bo'lmaydi */
.bg-media[data-blur="0"]{filter:none;will-change:transform}`, 'bg-media: blur=0 → filtr yo\'q');

E('css/base.css',
`@keyframes logoPulse{0%,100%{box-shadow:0 8px 22px color-mix(in srgb,var(--accent) 22%,transparent)}
  50%{box-shadow:0 10px 30px color-mix(in srgb,var(--accent) 40%,transparent)}}`,
`@keyframes logoPulse{0%,100%{transform:translateZ(0) scale(1)}
  50%{transform:translateZ(0) scale(1.045)}}`, 'logoPulse: box-shadow→transform');

E('css/base.css',
`  transition:width .35s var(--ease),flex-basis .35s var(--ease);z-index:40}`,
`  transition:width .3s var(--ease),flex-basis .3s var(--ease);backface-visibility:hidden;z-index:40}`, 'sidebar: yumshoqroq');

/* ---------------- CSS: components.css ---------------- */
E('css/components.css',
`.progress-fill{height:100%;border-radius:99px;background:linear-gradient(90deg,var(--accent),var(--accent-2));
  position:relative;overflow:hidden;transition:width .9s var(--ease-out);box-shadow:0 0 10px color-mix(in srgb,var(--accent) 22%,transparent)}`,
`.progress-fill{height:100%;width:100%;border-radius:99px;background:linear-gradient(90deg,var(--accent),var(--accent-2));
  position:relative;overflow:hidden;transform:scaleX(0);transform-origin:left center;will-change:transform;
  transition:transform .9s var(--ease-out);box-shadow:0 0 10px color-mix(in srgb,var(--accent) 22%,transparent)}`, 'progress: width→scaleX (layout yo\'q)');

E('css/components.css',
`.viz i{flex:1;background:linear-gradient(180deg,var(--accent-2),var(--accent));border-radius:2px;height:20%;transition:height .1s linear}`,
`.viz i{flex:1;background:linear-gradient(180deg,var(--accent-2),var(--accent));border-radius:2px;height:100%;transform:scaleY(.2);transform-origin:bottom center;will-change:transform;transition:transform .09s linear}`, 'viz: height→scaleY');

E('css/components.css',
`.pl-bar i{position:absolute;left:0;top:0;bottom:0;border-radius:99px;background:linear-gradient(90deg,var(--accent),var(--accent-2));width:0}`,
`.pl-bar i{position:absolute;left:0;top:0;bottom:0;border-radius:99px;background:linear-gradient(90deg,var(--accent),var(--accent-2));width:100%;transform:scaleX(0);transform-origin:left center;will-change:transform}`, 'player bar: width→scaleX');

E('css/components.css',
`@keyframes letterIn{from{opacity:0;transform:translateY(26px) rotate(6deg) scale(.9);filter:blur(8px)}to{opacity:1;transform:none;filter:none}}`,
`@keyframes letterIn{from{opacity:0;transform:letterIn0}to{opacity:1;transform:none}}`.replace('letterIn0', 'translateY(26px) rotate(6deg) scale(.9)'), 'letterIn: blur olib tashlandi');

E('css/components.css',
`.splash-bar span{display:block;height:100%;width:0;background:linear-gradient(90deg,var(--accent),var(--accent-2));animation:splashBar 2.1s var(--ease) forwards}`,
`.splash-bar span{display:block;height:100%;width:100%;transform:scaleX(0);transform-origin:left center;will-change:transform;background:linear-gradient(90deg,var(--accent),var(--accent-2));animation:splashBar 2.1s var(--ease) forwards}`, 'splash bar: width→scaleX');

E('css/components.css',
`@keyframes splashBar{to{width:100%}}`,
`@keyframes splashBar{to{transform:scaleX(1)}}`, 'splashBar keyframes');

E('css/components.css',
`@keyframes barShine{0%{transform:translateX(-100%)}60%,100%{transform:translateX(150%)}}`,
`@keyframes barShine{0%{transform:translate3d(-100%,0,0)}60%,100%{transform:translate3d(150%,0,0)}}`, 'barShine: translate3d');

/* ---------------- CSS: effects.css ---------------- */
E('css/effects.css',
`.ripple{position:absolute;width:10px;height:10px;border-radius:50%;transform:translate(-50%,-50%);
  border:1.5px solid color-mix(in srgb,var(--accent) 45%,transparent);animation:rippleOut .5s var(--ease-out) forwards}`,
`.ripple{position:absolute;width:110px;height:110px;margin:-55px 0 0 -55px;border-radius:50%;opacity:.85;
  transform:translateZ(0) scale(.09);transform-origin:center;will-change:transform,opacity;backface-visibility:hidden;
  border:1.5px solid color-mix(in srgb,var(--accent) 45%,transparent);animation:rippleOut .5s var(--ease-out) forwards}`,
`ripple: width/height→transform scale (layout thrash yo'q)`);

E('css/effects.css',
`@keyframes rippleOut{to{width:110px;height:110px;opacity:0;border-width:1px}}`,
`@keyframes rippleOut{to{transform:translateZ(0) scale(1);opacity:0}}`, 'rippleOut keyframes');

E('css/effects.css',
`@keyframes flashUp{0%{text-shadow:0 0 0 rgba(60,224,138,0)}30%{text-shadow:0 0 22px rgba(60,224,138,.85)}100%{text-shadow:none}}`,
`@keyframes flashUp{0%{color:inherit;transform:translateZ(0)}30%{color:#5df0a1;transform:translateZ(0) scale(1.06)}100%{color:inherit;transform:translateZ(0)}}`, 'flashUp: text-shadow→color/transform');

E('css/effects.css',
`@keyframes flashDown{0%{text-shadow:0 0 0 rgba(255,77,94,0)}30%{text-shadow:0 0 22px rgba(255,77,94,.85)}100%{text-shadow:none}}`,
`@keyframes flashDown{0%{color:inherit;transform:translateZ(0)}30%{color:#ff7a88;transform:translateZ(0) scale(1.06)}100%{color:inherit;transform:translateZ(0)}}`, 'flashDown: text-shadow→color/transform');

E('css/effects.css',
`.pulse-dot{width:8px;height:8px;border-radius:50%;background:#3ce08a;box-shadow:0 0 0 0 rgba(60,224,138,.6);animation:pulse 1.8s infinite}
@keyframes pulse{70%{box-shadow:0 0 0 12px rgba(60,224,138,0)}100%{box-shadow:0 0 0 0 rgba(60,224,138,0)}}`,
`.pulse-dot{position:relative;width:8px;height:8px;border-radius:50%;background:#3ce08a}
.pulse-dot::after{content:"";position:absolute;inset:0;border-radius:50%;border:2px solid rgba(60,224,138,.55);transform:translateZ(0);will-change:transform,opacity;animation:pulse 1.8s var(--ease) infinite}
@keyframes pulse{0%{transform:translateZ(0) scale(1);opacity:.75}70%,100%{transform:translateZ(0) scale(2.6);opacity:0}}`, 'pulse: box-shadow→transform ring');

E('css/effects.css',
`.eqbars i{flex:1;background:var(--accent);border-radius:2px;animation:eq 1s var(--ease) infinite alternate}
.eqbars i:nth-child(1){height:40%;animation-delay:.1s}
.eqbars i:nth-child(2){height:90%;animation-delay:.3s}
.eqbars i:nth-child(3){height:60%;animation-delay:.5s}
@keyframes eq{from{height:25%}to{height:100%}}`,
`.eqbars i{flex:1;height:100%;background:var(--accent);border-radius:2px;transform-origin:bottom center;will-change:transform;animation:eq 1s var(--ease) infinite alternate}
.eqbars i:nth-child(1){animation-delay:.1s;animation-duration:.9s}
.eqbars i:nth-child(2){animation-delay:.3s;animation-duration:.7s}
.eqbars i:nth-child(3){animation-delay:.5s;animation-duration:1.1s}
@keyframes eq{from{transform:scaleY(.28)}to{transform:scaleY(1)}}`, 'eqbars: height→scaleY');

/* GPU qatlamlari/maslahatlar bloki */
E('css/effects.css',
`/* scrollbars */`,
`/* ============ GPU / COMPOSITING QOIDALARI ============
   Har bir animatsiya faqat transform/opacity bilan bajariladi — bu xossalarni
   brauzer GPU'da, layout va paint qilmasdan chizadi (60fps uchun muhim). */
.card,.tile,.kpi,.nav-item,.btn,.chip,.tab,.key,.item{backface-visibility:hidden}
.fx-canvas{contain:strict;will-change:transform}
.fx-ripples{contain:strict}
.bg-grain{backface-visibility:hidden}
.reveal,.stagger>*,.pop,.enter,.slide-in-right{will-change:transform,opacity}
.eqbars,.viz,.pulse-dot{contain:layout paint style}

/* scrollbars */`, 'GPU qoidalari bloki');

E('css/effects.css',
`body.lowfx .reveal,body.lowfx .stagger>*{animation-duration:.34s !important}
body.lowfx .float-slow{animation:none}`,
`body.lowfx .reveal,body.lowfx .stagger>*{animation-duration:.34s !important}
body.lowfx .float-slow{animation:none}
/* yengil rejimda layout animatsiyalari butunlay o'chadi */
body.lowfx .sidebar{transition:none}
body.lowfx .card,body.lowfx .tile,body.lowfx .kpi{box-shadow:none}
body.lowfx .bg-media{will-change:auto}`, 'lowfx: layout animatsiyalar o\'chadi');

/* ---------------- JS: util.js ---------------- */
E('js/util.js',
`export function ripple(x, y, color) {
  const root = $('#fxRipples'); if (!root) return;
  const r = document.createElement('span');
  r.className = 'ripple';
  r.style.left = x + 'px'; r.style.top = y + 'px';
  if (color) r.style.borderColor = color;
  root.appendChild(r);
  setTimeout(() => r.remove(), 760);
}`,
`export function ripple(x, y, color) {
  const root = $('#fxRipples'); if (!root) return;
  /* bir vaqtda 6 tadan ko'p to'lqin bo'lmasin (qatlamlar ko'payib ketmasin) */
  while (root.childElementCount >= 6) root.firstElementChild.remove();
  const r = document.createElement('span');
  r.className = 'ripple';
  r.style.left = x + 'px'; r.style.top = y + 'px';
  if (color) r.style.borderColor = color;
  r.addEventListener('animationend', () => r.remove(), { once: true });
  root.appendChild(r);
  setTimeout(() => { if (r.isConnected) r.remove(); }, 900);
}`, 'ripple: 6 ta chegara + animationend');

E('js/util.js',
`export function countUpAll(root = document) {
  $$('[data-count]', root).forEach((el) => {
    const to = Number(el.dataset.count) || 0;
    animateNumber(el, 0, to, { fmt: (v) => el.dataset.fmt === 'money' ? v.toLocaleString('en-US', { maximumFractionDigits: 0 }) : Math.round(v).toLocaleString('en-US') });
  });
}`,
`export function countUpAll(root = document) {
  /* Bitta umumiy rAF tsikli — o'nlab raqam uchun o'nlab tsikl ochilmaydi */
  const els = $$('[data-count]', root);
  if (!els.length) return;
  const items = els.map((el) => ({ el, to: Number(el.dataset.count) || 0 }));
  const t0 = performance.now(), ms = 900;
  const tick = (t) => {
    const p = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - p, 3);
    for (let i = 0; i < items.length; i++) items[i].el.textContent = Math.round(items[i].to * e).toLocaleString('en-US');
    if (p < 1) requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}`, 'countUpAll: bitta umumiy rAF');

E('js/util.js',
`export function barFill(root = document) {
  $$('.progress-fill[data-w]', root).forEach((el) => {
    const w = clamp(el.dataset.w);
    requestAnimationFrame(() => { el.style.width = w + '%'; });
  });
}`,
`export function barFill(root = document) {
  /* Bitta rAF + transform:scaleX — width animatsiyasi layout thrash beradi */
  const els = $$('.progress-fill[data-w]', root);
  if (!els.length) return;
  requestAnimationFrame(() => {
    for (let i = 0; i < els.length; i++) {
      els[i].style.transform = 'scaleX(' + (clamp(els[i].dataset.w) / 100) + ')';
    }
  });
}`, 'barFill: bitta rAF + scaleX');

/* ---------------- JS: view-settings.js ---------------- */
E('js/view-settings.js',
`      const bar = m.root.querySelector('#expBar'); bar.style.width = '4%';`,
`      const bar = m.root.querySelector('#expBar'); bar.style.transform = 'scaleX(.04)';`, 'export bar 1');
E('js/view-settings.js',
`          bar.style.width = p + '%';`,
`          bar.style.transform = 'scaleX(' + (p / 100) + ')';`, 'export bar 2');
E('js/view-settings.js',
`      const bar = mm.root.querySelector('.progress-fill'); bar.style.width = '5%';`,
`      const bar = mm.root.querySelector('.progress-fill'); bar.style.transform = 'scaleX(.05)';`, 'import bar 1');
E('js/view-settings.js',
`          bar.style.width = Math.round((i / Math.max(1, total)) * 100) + '%';`,
`          bar.style.transform = 'scaleX(' + (i / Math.max(1, total)) + ')';`, 'import bar 2');
E('js/view-settings.js',
`function barFillLocal(root) {
  $$('.progress-fill[data-w]', root).forEach((el) => { requestAnimationFrame(() => { el.style.width = clamp(el.dataset.w) + '%'; }); });
}`,
`function barFillLocal(root) {
  const els = $$('.progress-fill[data-w]', root);
  if (!els.length) return;
  requestAnimationFrame(() => { for (const el of els) el.style.transform = 'scaleX(' + (clamp(el.dataset.w) / 100) + ')'; });
}`, 'barFillLocal');

/* ---------------- JS: view-music.js ---------------- */
E('js/view-music.js',
`  if (barEl) barEl.style.width = (a.duration ? (a.currentTime / a.duration) * 100 : 0) + '%';`,
`  if (barEl) barEl.style.transform = 'scaleX(' + (a.duration ? a.currentTime / a.duration : 0).toFixed(4) + ')';`, 'player seek: scaleX');

E('js/view-music.js',
`  const bars = $$('i', wrap);
  const loop = () => {
    vizRAF = requestAnimationFrame(loop);
    if (!player.analyser) { bars.forEach((b, i) => { b.style.height = (player.audio && !player.audio.paused ? 20 + Math.random() * 70 : 12) + '%'; }); return; }
    const data = new Uint8Array(player.analyser.frequencyBinCount);
    player.analyser.getByteFrequencyData(data);
    bars.forEach((b, i) => {
      const v = data[Math.floor((i / bars.length) * (data.length * .7))] || 0;
      b.style.height = Math.max(8, (v / 255) * 100) + '%';
    });
  };`,
`  const bars = $$('i', wrap);
  let data = null;   /* bufer bir marta ajratiladi — har freymda GC bo'lmaydi */
  const loop = () => {
    vizRAF = requestAnimationFrame(loop);
    if (document.hidden) return;
    if (!player.analyser) {
      for (let i = 0; i < bars.length; i++) {
        const h = player.audio && !player.audio.paused ? 20 + Math.random() * 70 : 12;
        bars[i].style.transform = 'scaleY(' + (h / 100).toFixed(2) + ')';
      }
      return;
    }
    if (!data || data.length !== player.analyser.frequencyBinCount) data = new Uint8Array(player.analyser.frequencyBinCount);
    player.analyser.getByteFrequencyData(data);
    for (let i = 0; i < bars.length; i++) {
      const v = data[Math.floor((i / bars.length) * (data.length * .7))] || 0;
      bars[i].style.transform = 'scaleY(' + Math.max(.08, v / 255).toFixed(2) + ')';
    }
  };`, 'viz: scaleY + bufer qayta ishlatiladi');

/* ---------------- joylashuv: natija ---------------- */
let ok = 0, miss = [];
for (const e of edits) {
  const p = path.join(root, e.file);
  let src = fs.readFileSync(p, 'utf8');
  if (!src.includes(e.find)) { miss.push(e.file + ' :: ' + e.note); continue; }
  src = src.replace(e.find, e.repl);
  fs.writeFileSync(p, src);
  ok++;
}
console.log('✔ qo\'llandi:', ok + '/' + edits.length);
if (miss.length) { console.log('✖ topilmadi:'); miss.forEach((m) => console.log('   ' + m)); process.exit(1); }
